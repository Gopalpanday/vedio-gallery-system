import org.nfunk.jep.*;

public class DerivativeList{
	Node f;
	DerivativeList next;
	
	DerivativeList( Node f ){
		this.f = f;
	}
}