import java.awt.*;
import javax.swing.*;

public class Palette extends JPanel{

	Swatch first;
	Swatch current;
	
	int NUM_COLORS = 0;
	
	JPanel colorPanel;
	JLabel nameLabel;
	
	SpiroGraphApplet applet;

	public Palette( int rows, int columns, SpiroGraphApplet applet ){
		this.applet = applet;
		setLayout( new BorderLayout(1,1) );
		add( "Center", colorPanel = new JPanel( new GridLayout( rows, columns, 1, 1) ) );
		add( "South", nameLabel = new JLabel("",JLabel.CENTER) );
	}
	
	
	// inserts a new color into the palette immediately after current color
	public void addColor( Color color, String name ){
		if ( current == null ){
			current = new Swatch( color , name, this );
			first = current;
		} else {
			Swatch tmp = current.next;
			current.next = new Swatch( color , name, this ); //swatches are stored as a linked list
			current = current.next;
			current.next = tmp;
		}
		colorPanel.add( current );
		NUM_COLORS++;
	}
	
	public void setColor( Swatch swatch ){
		current.active = false;
		current.repaint();
		current = swatch;
		current.active = true;
		current.repaint();
		nameLabel.setText( current.name );
		//nameLabel.setBackground( current.color );
		setBackground( current.color );
		if ( applet.drawgraph != null ) applet.drawgraph.repaint();
	}
	
	public void setColor( String name ){
		Swatch swatch=first;
		while ( swatch.next != null && !swatch.name.equals(name) ) swatch = swatch.next;
		setColor( swatch );
	}
	
	public Color getColor(){
		return current.color;
	}

	public Color randomColor(){
		int r = (int)(Math.random()*NUM_COLORS);
		Swatch s = first;
		for (int i=0; i<r; i++) s = s.next;
		setColor(s);
		return s.color;
	}
}