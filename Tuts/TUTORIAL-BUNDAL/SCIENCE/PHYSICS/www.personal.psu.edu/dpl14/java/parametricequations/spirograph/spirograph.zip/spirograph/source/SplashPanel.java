import java.awt.*;
import java.lang.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;


class Spiro{

	double w;
	double x;
	double y;
	double[] values;
	
	boolean active;

	BufferedImage image;
	Graphics2D graphics;
	
	Spiro next;
	
	Color color = Color.red;

	public Spiro(){
		reset();
	}
	
	
	public int gcd(int x, int y){
		if ( x%y == 0 ) return y;
		return gcd(y,x%y);
	}


	public void reset(){
		active = true;
		values = new double[8];
			values[0] = (int)(20 + 20*Math.random());						// R
			values[1] = (int)(-values[0] + 5 + Math.random()*40);			// r
			if (values[1] == 0) values[1] = 2;
			values[2] = (int)(60*Math.random() - 30);						// p

		w = 2*(values[0]+Math.abs(values[1])+Math.abs(values[2]))+10;

			values[3] = values[1] < 0 ? -1.0 : 1.0;						// sign
			values[4] = 0.0;											// theta
			values[5] = 0.0;											// phi
			values[6] = w/2+values[0]+values[1]+values[2]+values[3];	// point.x
			values[7] = w/2;											// point.y

		x = 10 + 380*Math.random();
		y = 10 + 80*Math.random();

		image = new BufferedImage( (int)w, (int)w, BufferedImage.TYPE_INT_ARGB);
		graphics = (Graphics2D)(image.getGraphics());
		graphics.setRenderingHint( RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON );
		graphics.setBackground( new Color(0,0,0,255) );
		graphics.setColor( color );
		graphics.setStroke( new BasicStroke(1.0f) );

		count = 0;

		revs = (int)(values[3]*values[1])/gcd((int)values[0],(int)(values[3]*values[1]));
			
		oldx = values[0] + values[1] + values[2] + w/2;
		oldy = w/2;
	}
	
	public void setColor( Color color ){
		this.color = color;
		graphics.setColor( color );
	}


	double count;
	double n = 100.0;
	int revs;
	double oldx;
	double oldy;


	public void update(){
		if ( count++ < (int)n*revs ){
			if (count==(int)n*revs) values[4]=0.0;
			else values[4] = 2*Math.PI*count/n;
			values[5] = values[4]*(1.0+values[0]/values[1]);

			// setPoint();
			values[6] = w/2 + (values[0] + values[1] + values[3])*Math.cos(values[4]) + values[2]*Math.cos(values[5]);
			values[7] = w/2 - (values[0] + values[1] + values[3])*Math.sin(values[4]) - values[2]*Math.sin(values[5]);

			graphics.draw( new Line2D.Double( oldx, oldy, values[6], values[7] ) );
			oldx = values[6];
			oldy = values[7];

			try {
				Thread.sleep(1);
			} catch (InterruptedException e){
			}
		} else if ( count++ < (int)(n*revs + 2) ){
/*
			float[] matrix = new float[9];
			for (int i = 0; i < 9; i++) matrix[i] = 1.0f/9.0f;

			//BufferedImageOp blue = new ConvolveOp( new Kernel(20, 20, matrix), ConvolveOp.EDGE_NO_OP, null );
			ConvolveOp blur = new ConvolveOp( new Kernel(3, 3, matrix) );
			BufferedImage dest = new BufferedImage( (int)w, (int)w, BufferedImage.TYPE_INT_ARGB);
			image = blur.filter(image, null);
*/
		} else {
			reset();
		}
	}
}



public class SplashPanel extends JPanel implements MouseListener,Runnable{

	SpiroGraphApplet spiro;
	
	Spiro firstSpiro;
	
	double w;
	double h;

	boolean newBackground = true;
	boolean active = true;

	Thread thread;

	Color[] colors = {Color.red,Color.blue,Color.green,Color.cyan,Color.yellow,Color.magenta,Color.orange};

	public SplashPanel( SpiroGraphApplet spiro ){
		setBackground( Color.white );
		addMouseListener( this );
		
		this.spiro = spiro;
		firstSpiro = new Spiro();
		Spiro tmp = firstSpiro;
		for ( int i=1; i<colors.length; i++ ){
			tmp.next = new Spiro();
			tmp = tmp.next;
			tmp.setColor( colors[i] );
		}
		start();
	}
	
	public void start(){
		active = true;
		thread = new Thread(this);
		thread.start();
	}
	
	public void run(){
		while ( active ){
			repaint();
			try {
				Thread.sleep(50);
			} catch (InterruptedException e){
			}
		}
    }



	

    public void setup(){
    }


	public void paintComponent( Graphics graphics ){
		//float[] matrix = new float[9];
		//for (int i = 0; i < 9; i++) matrix[i] = 1.0f/9.0f;
		//BufferedImageOp blur = new ConvolveOp( new Kernel(3, 3, matrix) );


		// have a copy of the background on which to draw
		w = getWidth();
		h = getHeight();
		Graphics2D g = (Graphics2D)graphics;
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);

		g.setColor(Color.white);
		g.fill( new Rectangle2D.Double(0, 0, w, h) );
		
		Spiro tmp = firstSpiro;
		while ( tmp != null ){
			tmp.update();
			g.drawImage(tmp.image,(int)(tmp.x-tmp.w/2),(int)(tmp.y-tmp.w/2),this);
			//g.drawImage(blur.filter(tmp.image, null),(int)(tmp.x-tmp.w/2),(int)(tmp.y-tmp.w/2),this);
			if ( !tmp.active ){
				tmp.reset();
			}
			tmp = tmp.next;
		}
		
		g.setColor( new Color( 128,128,128,220 ) );
		g.setFont( new Font("Helvetica",Font.BOLD,18) );
		String str = "CLICK ANYWHERE TO BEGIN";
		g.drawString( str, (int)(w-g.getFontMetrics().stringWidth(str)-5), (int)(h-5) );
	}

	public void mouseClicked( MouseEvent me ){
		active = false;
		spiro.showFrame();
	}

	public void mouseEntered( MouseEvent me ){
	}

	public void mouseExited( MouseEvent me ){
	}

	public void mousePressed( MouseEvent me ){
	}

	public void mouseReleased(MouseEvent me){
	}	
}