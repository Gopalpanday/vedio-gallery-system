//David Little
//Cycloid Version 2.0
//Last Updated Oct. 7, 2000
//Compiled with JDK 1.0.2

//Bugs
//No known bugs

//Updates
//No planned updates

import java.awt.*;
import java.util.*;
import java.awt.geom.*;
import java.awt.event.*;
//import java.applet.*;
import javax.swing.*;
//import javax.swing.event.*;

class drawCycloid extends JPanel{

    final int R = 33;			//Radius of circle
    final int P = 10+R;			//Distance from outside of circle
    final int shift = 10;		//arbitrary shift in x-coordinate
    final int N = 100;			//Break up interval [0,4Pi] into N parts
    final double PI = Math.PI;		//3.14159
    Image offImage,backImage;
    Graphics2D offg;
    Graphics2D backg;
    double[] X,dX,dY;

    drawCycloid(){
		super();
		double theta;

		X = new double[N+1];
		dX = new double[N+1];
		dY = new double[N+1];
        for (int i=0; i<=N; i++){
            theta = 4*i*PI/N;
            X[i] = R+shift+R*theta;
            dX[i] = R*Math.sin(theta)/2;
            dY[i] = R*Math.cos(theta)/2;
        }
    }
   	
   	
    public void start(){
		backImage = createImage(500,190);
        backg = (Graphics2D)backImage.getGraphics();
		backg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
		backg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        drawBackGround();
        
        offImage = createImage(500,190);
        offg = (Graphics2D)offImage.getGraphics();
		offg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
        
        clear();
        draw(0);
    }


    public void paintComponent(Graphics g){
		//Graphics2D g = (Graphics2D)graphics;
		//g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
		g.drawImage(offImage,0,0,this);
    }
	

    public void draw(int c){
		clear();

		if (c<=1) c=0;
		if (c>=N-1) c=N;

        //draw curves
		offg.setStroke( new BasicStroke( 1.5f ) );
        for (int i=1; i<=c; i++){
            offg.setColor(Color.red);
            offg.draw( new Line2D.Double(X[i-1]-1*dX[i-1],R+P+1*dY[i-1],X[i]-1*dX[i],R+P+1*dY[i]) );
            offg.setColor(Color.green);
            offg.draw( new Line2D.Double(X[i-1]-2*dX[i-1],R+P+2*dY[i-1],X[i]-2*dX[i],R+P+2*dY[i]) );
            offg.setColor(Color.blue);
            offg.draw( new Line2D.Double(X[i-1]-3*dX[i-1],R+P+3*dY[i-1],X[i]-3*dX[i],R+P+3*dY[i]) );
        }

        //draw circle and lines
		offg.setStroke( new BasicStroke( 1.0f ) );
        offg.setColor(Color.black);
        offg.draw( new Ellipse2D.Double(X[c]-R,P,2*R,2*R) );
        offg.draw( new Line2D.Double(X[c]+2*dY[c],R+P+2*dX[c],X[c]-2*dY[c],R+P-2*dX[c]) );
        offg.draw( new Line2D.Double(X[c],R+P,X[c]-3*dX[c],R+P+3*dY[c]) );

        offg.setColor( Color.red );
        offg.fill( new Ellipse2D.Double(X[c]-1*dX[c]-2,R+P+1*dY[c]-2,5,5) );

        offg.setColor( Color.green );
        offg.fill( new Ellipse2D.Double(X[c]-2*dX[c]-2,R+P+2*dY[c]-2,5,5) );

        offg.setColor( Color.blue );
        offg.fill( new Ellipse2D.Double(X[c]-3*dX[c]-2,R+P+3*dY[c]-2,5,5) );

        repaint();
    }


    public void clear(){
        offg.setPaintMode();
        offg.setColor(Color.white);
        offg.fillRect(0,0,500,200);
        offg.drawImage(backImage,0,0,this);
    }
    
    
    public void drawBackGround(){
        String str;
        backg.setFont(new Font("Application",Font.PLAIN,10));
        
        //white background
        backg.setColor(Color.white);
        backg.fillRect(0,0,500,200);

        //draw grid
        backg.setColor(new Color(200,255,255));
        for (int i=-2;i<31;i++) backg.drawLine(shift+i*R/2+R,P-R,shift+i*R/2+R,3*R+P);
        for (int i=-2;i<7;i++) backg.drawLine(shift,2*R+P-i*R/2,shift+14*R+R/2,2*R+P-i*R/2);
        
        //draw axes
        backg.setColor(Color.black);
        backg.drawLine(shift+R,P-R,shift+R,3*R+P);
        backg.drawLine(shift,2*R+P,shift+14*R+R/2,2*R+P);
        for (int i=1; i<14; i++){
            str = ""+i;
            backg.drawString(str,shift+i*R+R-backg.getFontMetrics().stringWidth(str)/2,2*R+P+13);
            backg.drawLine(shift+i*R+R,2*R+P-2,shift+i*R+R,2*R+P+2);
        }
        for (int i=1; i<3; i++){
            str = ""+i;
            backg.drawString(str,shift+R-6-backg.getFontMetrics().stringWidth(str)/2,2*R+P+4-i*R);
            backg.drawLine(shift+R-2,2*R+P-i*R,shift+R+2,2*R+P-i*R);
        }
    }
}


public class Cycloid extends JApplet implements AdjustmentListener{

    static JScrollBar THETA;
    static drawCycloid drawcycloid;
  
    public void init(){
        getContentPane().setBackground(Color.white); 
        getContentPane().setLayout( new BorderLayout() );
        drawcycloid = new drawCycloid();

        THETA = new JScrollBar( JScrollBar.HORIZONTAL, 0, 1, 0, drawcycloid.N );

        getContentPane().add( "South", THETA );
        getContentPane().add( "Center", drawcycloid );
        
        drawcycloid.start();
		
		THETA.addAdjustmentListener( this );
    }
    
    
    public void start(){
        drawcycloid.draw(THETA.getValue());
    }
    
/*
    public boolean keyDown(Event e, int key){
        int n = THETA.getValue();
        if (key==' '){		//spacebar
            for (int i=n+1; i<=drawcycloid.N; i++){
                drawcycloid.draw(i);
                THETA.setValue(i);
                drawcycloid.repaint();
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ie){
                }
            }
        } else if (key==1006){		//left
            drawcycloid.draw(n-1);
            THETA.setValue(n-1);
        } else if (key==1007){		//right
            drawcycloid.draw(n+1);
            THETA.setValue(n+1);
        }
        return true;
    }
*/

	public void adjustmentValueChanged( AdjustmentEvent e ){
		Adjustable a = e.getAdjustable();
		if ( a.equals(THETA) ){
			drawcycloid.draw(THETA.getValue());
		}
	}
}
