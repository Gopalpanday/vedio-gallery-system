/**
 * @author David Little
 * @version drawGraph1.0
 * Last Updated Feb. 16, 1999
 * Compiled with JDK 1.0.2
 */
 
 
 
import java.awt.*;
import java.lang.*;
import java.util.*;


public class drawGraph extends Panel implements Runnable{

    final int H=1000, W=1200;
    double n=270;
    int v, count;
    Image offImage;
    Graphics offg;
    double[] center;
    double[] val, oldval;

    drawGraph(){
        super();
        setBackground(Color.white);
        center = new double[2];
        val = new double[8];
            val[0]=60.0;				//R
            val[1]=60.0;				//r
            val[2]=60.0;				//p
            val[3]=1.0;					//sign
            val[4]=0.0;					//theta
            val[5]=0.0;					//phi
            val[6]=W/2+val[0]+val[1]+val[2]+val[3];	//point.x
            val[7]=H/2;					//point.y
        recordValues();
    }

    public void run(){
        count=0;
        initializeValues();

        int revs = (int)(val[3]*val[1])/gcd((int)val[0],(int)(val[3]*val[1]));

        while (count++ < (int)n*revs){
            if (count==(int)n*revs) val[4] = 0.0;
            else val[4] = 2*Math.PI*count/n;
            val[5] = val[4]*(1+val[0]/val[1]);
            setPoint();

            if (SpiroGraph.hide.getLabel().equals("Hide")){
                drawCircle2(oldval);
                drawDot(oldval);
                drawLineToDot(oldval);
            }

            offg.setPaintMode();
            offg.setColor(SpiroGraph.COLOR);
            offg.drawLine((int)oldval[6],(int)oldval[7],
                          (int)val[6],(int)val[7]);
            offg.setXORMode(getBackground());
            offg.setColor(Color.black);

            if (SpiroGraph.hide.getLabel().equals("Hide")){
                drawCircle2(val);
                drawDot(val);
                drawLineToDot(val);
            }

            repaint();
            recordValues();

            try {
                Thread.sleep(5*(10-v));
            } catch (InterruptedException e){}
        }
        SpiroGraph.draw.setLabel("Draw");
        SpiroGraph.thread = new Thread(SpiroGraph.drawgraph);
    }

    public void update(Graphics g){
        paint(g);
    }

    public void paint(Graphics g){
        g.drawImage(offImage,(this.size().width-W)/2,(this.size().height-H)/2,this);
    }

    public void initializeValues(){
        val = new double[8];
            val[0]=SpiroGraph.RAD1.getValue();		//R
            val[1]=SpiroGraph.RAD2.getValue();		//r
            val[2]=SpiroGraph.POS.getValue();		//p
            if (val[1]<0) val[3]=-1.0; 
            else val[3]=1.0;				//sign
            val[4]=0.0;					//theta
            val[5]=0.0;					//phi
            val[6]=W/2+val[0]+val[1]+val[2]+val[3];	//point.x
            val[7]=H/2;					//point.y
        recordValues();
    }

    public void recordValues(){
        oldval = new double[val.length];
        for (int i=0; i<val.length; i++) oldval[i]=val[i];
    }

    public void setPoint(){
        setCenter(val);
        val[6] = center[0]+val[2]*Math.cos(val[5]);
        val[7] = center[1]-val[2]*Math.sin(val[5]);
    }

    public void setCenter(double[] d){
        center[0] = W/2+(d[0]+d[1]+d[3])*Math.cos(d[4]);
        center[1] = H/2-(d[0]+d[1]+d[3])*Math.sin(d[4]);
    }

    public void clear(){
        offg.setPaintMode();
        offg.setColor(getBackground());
        offg.fillRect(0,0,W,H);
        drawAxes();
    }

    public void drawAxes(){
        if (SpiroGraph.hide.getLabel().equals("Hide")){
            offg.setXORMode(getBackground());
            offg.setColor(Color.gray);
            offg.drawLine(W/2,0,W/2,H);
            offg.drawLine(0,H/2,W,H/2);
            offg.setColor(Color.black);
            drawCircle1(val);
            drawCircle2(val);
            drawDot(val);
            drawLineToDot(val);
        }
        repaint();
    }

    public int gcd(int x, int y){
        if (x%y == 0) return y;
        return gcd(y,x%y);
    }

    public void adjustCircle1(){
        if (SpiroGraph.hide.getLabel().equals("Hide")){
            drawCircle1(oldval);
            drawCircle1(val);
            adjustCircle2();
        } else recordValues();
    }

    public void adjustCircle2(){
        if (SpiroGraph.hide.getLabel().equals("Hide")){
            drawCircle2(oldval);
            drawCircle2(val);
            adjustDot();
        } else recordValues();
    }

    public void adjustDot(){
        if (SpiroGraph.hide.getLabel().equals("Hide")){
            drawDot(oldval);
            drawDot(val);
            adjustLineToDot();
        } else recordValues();
    }

    public void adjustLineToDot(){
        drawLineToDot(oldval);
        drawLineToDot(val);
        recordValues();
        repaint();
    }

    public void drawCircle1(double[] d){
        offg.drawOval((int)(W/2-d[0]),(int)(H/2-d[0]),
                      (int)(2*d[0]),(int)(2*d[0]));
    }

    public void drawCircle2(double[] d){ 
        setCenter(d);
        offg.drawOval((int)(center[0]-d[3]*d[1]),(int)(center[1]-d[3]*d[1]),
                      (int)(2*d[3]*d[1]),(int)(2*d[3]*d[1]));
    }

    public void drawDot(double[] d){
        setCenter(d);
        offg.fillOval((int)(center[0]+d[2]*Math.cos(d[5]))-2,
                      (int)(center[1]-d[2]*Math.sin(d[5]))-2,
                      5,5);
    }

    public void drawLineToDot(double[] d){
        setCenter(d);
        double side = d[3];
        if (d[2]<0) side = -1*d[3];

        offg.drawLine((int)(center[0]+side*d[1]*Math.cos(d[5])),
                      (int)(center[1]-side*d[1]*Math.sin(d[5])),
                      (int)d[6],(int)d[7]);
        setPoint();
    }
}

