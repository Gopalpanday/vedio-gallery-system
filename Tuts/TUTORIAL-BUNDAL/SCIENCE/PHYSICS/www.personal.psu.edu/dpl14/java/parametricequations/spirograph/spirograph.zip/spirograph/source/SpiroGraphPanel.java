import java.awt.*;
import java.awt.geom.*;
import java.awt.print.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;
	

public class SpiroGraphPanel extends JPanel implements Runnable,Printable{

	int H;
	int W;
	int count;
	double n;
	double revs;
	double ratio;
	double sum;
	double val2;

	Image offImage;
	Graphics2D offg;

	double[] center;
	double[] values;

	Thread thread;
	boolean active = false;
	
	SpiroGraphApplet applet;
	
	GeneralPath path;

	public SpiroGraphPanel( SpiroGraphApplet applet ){
		super();
		this.applet = applet;
		setBackground( Color.white );

		center = new double[2];		
		values = new double[10];

		initializeValues();
		setCenter();

		thread = new Thread(this);
	}
		

	public void start(){
		if ( !active ){
			active = true;
			initializeValues();
			n = (double)applet.RES.getValue();
			revs = values[3]*values[1]/gcd((int)values[0],(int)(values[3]*values[1]));

			ratio = 1.0+values[0]/values[1];
			sum = values[0] + values[1] + values[3];
			val2 = values[2];
			
			if ( applet.auto.isSelected() ){
				offg.setColor( Color.white );
				offg.fill( new Rectangle2D.Double( 0, 0, W, H ) );
			}
		}
		thread.start();
	}
		

	public void run(){
		path = new GeneralPath();
		path.moveTo( (float)values[6], (float)values[7] );
		
		while ( active && count++ < (int)(n*revs) ){
			if (count==(int)(n*revs)) values[4]=0.0;
			else values[4] = 2*Math.PI*count/n;
			values[5] = values[4]*(ratio);

			// setCenter();
			center[0] = W/2+(sum)*Math.cos(values[4]);
			center[1] = H/2-(sum)*Math.sin(values[4]);
			// setPoint();
			values[6] = center[0]+val2*Math.cos(values[5]);
			values[7] = center[1]-val2*Math.sin(values[5]);

			offg.setColor( applet.palette.getColor() );
			offg.draw( new Line2D.Double( values[8], values[9], values[6], values[7] ) );
			//path.lineTo( (float)values[6], (float)values[7] );
			values[8] = values[6];
			values[9] = values[7];

			if ( applet.show.isSelected() || !applet.auto.isSelected() )
				repaint();
			if ( applet.VEL.getValue()<10 ){
				try {
					Thread.sleep(200-20*applet.VEL.getValue());
				} catch (InterruptedException e){
				}
			}
		}
		repaint();

		if ( count >= (int)(n*revs) ){
			count = 0;
			active = false;
			applet.draw.setText( "Draw" );
			thread = new Thread(this);
		}
	}
	

	public int gcd(int x, int y){
		if ( x%y == 0 ) return y;
		return gcd(y,x%y);
	}


	public void paintComponent( Graphics graphics ){		
		Graphics2D g = (Graphics2D)graphics;
		g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);

		W = getWidth();
		H = getHeight();
		if ( offImage == null ){
			offImage = createImage(W,H);
			offg = (Graphics2D)offImage.getGraphics();
			offg.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
			clear();
		}
		//if ( path != null ) offg.draw( path );
		g.drawImage( offImage, 0, 0, this );
		if ( applet.show.isSelected() ){
			setCenter();
			drawCircles( g );
		}
	}

	public void pause(){
		active = false;
	}

	public void resume(){
		active = true;
		thread = new Thread(this);
		thread.start();
	}

	public void reset(){
		active = false;
		thread = new Thread(this);
		values[4]=0.0;
		values[5]=0.0;
		setCenter();
		setPoint();
		repaint();
		count = 0;
	}

	public void initializeValues(){
		values[0] = applet.RAD1.getValue();							// R
		values[1] = applet.RAD2.getValue();							// r
		values[2] = applet.POS.getValue();							// p
		values[3] = values[1] < 0 ? -1.0 : 1.0;						// sign
		values[4] = 0.0;											// theta
		values[5] = 0.0;											// phi
		values[6] = W/2 + values[0]+values[1]+values[2]+values[3];	// point.x
		values[7] = H/2;											// point.y
		values[8] = W/2 + values[0] + values[1] + values[2];		// old point.x
		values[9] = H/2;											// old point.y
	}

	public void clear(){
		path = new GeneralPath();
		offg.setColor( Color.white );
		offg.fill( new Rectangle2D.Double( 0, 0, W, H ) );
		offg.setColor( applet.palette.getColor() );
	}

	public void drawCircles( Graphics2D g ){
		g.setColor( Color.black );
		double c0 = center[0];
		double c1 = center[1];
		double v0 = values[0];
		double v1 = values[1];
		double v2 = values[2];
		double v5 = values[5];

		// draw fixed circle
		g.draw( new Ellipse2D.Double( W/2-v0,H/2-v0,2*v0,2*v0 ) );

		// draw moving circle
		g.setColor( new Color(0,0,0,50) );
		double d = values[1]*values[3];
		Ellipse2D ellipse = new Ellipse2D.Double( c0 - d, c1 - d, 2*d, 2*d );
		g.fill( ellipse  );
		g.setColor( Color.black );
		g.draw( ellipse );


		// draw line to dot
		d = (values[2]<0 ? -1.0 : 1.0)*values[3];
		g.draw( new Line2D.Double( c0 + d*v1*Math.cos(v5), c1 - d*v1*Math.sin(v5),
								   c0 + v2*Math.cos(v5), c1 - v2*Math.sin(v5) ) );

		// draw dot
		g.setColor( applet.palette.getColor() );
		ellipse = new Ellipse2D.Double( c0 + v2*Math.cos(v5) - 3,c1 - v2*Math.sin(v5) - 3, 7, 7 );
		g.fill( ellipse );
		g.setColor( Color.black );
		g.draw( ellipse );
	}

	public void setCenter( ){
		center[0] = W/2+(values[0]+values[1]+values[3])*Math.cos(values[4]);
		center[1] = H/2-(values[0]+values[1]+values[3])*Math.sin(values[4]);
	}
	
	public void setPoint(){
		values[6] = center[0]+values[2]*Math.cos(values[5]);
		values[7] = center[1]-values[2]*Math.sin(values[5]);
	}

	public int print(Graphics g, PageFormat pf, int pi) throws PrinterException {
		if (pi >= 1) {
			return Printable.NO_SUCH_PAGE;
		}
		g.drawImage( offImage, 0, 0, this );
		if ( applet.show.isSelected() ){
			drawCircles( (Graphics2D)g );
		}
		return Printable.PAGE_EXISTS;
	}
}