/**
 * @author David Little
 * @version SpiroGraph1.0
 * Last Updated Mar. 12, 1999
 * Compiled with JDK 1.0.2
 */
 
import java.applet.*;
import java.awt.*;

public class SpiroGraph extends Applet{

    static Panel p1,q1;
    static BorderLayout p0, q0;
    static drawGraph drawgraph;
    static Color COLOR;
    static Label rad1, rad2, pos, vel, res, X, Y, swatch, red, green, blue;
    static Scrollbar RAD1, RAD2, POS, VEL, RES, RED, GREEN, BLUE;
    static Button hide, clear, draw, reset;
    static Thread thread;

    public void init(){
        setLayout(new BorderLayout());
        drawgraph = new drawGraph();

        p1 = new Panel();
        p1.setLayout(new GridLayout(24,1));
        p1.add(rad1 = new Label("Radius1: " + 60));
        p1.add(RAD1 = new Scrollbar(Scrollbar.HORIZONTAL,60,5,5,155));
        p1.add(rad2 = new Label("Radius2: " + 60));
        p1.add(RAD2 = new Scrollbar(Scrollbar.HORIZONTAL,60,5,-59,155));
        p1.add(pos = new Label("Position: 60"));
        p1.add(POS = new Scrollbar(Scrollbar.HORIZONTAL,60,5,-300,300));
        p1.add(vel = new Label("Velocity: 5")); 
        p1.add(VEL = new Scrollbar(Scrollbar.HORIZONTAL,5,1,0,10));
        p1.add(res = new Label("Resolution: 90"+"   "));
        p1.add(RES = new Scrollbar(Scrollbar.HORIZONTAL,90,10,1,500));
        p1.add(new Label(" "));
        p1.add(hide = new Button("Hide"));
        p1.add(clear = new Button("Clear"));
        p1.add(reset = new Button("Reset"));
        p1.add(draw = new Button("Draw"));
        p1.add(new Label(" "));
        p1.add(swatch = new Label());
        p1.add(red = new Label("Red: 0"));
        p1.add(RED = new Scrollbar(Scrollbar.HORIZONTAL,0,1,0,255));
        p1.add(green = new Label("Green: 0"));
        p1.add(GREEN = new Scrollbar(Scrollbar.HORIZONTAL,0,1,0,255));
        p1.add(blue = new Label("Blue: 0")); 
        p1.add(BLUE = new Scrollbar(Scrollbar.HORIZONTAL,0,1,0,255));
        updateSwatch();

        q1 = new Panel();
        q1.setLayout(new GridLayout(1,2,0,0));
        q1.add(X = new Label("",Label.CENTER));
        q1.add(Y = new Label("",Label.CENTER));
        updateEqn();

        
        add("East",p1);
        add("Center",drawgraph);
        add("South",q1);

        drawgraph.offImage = createImage(drawgraph.W,drawgraph.H);
        drawgraph.offg = drawgraph.offImage.getGraphics();
        drawgraph.clear();

        thread = new Thread(drawgraph);
    }

    public void updateEqn(){
        int r = RAD2.getValue();
        int Rr = RAD1.getValue()+r;
        int p = POS.getValue();
        String s1 = "+", s2 = "+";

        if (r==0){
            X.setText("x(t)=undefined");
            Y.setText("y(t)=undefined");
        } else if (p==0){
            X.setText("x(t)="+Rr+"cos(t)");
            Y.setText("y(t)="+Rr+"sin(t)");
        } else {
            if (p<0 && r<0){
                p*=-1; r*=-1; s1="-";
            } else if (p<0 && r>0){
                p*=-1; s1="-"; s2="-";
            } else if (p>0 && r<0){
                r*=-1; s2="-";
            }
            X.setText("x(t)="+Rr+"cos(t)"+s1+p+"cos("+Rr+"t/"+r+")");
            Y.setText("y(t)="+Rr+"sin(t)"+s2+p+"sin("+Rr+"t/"+r+")");
        }
    }

    public void updateSwatch(){
        COLOR = new Color(RED.getValue(),GREEN.getValue(),BLUE.getValue());
        swatch.setBackground(COLOR);
        swatch.repaint();
    }

    public boolean handleEvent(Event e){
        if (e.target instanceof Scrollbar){
            if (e.target==RAD1){
                rad1.setText("Radius1: " + RAD1.getValue());
                int n = RAD2.getValue();
                int m = RAD1.getValue();
                if (n<2-m){
                    n=1-m;
                    RAD2.setValue(n);
                    rad2.setText("Radius2: " + n);
                    drawgraph.val[1] = n;
                }
                RAD2.setValues(RAD2.getValue(),RAD2.getVisible(),
                               2-m,RAD2.getMaximum());
                drawgraph.val[0] = RAD1.getValue();
                drawgraph.adjustCircle1();
            } else if (e.target==RAD2){
                rad2.setText("Radius2: " + RAD2.getValue());
                drawgraph.val[1] = RAD2.getValue();
                if (RAD2.getValue() < 0) drawgraph.val[3]=-1.0;
                else drawgraph.val[3]=1.0;
                drawgraph.adjustCircle2();
            } else if (e.target==POS){
                pos.setText("Position: " + POS.getValue());
                drawgraph.val[2] = POS.getValue();
                drawgraph.adjustDot();
            } else if (e.target==VEL){
                vel.setText("Velocity: " + VEL.getValue());
                drawgraph.v = VEL.getValue();
            } else if (e.target==RES){
                res.setText("Resolution: " + RES.getValue());
            } else if (e.target==RED){
                red.setText("Red: " + RED.getValue());
                updateSwatch();
            } else if (e.target==GREEN){
                green.setText("Green: " + GREEN.getValue());
                updateSwatch();
            } else if (e.target==BLUE){
                blue.setText("Blue: " + BLUE.getValue());
                updateSwatch();
            }
            updateEqn();
            return true;
        } 
        return super.handleEvent(e);
    }

    public boolean action(Event e, Object obj){
        if (e.target instanceof Button){
            if(RAD2.getValue()!=0){
                if (obj.equals("Draw")){
                    draw.setLabel("Pause");
                    drawgraph.n=(double)RES.getValue();
                    thread.start();
                } else if (obj.equals("Pause")){
                    thread.suspend();
                    draw.setLabel("Resume");
                } else if (obj.equals("Resume")){
                    thread.resume();
                    draw.setLabel("Pause");   
                }
            }

            if (obj.equals("Reset")){
                thread.stop();
                thread = new Thread(drawgraph);
                drawgraph.val[4]=0.0;
                drawgraph.val[5]=0.0;
                drawgraph.setPoint();
                drawgraph.adjustCircle2();
                draw.setLabel("Draw");
            } else if (obj.equals("Hide")){
                drawgraph.drawAxes();
                hide.setLabel("Show");
            } else if (obj.equals("Show")){
                hide.setLabel("Hide");
                drawgraph.drawAxes();
            } else if (obj.equals("Clear")){
                drawgraph.clear();
            }
            return true;
        }
        return super.handleEvent(e);
    }

    //public void componentResized(ComponentEvent e){
    //    start();
    //}

    public void start(){
        //this.resize(this.size());
        drawgraph.repaint();
    }

    public void paint(Graphics g){
    }   
}

