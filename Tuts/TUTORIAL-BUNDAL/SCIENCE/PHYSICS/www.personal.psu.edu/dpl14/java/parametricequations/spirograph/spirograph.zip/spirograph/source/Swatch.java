import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Swatch extends JPanel implements MouseListener{
		
	Color color;
	boolean active;
	boolean over;
	String name;
		
	Swatch next;
	
	Palette palette;
		
	public Swatch( Color color, String name,  Palette palette ){
		this.color = color;
		this.name = name;
		this.palette = palette;
		active = false;
		over = false;
		next = null;
		
		addMouseListener( this );
	}

	public void paintComponent( Graphics g ){
		int w = getWidth();
		int h = getHeight();
			
		g.setColor(color);
		g.fillRect(0,0,w,h);
		if ( active || over ){
			g.setColor(Color.black);
			g.drawRect(0,0,w-1,h-1);
		} 
	}
		
	public void mouseEntered( MouseEvent me ){
		over = true;
		repaint();
		palette.nameLabel.setText( name );
		palette.setBackground( color );
	}

	public void mouseReleased( MouseEvent me ){
	}

	public void mouseExited( MouseEvent me ){
		over = false;
		repaint();
		palette.nameLabel.setText( palette.current.name );
		palette.setBackground( palette.current.color );
	}

	public void mouseClicked( MouseEvent me ){
		palette.setColor( this );
	}

	public void mousePressed( MouseEvent me ){
	}
}