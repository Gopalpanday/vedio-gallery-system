import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import Geometry.*;

public class EuclideanPanel extends GeometricPanel{

	public EuclideanPanel( EuclideanToolbox toolbox ){
		super( toolbox );
		setBackground( Color.white );
	}
	
	public void addAngleBisector(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanAngleBisector((EuclideanPoint)selected1,(EuclideanPoint)selected2,(EuclideanPoint)selected3,color) );
		clearSelected();
	}

	public void addAngleTrisector(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanAngleTrisector((EuclideanPoint)selected1,(EuclideanPoint)selected2,(EuclideanPoint)selected3,color) );
		clearSelected();
	}

	public void addCentroid(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanCentroid((EuclideanPoint)selected1,(EuclideanPoint)selected2,(EuclideanPoint)selected3,color) );
		clearSelected();
	}

	public void addCircle(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanCircle((EuclideanPoint)selected1,(EuclideanPoint)selected2,color) );
		clearSelected();
	}

	public void addCircleFixedRadius(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanCircleFixedRad((EuclideanPoint)selected1,(EuclideanPoint)selected2,color) );
		clearSelected();
	}

	public void addCircumcenter(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanCircumcenter((EuclideanPoint)selected1,(EuclideanPoint)selected2,(EuclideanPoint)selected3,color) );
		clearSelected();
	}

	public void addCircumscribedCircle(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanCircumCircle((EuclideanPoint)selected1,(EuclideanPoint)selected2,(EuclideanPoint)selected3,color) );
		clearSelected();
	}

	public void addEquilateralTriangle(){
		color = toolbox.colorPalette.getColor();
		EuclideanCircle circle1 = new EuclideanCircle( (EuclideanPoint)selected1, (EuclideanPoint)selected2 );
		EuclideanCircle circle2 = new EuclideanCircle( (EuclideanPoint)selected2, (EuclideanPoint)selected1 );
		selected3 = new EuclideanCircleIntersect(circle1,circle2,1);
		selected3.color = color;

		addObject( (EuclideanPoint)selected3 );
		addObject( new EuclideanLineSegment((EuclideanPoint)selected1,(EuclideanPoint)selected2,color) );
		addObject( new EuclideanLineSegment((EuclideanPoint)selected2,(EuclideanPoint)selected3,color) );
		addObject( new EuclideanLineSegment((EuclideanPoint)selected3,(EuclideanPoint)selected1,color) );
		//addObject( new EuclideanEquilateralTriangle((EuclideanPoint)selected1,(EuclideanPoint)selected2,color) );
		clearSelected();
	}

	public void addEulerLine(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanEulerLine((EuclideanPoint)selected1,(EuclideanPoint)selected2,(EuclideanPoint)selected3,color) );
		clearSelected();
	}

	public void addIncenter(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanIncenter((EuclideanPoint)selected1,(EuclideanPoint)selected2,(EuclideanPoint)selected3,color) );
		clearSelected();
	}

	public void addInscribedCircle(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanInscribedCircle((EuclideanPoint)selected1,(EuclideanPoint)selected2,(EuclideanPoint)selected3,color) );
		clearSelected();
	}

	public void addIntersection(){
		color = toolbox.colorPalette.getColor();
		if ( selected1 instanceof EuclideanLine ){
			if ( selected2 instanceof EuclideanLine ){
				addObject( new EuclideanLineIntersect((EuclideanLine)selected1,(EuclideanLine)selected2,color) );
			} else {
				addObject( new EuclideanLCIntersect((EuclideanLine)selected1,(EuclideanCircle)selected2, 1,color) );
				addObject( new EuclideanLCIntersect((EuclideanLine)selected1,(EuclideanCircle)selected2, -1,color) );
			}
		} else {
			if ( selected2 instanceof EuclideanLine ){
				addObject( new EuclideanLCIntersect((EuclideanLine)selected2,(EuclideanCircle)selected1, 1,color) );
				addObject( new EuclideanLCIntersect((EuclideanLine)selected2,(EuclideanCircle)selected1, -1,color) );
			} else {
				addObject( new EuclideanCircleIntersect((EuclideanCircle)selected1,(EuclideanCircle)selected2,1,color) );
				addObject( new EuclideanCircleIntersect((EuclideanCircle)selected1,(EuclideanCircle)selected2,-1,color) );
			}
		}
		clearSelected();
	}

	public void addInversion(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanInversion((EuclideanPoint)selected1,(EuclideanCircle)selected2,color) );
		clearSelected();
	}

	public void addLine(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanLine((EuclideanPoint)selected1,(EuclideanPoint)selected2,color) );
		clearSelected();
	}

	public void addLineSegment(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanLineSegment((EuclideanPoint)selected1,(EuclideanPoint)selected2,color) );
		clearSelected();
	}

	public void addMidpoint(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanMidpoint((EuclideanPoint)selected1,(EuclideanPoint)selected2,color) );
		clearSelected();
	}

	public void addOrthocenter(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanOrthocenter((EuclideanPoint)selected1,(EuclideanPoint)selected2,(EuclideanPoint)selected3,color) );
		clearSelected();
	}

	public void addParallelLine(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanParallelLine((EuclideanPoint)selected1,(EuclideanLine)selected2,color) );
		clearSelected();
	}

	public void addPerpendicularLine(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanPerpLine((EuclideanPoint)selected1,(EuclideanLine)selected2,color) );
		clearSelected();
	}

	public void addPerpendicularBisector(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanPerpBisector((EuclideanLineSegment)selected1,color) );
		clearSelected();
	}

	public void addPoint(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanPoint(POINT,color) );
		// do not clearSelected()
	}

	public void addPointOnCircle(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanPointOnCircle((EuclideanCircle)selected1,new EuclideanPoint(POINT),color) );
		clearSelected();
	}

	public void addPointOnLine(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanPointOnLine((EuclideanLine)selected1,new EuclideanPoint(POINT),color) );
		clearSelected();
	}

	public void addProjection(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanProjection((EuclideanPoint)selected1,(EuclideanLine)selected2,color) );
		clearSelected();
	}
	
	public void addRay(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanRay((EuclideanPoint)selected1,(EuclideanPoint)selected2,color) );
		clearSelected();
	}

	public void addReflection(){
		color = toolbox.colorPalette.getColor();
		addObject( new EuclideanReflection((EuclideanPoint)selected1,(EuclideanLine)selected2,color) );
		clearSelected();
	}

	public void addSquare(){
		color = toolbox.colorPalette.getColor();
		EuclideanPoint A = (EuclideanPoint)selected1;
		EuclideanPoint B = (EuclideanPoint)selected2;

		EuclideanPoint C = new EuclideanPerpPoint( B, A, -1, color );
		addObject( C );
		EuclideanPoint D = new EuclideanPerpPoint( A, B, 1, color );
		addObject( D );

		addObject( new EuclideanLineSegment(A,B,color) );
		addObject( new EuclideanLineSegment(B,C,color) );
		addObject( new EuclideanLineSegment(C,D,color) );
		addObject( new EuclideanLineSegment(D,A,color) );
		//addObject( new EuclideanSquare((EuclideanPoint)selected1,(EuclideanPoint)selected2,color) );
		clearSelected();
	}


	/*
	Image offImage;
	Graphics offGraphics;
	Image backImage;
	Graphics2D background;
	public void update(Graphics g){
		w = getWidth();
		h = getHeight();

		if (offImage==null || offImage.getWidth(this) != w || offImage.getHeight(this) != h){
			offImage = this.createImage( w, h );
			offGraphics = offImage.getGraphics();
			backImage = this.createImage( w, h );
			background = (Graphics2D)backImage.getGraphics();
			background.setColor( getBackground() );
			background.fillRect( 0, 0, w, h );
		}

		offGraphics.setColor( getBackground() );
		offGraphics.fillRect( 0, 0, w, h );

		EuclideanObject tmp = lastObject;
		while ( tmp != null ){
			if ( tmp.isMarker ){
				background.setColor( tmp.color );
				tmp.draw( background );
			}
			tmp = tmp.previous;
		}
		offGraphics.drawImage( backImage, 0, 0, this );
		paint( offGraphics ); 

		g.drawImage( offImage, 0, 0, this );
	}*/


	public void drawBackground( Graphics2D g ){
		//g.setColor( getBackground() );
		//g.setColor( Color.white );
		//g.fill( new Rectangle2D.Double(0, 0, w, h) );

		if ( backImage == null ){
			backImage = this.createImage( w, h );
			background = (Graphics2D)backImage.getGraphics();
		} else if ( backImage.getWidth(this) != w || backImage.getHeight(this) != h ){
			backImage = this.createImage( w, h );
			background = (Graphics2D)backImage.getGraphics();
		}
		
		GeometricObject tmp = lastObject;
		// draw markers on background
		GeometricPoint p;
		double r = 0;
		if ( tmp != null ){
			r = tmp.radius/3;
		}
		while ( tmp != null ){
			if ( tmp.isMarker ){
				background.setColor( tmp.color );
				if ( tmp instanceof EuclideanPoint ){
					p = ((EuclideanPoint)tmp).getPoint();
					background.fill( new Arc2D.Double(p.x-r, p.y-r, 2*r, 2*r,0,360, Arc2D.OPEN) );
				} else {
					tmp.draw( background );
				}
			}
			tmp = tmp.previous;
		}
		g.drawImage( backImage, 0, 0, this );

	}



	public void mouseMoved(MouseEvent me){
		GeometricObject tmp = firstObject;
		EuclideanPoint p = new EuclideanPoint( me.getPoint() );
		over = null;

		if ( toolbox.type == GeometricObject.ANY ){ // give preference to points in this case
			while ( tmp != null && over == null ){ // first look for EuclideanPoint
				tmp.mouseOver = false;
				if ( tmp instanceof EuclideanPoint && tmp.isOver(p) ){
					tmp.mouseOver = true;
					over = tmp;
				}
				tmp = tmp.next;
			}
			if ( over == null ){ // next look for other EuclideanObjects
				tmp = firstObject;
				while ( tmp != null && over == null ){
					tmp.mouseOver = false;
					if ( !(tmp instanceof EuclideanPoint) && tmp.isOver(p) ){
						tmp.mouseOver = true;
						over = tmp;
					}
					tmp = tmp.next;
				}
			}
		} else {
			while ( tmp != null && over == null ){
				tmp.mouseOver = false;
				if ( tmp.isOver(p) ){
					switch ( toolbox.type ){
						case GeometricObject.POINT:
							if ( tmp instanceof EuclideanPoint ){
								Object s = toolbox.choice.getSelectedItem();
								if ( (s.equals("Point") && tmp.isMovable) || !s.equals("Point") ){
									tmp.mouseOver = true;
									over = tmp;
								}
							}
							break;
						case GeometricObject.LINE:
							if ( tmp instanceof EuclideanLine ){
								tmp.mouseOver = true;
								over = tmp;
							}
							break;
						case GeometricObject.LINE_SEGMENT:
							if ( tmp instanceof EuclideanLineSegment ){
								tmp.mouseOver = true;
								over = tmp;
							}
							break;
						case GeometricObject.CIRCLE:
							if ( tmp instanceof EuclideanCircle ){
								tmp.mouseOver = true;
								over = tmp;
							}
							break;
						case GeometricObject.LINE_OR_CIRCLE:
							if ( tmp instanceof EuclideanLine || tmp instanceof EuclideanCircle ){
								tmp.mouseOver = true;
								over = tmp;
							}
							break;
					}
				}
				tmp = tmp.next;
			}
		}


		// reset mouseOver on remaining objects
		while ( tmp != null ){
			tmp.mouseOver = false;
			tmp = tmp.next;
		}
		repaint();
	}

	public void mouseDragged(MouseEvent me){
		if ( over != null && over.isMovable ){
			if ( over instanceof EuclideanPointOnLine ){
				EuclideanPointOnLine X = (EuclideanPointOnLine) over;
				X.setPoint( new EuclideanPoint(me.getPoint()) );
				repaint();
			} else if ( over instanceof EuclideanPointOnCircle ){
				EuclideanPointOnCircle X = (EuclideanPointOnCircle) over;
				X.setPoint( new EuclideanPoint(me.getPoint()) );
				repaint();
			} else {
				over.setPoint( me.getPoint() );
				repaint();
			}
		}
	}	
}

