import java.awt.*;
import Geometry.*;

public class EuclideanLineIntersect extends EuclideanPoint{

	private EuclideanLine L1;
	private EuclideanLine L2;

	public EuclideanLineIntersect( EuclideanLine L1, EuclideanLine L2 ){
		this( L1, L2, Color.black );
	}

	public EuclideanLineIntersect( EuclideanLine L1, EuclideanLine L2, Color color ){
		super();
		this.L1 = L1;
		this.L2 = L2;
		this.color = color;
		this.isMovable = false;
	}

	public GeometricPoint getPoint(){
		GeometricPoint X = L1.getPoint( 1.0 ).subtract( L1.getPoint(0.0) );
		GeometricPoint Y = L2.getPoint( 1.0 ).subtract( L2.getPoint(0.0) );
		double c = X.cross( Y ).z;
		
		this.exists = false;
		if ( c != 0 ){
			GeometricPoint Z = L2.getPoint( 0.0 ).subtract( L1.getPoint(0.0) );
			double t = Z.cross(Y).z/c; //point of intersection on line L1
			double s = Z.cross(X).z/c; //point of intersection on line L2
			if ( L1 instanceof EuclideanLineSegment || L2 instanceof EuclideanLineSegment ){
				if ( L1 instanceof EuclideanLineSegment && ( t < 0 || t > 1 ) ){
					return new EuclideanPoint();
				}
				if ( L2 instanceof EuclideanLineSegment && ( s < 0 || s > 1 ) ){
					return new EuclideanPoint();
				}
			}
			this.exists = true;
			return L1.getPoint( t );
		} else {
			return new GeometricPoint();
		}
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == L1 || obj == L2 || L1.uses(obj) || L2.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( L1 );
		int b = GeometricPanel.getIndex( L2 );
		return "EUCLIDEAN_LINE_INTERSECTION(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}