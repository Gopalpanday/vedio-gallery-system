import java.awt.*;
import Geometry.*;

public class SphericalMidpoint extends SphericalPoint{

    private SphericalPoint A;
    private SphericalPoint B;

    public SphericalMidpoint( SphericalPoint A, SphericalPoint B ){
		this( A, B, Color.black );
    }

    public SphericalMidpoint( SphericalPoint A, SphericalPoint B, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.color = color;
		this.isMovable = false;
    }

    public GeometricPoint getPoint(){
		GeometricPoint P = A.add( B ).scale( .5 );
		this.exists = ( A.exists && B.exists );
		return P.scale( 1/Math.sqrt(P.dot(P)) );
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || A.uses(obj) || B.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		return "SPHERICAL_MIDPOINT(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}