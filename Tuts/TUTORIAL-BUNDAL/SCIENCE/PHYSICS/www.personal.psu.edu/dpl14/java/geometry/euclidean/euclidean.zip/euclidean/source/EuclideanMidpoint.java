import java.awt.*;
import Geometry.*;

public class EuclideanMidpoint extends EuclideanPoint{

	private EuclideanPoint A;
	private EuclideanPoint B;

	public EuclideanMidpoint( EuclideanPoint A, EuclideanPoint B ){
		this( A, B, Color.black );
	}

	public EuclideanMidpoint( EuclideanPoint A, EuclideanPoint B, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.color = color;
		this.isMovable = false;
	}

	public GeometricPoint getPoint(){
		GeometricPoint AP = A.getPoint();
		GeometricPoint BP = B.getPoint();
		exists = ( A.exists && B.exists );
		return new EuclideanPoint( (AP.x+BP.x)/2, (AP.y+BP.y)/2);
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || A.uses(obj) || B.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		return "EUCLIDEAN_MIDPOINT(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}