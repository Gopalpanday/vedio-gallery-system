import java.awt.*;
import Geometry.*;

public class EuclideanPointOnCircle extends EuclideanPoint{

	EuclideanCircle C;

	// theta is in degrees
	public EuclideanPointOnCircle( EuclideanCircle C, int theta){
		this( C, theta, Color.black );
	}

	public EuclideanPointOnCircle( EuclideanCircle C, int theta, Color color ){
		super();
		this.C = C;
		GeometricPoint X = C.getCenter();
		double radius = C.getRadius();
		this.x = radius*Math.cos(Math.PI*theta/180.0);
		this.y = -radius*Math.sin(Math.PI*theta/180.0);
		this.color = color;
		this.isMovable = true;
	}

	public EuclideanPointOnCircle( EuclideanCircle C, EuclideanPoint A ){
		this( C, A, Color.black );
	}

	public EuclideanPointOnCircle( EuclideanCircle C, EuclideanPoint A, Color color ){
		super();
		this.C = C;
		GeometricPoint X = C.getCenter();
		GeometricPoint Y = A.getPoint();
		this.x = Y.x-X.x;
		this.y = Y.y-X.y;
		this.color = color;
		this.isMovable = true;
	}

	public GeometricPoint getPoint(){
		GeometricPoint X = C.getCenter();
		this.exists = C.exists;
		double R = C.getRadius();
		double d = Math.sqrt( x*x + y*y );
		return new EuclideanPoint( X.x+R*x/d, X.y+R*y/d );
	}
	
	// under construction
	public int getTheta(){
		int out = 0; // not EXACTLY!!
		GeometricPoint X = C.getCenter();
		return out;
	}

	public void setPoint( EuclideanPoint A ){
		GeometricPoint P = getPoint();
		GeometricPoint X = C.getCenter();
		GeometricPoint Y = A.getPoint();
		this.x = Y.x-X.x;
		this.y = Y.y-X.y;
		X = getPoint();
		
		LinkedPoints tmp = firstPoint;
		while ( tmp.point != null ){
			tmp.point.translate( X.x-P.x, X.y-P.y );
			tmp = tmp.next;
		}
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == C || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int c = GeometricPanel.getIndex( C );
		return "EUCLIDEAN_POINT_ON_CIRCLE(" + c + "," + getTheta() + "," + GeometricToolbox.getColor( color ) +")";
	}
}