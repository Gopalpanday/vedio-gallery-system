import java.awt.*;
import Geometry.*;

public class SphericalProjection extends SphericalPoint{

	SphericalPoint A;
	SphericalLine L;

	public SphericalProjection( SphericalPoint A, SphericalLine L ){
		this( A, L, Color.black );
	}

	public SphericalProjection( SphericalPoint A, SphericalLine L, Color color ){
		super();
		this.A = A;
		this.L = L;
		this.color = color;
		this.isMovable = false;
	}

	public GeometricPoint getPoint(){
		SphericalPoint X = new SphericalPoint( L.A.getPoint() );
		SphericalPoint Y = new SphericalPoint( L.B.getPoint() );
		SphericalPoint C = new SphericalPoint( X.cross(Y) );
		GeometricPoint P = A.getPoint();
		SphericalPoint axis = new SphericalPoint( C.cross(P) );
		P.rotate( Math.PI/2 - C.distance(A), axis );
		this.exists = ( L.exists && A.exists );
		return P;
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == L || A.uses(obj) || L.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int l = GeometricPanel.getIndex( L );
		return "SPHERICAL_PROJECTION(" + a + "," + l + "," + GeometricToolbox.getColor( color ) +")";
	}
}