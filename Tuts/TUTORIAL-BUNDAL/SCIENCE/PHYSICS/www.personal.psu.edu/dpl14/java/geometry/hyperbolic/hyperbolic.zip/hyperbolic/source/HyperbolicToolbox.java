import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import Geometry.*;

public class HyperbolicToolbox extends GeometricToolbox{
        
    public void init(){
		contentpane = this.getContentPane();
		setup();
		
		contentpane.add( "Center", panel = new HyperbolicPanel( this ) );
		    
		int i=1;
		while ( getParameter("object_"+i) != null ){
			first = panel.firstObject; // so that getObject knows where to start looking
			panel.addObject( parseObject(getParameter("object_"+i)) );
			i++;
		}

		panel.requestFocus();
	}
    
    
    public GeometricObject parseObject( String s ){
		int openparan = s.indexOf("(");
		String object = s.substring(0,openparan).trim();
		StringTokenizer st = new StringTokenizer( s.substring(openparan+1,s.length()-1), "," );
		HyperbolicPoint X;
		HyperbolicPoint Y;
		HyperbolicPoint Z;
		HyperbolicLine L;
		HyperbolicLine M;
		HyperbolicCircle C;
		HyperbolicCircle D;
		int I;

		if ( object.equals("CIRCLE") ){
			X = (HyperbolicPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (HyperbolicPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new HyperbolicCircle( X, Y, getColor(st.nextToken()) );
		} else if ( object.equals("CIRCLE_INTERSECTION") ){
			C = (HyperbolicCircle)getObject( Integer.parseInt( st.nextToken() ) );
			D = (HyperbolicCircle)getObject( Integer.parseInt( st.nextToken() ) );
			I = Integer.parseInt(st.nextToken());
			return new HyperbolicCircleIntersect( C, D, I, getColor(st.nextToken()) );
		} else if ( object.equals("INVERSION") ){
			X = (HyperbolicPoint)getObject( Integer.parseInt( st.nextToken() ) );
			C = (HyperbolicCircle)getObject( Integer.parseInt( st.nextToken() ) );
			return new HyperbolicInversion( X, C, getColor(st.nextToken()) );
		} else if ( object.equals("LINE") ){
			X = (HyperbolicPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (HyperbolicPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new HyperbolicLine( X, Y, getColor(st.nextToken()) );
		} else if ( object.equals("LINE_INTERSECTION") ){
			L = (HyperbolicLine)getObject( Integer.parseInt( st.nextToken() ) );
			M = (HyperbolicLine)getObject( Integer.parseInt( st.nextToken() ) );
			return new HyperbolicLineIntersect( L, M, getColor(st.nextToken()) );
		} else if ( object.equals("LINE_CIRCLE_INTERSECTION") ){
			L = (HyperbolicLine)getObject( Integer.parseInt( st.nextToken() ) );
			C = (HyperbolicCircle)getObject( Integer.parseInt( st.nextToken() ) );
			I = Integer.parseInt(st.nextToken());
			return new HyperbolicLCIntersect( L, C, I, getColor(st.nextToken()) );
		} else if ( object.equals("LINE_SEGMENT") ){
			X = (HyperbolicPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (HyperbolicPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new HyperbolicLineSegment( X, Y, getColor(st.nextToken()) );
		} else if ( object.equals("MIDPOINT") ){
			X = (HyperbolicPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (HyperbolicPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new HyperbolicMidpoint( X, Y, getColor(st.nextToken()) );
		} else if ( object.equals("PERPENDICULAR_LINE") ){
			X = (HyperbolicPoint)getObject( Integer.parseInt( st.nextToken() ) );
			L = (HyperbolicLine)getObject( Integer.parseInt( st.nextToken() ) );
			return new HyperbolicPerpLine( X, L, getColor(st.nextToken()) );
		} else if ( object.equals("POINT") ){
			double x = Double.parseDouble( st.nextToken() );
			double y = Double.parseDouble( st.nextToken() );
			return new HyperbolicPoint( x, y, getColor(st.nextToken()) );
		} else if ( object.equals("PROJECTION") ){
			X = (HyperbolicPoint)getObject( Integer.parseInt( st.nextToken() ) );
			L = (HyperbolicLine)getObject( Integer.parseInt( st.nextToken() ) );
			return new HyperbolicProjection( X, L, getColor(st.nextToken()) );
		} else if ( object.equals("REFLECTION") ){
			X = (HyperbolicPoint)getObject( Integer.parseInt( st.nextToken() ) );
			L = (HyperbolicLine)getObject( Integer.parseInt( st.nextToken() ) );
			return new HyperbolicReflection( X, L, getColor(st.nextToken()) );
		} else {
			return null;
		}
    }
}