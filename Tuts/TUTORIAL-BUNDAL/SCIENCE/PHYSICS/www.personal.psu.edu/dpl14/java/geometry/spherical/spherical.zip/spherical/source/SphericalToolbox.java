import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import Geometry.*;

public class SphericalToolbox extends GeometricToolbox{
    
    public void init(){
		contentpane = this.getContentPane();
		setup();
		
		contentpane.add( "Center", panel = new SphericalPanel( this ) );
		    
		int i=1;
		while ( getParameter("object_"+i) != null ){
			first = panel.firstObject; // so that getObject knows where to start looking
			panel.addObject( parseObject(getParameter("object_"+i)) );
			i++;
		}

		panel.requestFocus();
    }
    
    
    public GeometricObject parseObject( String s ){
		int openparan = s.indexOf("(");
		String object = s.substring(0,openparan).trim();
		StringTokenizer st = new StringTokenizer( s.substring(openparan+1,s.length()-1), "," );
		SphericalPoint X;
		SphericalPoint Y;
		SphericalPoint Z;
		SphericalLine L;
		SphericalLine M;
		SphericalCircle C;
		SphericalCircle D;
		int I;

		if ( object.equals("ANTIPODE") ){
			X = (SphericalPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new SphericalAntipode( X, getColor(st.nextToken()) );
		} else if ( object.equals("CIRCLE") ){
			X = (SphericalPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (SphericalPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new SphericalCircle( X, Y, getColor(st.nextToken()) );
		} else if ( object.equals("CIRCLE_INTERSECTION") ){
			C = (SphericalCircle)getObject( Integer.parseInt( st.nextToken() ) );
			D = (SphericalCircle)getObject( Integer.parseInt( st.nextToken() ) );
			I = Integer.parseInt(st.nextToken());
			return new SphericalCircleIntersect( C, D, I, getColor(st.nextToken()) );
		} else if ( object.equals("LINE") ){
			X = (SphericalPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (SphericalPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new SphericalLine( X, Y, getColor(st.nextToken()) );
		} else if ( object.equals("LINE_INTERSECTION") ){
			L = (SphericalLine)getObject( Integer.parseInt( st.nextToken() ) );
			M = (SphericalLine)getObject( Integer.parseInt( st.nextToken() ) );
			return new SphericalLineIntersect( L, M, getColor(st.nextToken()) );
		} else if ( object.equals("LINE_CIRCLE_INTERSECTION") ){
			L = (SphericalLine)getObject( Integer.parseInt( st.nextToken() ) );
			C = (SphericalCircle)getObject( Integer.parseInt( st.nextToken() ) );
			I = Integer.parseInt(st.nextToken());
			return new SphericalLCIntersect( L, C, I, getColor(st.nextToken()) );
		} else if ( object.equals("LINE_SEGMENT") ){
			X = (SphericalPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (SphericalPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new SphericalLineSegment( X, Y, getColor(st.nextToken()) );
		} else if ( object.equals("MIDPOINT") ){
			X = (SphericalPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (SphericalPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new SphericalMidpoint( X, Y, getColor(st.nextToken()) );
		} else if ( object.equals("PERPENDICULAR_LINE") ){
			X = (SphericalPoint)getObject( Integer.parseInt( st.nextToken() ) );
			L = (SphericalLine)getObject( Integer.parseInt( st.nextToken() ) );
			return new SphericalPerpLine( X, L, getColor(st.nextToken()) );
		} else if ( object.equals("POINT") ){
			double x = Double.parseDouble( st.nextToken() );
			double y = Double.parseDouble( st.nextToken() );
			double z = Double.parseDouble( st.nextToken() );
			return new SphericalPoint( x, y, z, getColor(st.nextToken()) );
		} else if ( object.equals("PROJECTION") ){
			X = (SphericalPoint)getObject( Integer.parseInt( st.nextToken() ) );
			L = (SphericalLine)getObject( Integer.parseInt( st.nextToken() ) );
			return new SphericalProjection( X, L, getColor(st.nextToken()) );
		} else {
			return null;
		}
    }
}