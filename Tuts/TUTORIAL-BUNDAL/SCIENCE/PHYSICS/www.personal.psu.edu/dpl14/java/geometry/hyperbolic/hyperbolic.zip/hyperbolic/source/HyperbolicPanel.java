import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import Geometry.*;

public class HyperbolicPanel extends GeometricPanel{
    

    public HyperbolicPanel( HyperbolicToolbox toolbox){
		super( toolbox );
    }
       
	public void addCircle(){
		color = toolbox.colorPalette.getColor();
		addObject( new HyperbolicCircle((HyperbolicPoint)selected1,(HyperbolicPoint)selected2,color) );
		clearSelected();
	}

	public void addIntersection(){
		color = toolbox.colorPalette.getColor();
		if ( selected1 instanceof HyperbolicLine ){
			if ( selected2 instanceof HyperbolicLine ){
				addObject( new HyperbolicLineIntersect((HyperbolicLine)selected1,(HyperbolicLine)selected2,color) );
			} else {
				addObject( new HyperbolicLCIntersect((HyperbolicLine)selected1,(HyperbolicCircle)selected2, 1,color) );
				addObject( new HyperbolicLCIntersect((HyperbolicLine)selected1,(HyperbolicCircle)selected2, -1,color) );
			}
		} else {
			if ( selected2 instanceof HyperbolicLine ){
				addObject( new HyperbolicLCIntersect((HyperbolicLine)selected2,(HyperbolicCircle)selected1, 1,color) );
				addObject( new HyperbolicLCIntersect((HyperbolicLine)selected2,(HyperbolicCircle)selected1, -1,color) );
			} else {
				addObject( new HyperbolicCircleIntersect((HyperbolicCircle)selected1,(HyperbolicCircle)selected2,1,color) );
				addObject( new HyperbolicCircleIntersect((HyperbolicCircle)selected1,(HyperbolicCircle)selected2,-1,color) );
			}
		}
		clearSelected();
	}

	public void addInversion(){
		color = toolbox.colorPalette.getColor();
		//addObject( new HyperbolicInversion((HyperbolicPoint)selected1,(HyperbolicCircle)selected2,color) );
		clearSelected();
	}

    public void addLine(){
		color = toolbox.colorPalette.getColor();
		addObject( new HyperbolicLine((HyperbolicPoint)selected1,(HyperbolicPoint)selected2,color) );
		clearSelected();
    }

    public void addLineSegment(){
		color = toolbox.colorPalette.getColor();
		addObject( new HyperbolicLineSegment((HyperbolicPoint)selected1,(HyperbolicPoint)selected2,color) );
		clearSelected();
    }
    
    public void addMidpoint(){
		color = toolbox.colorPalette.getColor();
		addObject( new HyperbolicMidpoint((HyperbolicPoint)selected1,(HyperbolicPoint)selected2,color) );
		clearSelected();
    }
    
    
    public void addPerpendicularLine(){
		color = toolbox.colorPalette.getColor();
		addObject( new HyperbolicPerpLine((HyperbolicPoint)selected1,(HyperbolicLine)selected2,color) );
		clearSelected();
    }

    public void addPoint(){
		HyperbolicPoint point = toHyperbolicPoint(POINT);
		point.color = toolbox.colorPalette.getColor();
		addObject( point );
		// do not clearSelected()
    }
    
    public void addProjection(){
		color = toolbox.colorPalette.getColor();
		addObject( new HyperbolicProjection((HyperbolicPoint)selected1,(HyperbolicLine)selected2,color) );
		clearSelected();
    }



	public void addReflection(){
		color = toolbox.colorPalette.getColor();
		addObject( new HyperbolicReflection((HyperbolicPoint)selected1,(HyperbolicLine)selected2,color) );
		clearSelected();
	}
    
    
	public void drawBackground( Graphics2D g ){
		int D = Math.min( w, h );
		g.setColor( getBackground() );
		g.fill( new Rectangle2D.Double(0, 0, w, h) );
		g.setColor( Color.white );
		g.setStroke( new BasicStroke( 2.0f ) );
		g.draw( new Arc2D.Double( w/2-D/2, h/2-D/2, D, D, 0, 360, Arc2D.OPEN ) );
		g.fill( new Arc2D.Double( w/2-D/2, h/2-D/2, D, D, 0, 360, Arc2D.OPEN ) );
	}
    
    public HyperbolicPoint toHyperbolicPoint( Point p ){
		double R = Math.min( w/2.0, h/2.0 );
		double x = (p.x-w/2.0)/R;
		double y = (h/2.0-p.y)/R;
		double d = Math.sqrt( x*x + y*y );
		if ( d >= 1.0 ){
			x /= 1.0000000001*d;
			y /= 1.0000000001*d;
		}

		return new HyperbolicPoint( x, y );
    }

/*
	public void mouseMoved(MouseEvent me){
	    HyperbolicObject tmp = first;
	    over = null;
	    while ( tmp != null && over == null ){
		tmp.mouseOver = false;
		
		if ( tmp.isOver(toHyperbolicPoint(me.getPoint())) ){
		    switch( toolbox.type ){
			case HyperbolicObject.POINT:
			    if (tmp instanceof HyperbolicPoint ){
				String s = toolbox.choice.getSelectedItem();
				if ( (s.equals("Point") && tmp.isMovable) || !s.equals("Point") ){
				    tmp.mouseOver = true;
				    over = tmp;
				}
			    }
			    break;
			case HyperbolicObject.LINE:
			    if (tmp instanceof HyperbolicLine ){
			    }
			    break;
		    }
		}
		tmp = tmp.next;
	    }
	    repaint();
	}
*/


    public void mouseMoved(MouseEvent me){
		GeometricObject tmp = firstObject;
		HyperbolicPoint p = toHyperbolicPoint( me.getPoint() );
		over = null;

	    if ( toolbox.type == GeometricObject.ANY ){ // give preference to points in this case
			while ( tmp != null && over == null ){ // first look for SphericalPoint
				tmp.mouseOver = false;
				if ( tmp instanceof HyperbolicPoint && tmp.isOver(p) ){
					tmp.mouseOver = true;
					over = tmp;
				}
				tmp = tmp.next;
			}
			if ( over == null ){ // next look for other Spherical Objects
				tmp = firstObject;
				while ( tmp != null && over == null ){
					tmp.mouseOver = false;
					if ( !(tmp instanceof HyperbolicPoint) && tmp.isOver(p) ){
						tmp.mouseOver = true;
						over = tmp;
					}
					tmp = tmp.next;
				}
			}
		} else {
			while ( tmp != null && over == null ){
				tmp.mouseOver = false;
				if ( tmp.isOver( p ) ){
					switch ( toolbox.type ){
						case GeometricObject.POINT:
							if ( tmp instanceof HyperbolicPoint ) {
								Object s = toolbox.choice.getSelectedItem();
								if ( (s.equals("Point") && tmp.isMovable) || !s.equals("Point") ){
									tmp.mouseOver = true;
									over = tmp;
								}
							}
							break;
						case GeometricObject.LINE:
							if ( tmp instanceof HyperbolicLine ) {
								tmp.mouseOver = true;
								over = tmp;
							}
							break;
						case GeometricObject.CIRCLE:
							if ( tmp instanceof HyperbolicCircle ) {
								tmp.mouseOver = true;
								over = tmp;
							}
							break;
						case GeometricObject.LINE_OR_CIRCLE:
							if ( tmp instanceof HyperbolicLine || tmp instanceof HyperbolicCircle ){
								tmp.mouseOver = true;
								over = tmp;
							}
							break;
					}
				}
				tmp = tmp.next;
			}
		}
	
		// reset mouseOver on remaining objects
		while ( tmp != null ){
			tmp.mouseOver = false;
			tmp = tmp.next;
		}

		repaint();
    }
	
	public void mouseDragged(MouseEvent me){
	    if ( over != null && over.isMovable() ){
			over.setPoint( toHyperbolicPoint(me.getPoint()) );
			repaint();
	    }
	}
}

