import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import Geometry.*;

public class SphericalPanel extends GeometricPanel{
    
    static GeometricPoint XAXIS;
    static GeometricPoint YAXIS;
    static GeometricPoint ZAXIS;

    public SphericalPanel( GeometricToolbox toolbox ){
		super( toolbox );

		XAXIS = new GeometricPoint( 1.0, 0.0, 0.0 );
		YAXIS = new GeometricPoint( 0.0, 1.0, 0.0 );
		ZAXIS = new GeometricPoint( 0.0, 0.0, 1.0 );
    }


    public void addAntipode(){
		color = toolbox.colorPalette.getColor();
		addObject( new SphericalAntipode((SphericalPoint)selected1,color) );
		clearSelected();
    }
    
    public void addCircle(){
		color = toolbox.colorPalette.getColor();
		addObject( new SphericalCircle((SphericalPoint)selected1,(SphericalPoint)selected2,color) );
		clearSelected();
    }

    public void addIntersection(){
		color = toolbox.colorPalette.getColor();
		if ( selected1 instanceof SphericalLine ){
			if ( selected2 instanceof SphericalLine ){
				addObject( new SphericalLineIntersect((SphericalLine)selected1,(SphericalLine)selected2,1,color) );
				addObject( new SphericalLineIntersect((SphericalLine)selected1,(SphericalLine)selected2,-1,color) );
			} else {
				addObject( new SphericalLCIntersect((SphericalLine)selected1,(SphericalCircle)selected2, 1,color) );
				addObject( new SphericalLCIntersect((SphericalLine)selected1,(SphericalCircle)selected2, -1,color) );
			}
		} else {
			if ( selected2 instanceof SphericalLine ){
				addObject( new SphericalLCIntersect((SphericalLine)selected2,(SphericalCircle)selected1, 1,color) );
				addObject( new SphericalLCIntersect((SphericalLine)selected2,(SphericalCircle)selected1, -1,color) );
			} else {
				addObject( new SphericalCircleIntersect((SphericalCircle)selected1,(SphericalCircle)selected2,1,color) );
				addObject( new SphericalCircleIntersect((SphericalCircle)selected1,(SphericalCircle)selected2,-1,color) );
			}
		}
		clearSelected();
    }
    
    public void addLine(){
		color = toolbox.colorPalette.getColor();
		addObject( new SphericalLine((SphericalPoint)selected1,(SphericalPoint)selected2,color) );
		clearSelected();
    }

    public void addLineSegment(){
		color = toolbox.colorPalette.getColor();
		addObject( new SphericalLineSegment((SphericalPoint)selected1,(SphericalPoint)selected2,color) );
		clearSelected();
    }
    
    public void addMidpoint(){
		color = toolbox.colorPalette.getColor();
		addObject( new SphericalMidpoint((SphericalPoint)selected1,(SphericalPoint)selected2,color) );
		clearSelected();
    }

    public void addPerpendicularLine(){
		color = toolbox.colorPalette.getColor();
		addObject( new SphericalPerpLine((SphericalPoint)selected1,(SphericalLine)selected2,color) );
		clearSelected();
    }

    public void addPoint(){
		SphericalPoint point = toSphericalPoint(POINT);
		point.color = toolbox.colorPalette.getColor();
		addObject( point );
		// do not clearSelected()
    }
    
    public void addProjection(){
		color = toolbox.colorPalette.getColor();
		addObject( new SphericalProjection((SphericalPoint)selected1,(SphericalLine)selected2,color) );
		clearSelected();
    }

	public void drawBackground( Graphics2D g ){
		int D = Math.min( w, h );
		g.setColor( getBackground() );
		g.fill( new Rectangle2D.Double(0, 0, w, h) );
		g.setColor( Color.white );
		g.setStroke( new BasicStroke( 2.0f ) );
		g.draw( new Arc2D.Double( w/2-D/2, h/2-D/2, D, D, 0, 360, Arc2D.OPEN ) );
		g.fill( new Arc2D.Double( w/2-D/2, h/2-D/2, D, D, 0, 360, Arc2D.OPEN ) );
	}


    public SphericalPoint toSphericalPoint( Point p ){	
		if ( ZAXIS.z != 0 ){
			// Convert screen point p to unit disk
			double R = Math.min( w/2.0, h/2.0 );
			double x = (p.x-w/2.0)/R;
			double y = (h/2.0-p.y)/R;
	
			double d = Math.sqrt( x*x + y*y );
			if (d < 1) d=1.0;
			x /= d;
			y /= d;

			// get z coordinate on xy-plane
			double z = (-ZAXIS.x*x - ZAXIS.y*y)/ZAXIS.z;
	    
			// get intersection of sphere with line through (x,y,0) and (x,y,z)
			GeometricPoint X = new GeometricPoint( x, y, Math.sqrt( 1 - x*x - y*y ) );
	    
			// project (x,y,c) onto xy-plane
			GeometricPoint P = X.subtract( ZAXIS.scale(X.dot(ZAXIS)) );
	    
			// convert P to xyz coordinates
			double A = P.dot( XAXIS );
			double B = P.dot( YAXIS );
			double C = X.subtract( P ).dot( ZAXIS );
	    
			//return new GeometricPoint( A, B, C, Color.blue );
			return new SphericalPoint( A, B, C );
		} else {
			System.out.println("CRAPPPP");
			return new SphericalPoint();
		}
    }

	/*
    public void mouseClicked(MouseEvent me){
		if ( over != null ){
			if ( toolbox.choice.getSelectedItem().equals("None") ){
				over.color = toolbox.colorPalette.getColor();
			} else {
				if ( !over.isSelected ){
					if ( selected1 == null ){
						selected1 = over;
						selected1.isSelected = true;
					} else if ( selected2 == null ) {
						selected2 = over;
						selected2.isSelected = true;
					} else if ( selected3 == null ) {
						selected3 = over;
						selected3.isSelected = true;
					}
					toolbox.nextInstruction();
				}
			}
		} else if ( toolbox.choice.getSelectedItem().equals("Point") ){
			double R = Math.min( w/2.0, h/2.0 );
			double x = ((double)me.getPoint().x-w/2.0)/R;
			double y = (h/2.0-(double)me.getPoint().y)/R;
			if ( x*x + y*y < 1 ){
				addPoint();
			}
		}
		repaint();
    }
*/

    public void mouseMoved(MouseEvent me){
		GeometricObject tmp = firstObject;
		SphericalPoint p = toSphericalPoint( me.getPoint() );
		over = null;

	    if ( toolbox.type == GeometricObject.ANY ){ // give preference to points in this case
			while ( tmp != null && over == null ){ // first look for SphericalPoint
				tmp.mouseOver = false;
				if ( tmp instanceof SphericalPoint && tmp.isOver(p) ){
					tmp.mouseOver = true;
					over = tmp;
				}
				tmp = tmp.next;
			}
			if ( over == null ){ // next look for other Spherical Objects
				tmp = firstObject;
				while ( tmp != null && over == null ){
					tmp.mouseOver = false;
					if ( !(tmp instanceof SphericalPoint) && tmp.isOver(p) ){
						tmp.mouseOver = true;
						over = tmp;
					}
					tmp = tmp.next;
				}
			}
		} else {
			while ( tmp != null && over == null ){
				tmp.mouseOver = false;
				if ( tmp.isOver( p ) ){
					switch ( toolbox.type ){
						case GeometricObject.POINT:
							if ( tmp instanceof SphericalPoint ) {
								Object s = toolbox.choice.getSelectedItem();
								if ( (s.equals("Point") && tmp.isMovable) || !s.equals("Point") ){
									tmp.mouseOver = true;
									over = tmp;
								}
							}
							break;
						case GeometricObject.LINE:
							if ( tmp instanceof SphericalLine ) {
								tmp.mouseOver = true;
								over = tmp;
							}
							break;
						case GeometricObject.CIRCLE:
							if ( tmp instanceof SphericalCircle ) {
								tmp.mouseOver = true;
								over = tmp;
							}
							break;
						case GeometricObject.LINE_OR_CIRCLE:
							if ( tmp instanceof SphericalLine || tmp instanceof SphericalCircle ){
								tmp.mouseOver = true;
								over = tmp;
							}
							break;
					}
				}
				tmp = tmp.next;
			}
		}
	
		// reset mouseOver on remaining objects
		while ( tmp != null ){
			tmp.mouseOver = false;
			tmp = tmp.next;
		}

		repaint();
    }
    	
    public void mouseDragged(MouseEvent me){
		if ( over != null && over.isMovable() ){
			double R = Math.min( getWidth()/2.0, getHeight()/2.0 );
			double x = ((double)me.getPoint().x-getWidth()/2.0)/R;
			double y = (getHeight()/2.0-(double)me.getPoint().y)/R;
			double d = Math.sqrt(x*x + y*y);
			if ( d < 1 ){
				over.setPoint( toSphericalPoint(me.getPoint()) );
			repaint();
			}
		} else {
			Point P = me.getPoint();
			double d = Math.sqrt((POINT.x - P.x)*(POINT.x-P.x) + (POINT.y-P.y)*(POINT.y-P.y));
			double degrees = Math.PI*d/180.0;
			SphericalPoint axis = new SphericalPoint( (P.y-POINT.y)/d , (P.x-POINT.x)/d, 0);
			XAXIS.rotate( degrees, axis );
			YAXIS.rotate( degrees, axis );
			ZAXIS.rotate( degrees, axis );
			POINT = me.getPoint();
			repaint();
		}
    }	
}