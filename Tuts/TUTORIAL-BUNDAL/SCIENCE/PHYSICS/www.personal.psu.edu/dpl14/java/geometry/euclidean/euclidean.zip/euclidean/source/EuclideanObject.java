import java.awt.*;
import Geometry.*;

public abstract class EuclideanObject extends GeometricObject{

	public EuclideanObject(){
		this.threshold = 5;
	}

/*
	public abstract boolean uses( EuclideanObject obj );

	public abstract double distance( Point p );

	public abstract void draw( Graphics2D g );
	
	public abstract String toString();*/
}