import java.awt.*;
import Geometry.*;

public class EuclideanInversion extends EuclideanPoint{

	EuclideanPoint A;
	EuclideanCircle C;

	public EuclideanInversion( EuclideanPoint A, EuclideanCircle C ){
		this( A, C, Color.black );
	}

	public EuclideanInversion( EuclideanPoint A, EuclideanCircle C, Color color ){
		super();
		this.A = A;
		this.C = C;
		this.color = color;
		this.isMovable = false;
	}

	public GeometricPoint getPoint(){
		GeometricPoint X = C.getCenter();
		double r = C.getRadius();
		double d = A.distance( X );
		this.exists = ( C.exists && A.exists );
		return X.add( A.subtract(X).scale(r*r/d/d) );
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == C || A.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int c = GeometricPanel.getIndex( C );
		return "EUCLIDEAN_INVERSION(" + a + "," + c + "," + GeometricToolbox.getColor( color ) +")";
	}
}