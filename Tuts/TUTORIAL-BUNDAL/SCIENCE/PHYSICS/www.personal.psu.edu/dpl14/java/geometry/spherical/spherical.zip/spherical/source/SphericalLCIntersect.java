import java.awt.*;
import Geometry.*;

public class SphericalLCIntersect extends SphericalPoint{

    private SphericalLine L;
    private SphericalCircle C;
    private int sign;

    public SphericalLCIntersect( SphericalLine L, SphericalCircle C ){
		this( L, C, 1, Color.black );
    }

    public SphericalLCIntersect( SphericalLine L, SphericalCircle C, Color color ){
		this( L, C, 1, color );
    }

    public SphericalLCIntersect( SphericalLine L, SphericalCircle C, int sign ){
		this( L, C, sign, Color.black );
    }

    public SphericalLCIntersect( SphericalLine L, SphericalCircle C, int sign, Color color ){
		super();
		this.L = L;
		this.C = C;
		this.sign = sign;
		this.color = color;
		this.isMovable = false;
    }

    public GeometricPoint getPoint(){
		SphericalPoint AcrossB = new SphericalPoint( L.A.cross( L.B ) );
			AcrossB = (SphericalPoint)( AcrossB.scale( 1/AcrossB.length() ) );
		GeometricPoint cross = AcrossB.cross( C.getCenter() );
		double dot = C.getCenter().dot( C.X.getPoint() );
	
		if ( cross.z != 0 ){
System.out.print( "exists...." );
			double a = cross.dot( cross );
			double b = 2*dot*AcrossB.cross(cross).z;
			double c = dot*dot*(AcrossB.x*AcrossB.x + AcrossB.y*AcrossB.y) - cross.z*cross.z;
	    
			double z = ( -b + sign*Math.sqrt(b*b-4*a*c) )/(2*a);
			double x = ( cross.x*z - AcrossB.y*dot )/cross.z;
			double y = ( cross.y*z + AcrossB.x*dot )/cross.z;
			
			if ( L instanceof SphericalLineSegment ){
				if ( true ){
					this.exists = true;
					return new SphericalPoint( x, y, z );
				} else {
					this.exists = false;
					return new SphericalPoint( );
				}
			} else {
				this.exists = true;
				return new SphericalPoint( x, y, z );
			}
		} else {
System.out.print( "DOES NOT exist..." );
			this.exists = false;
			return new SphericalPoint( );
		}
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == L || obj == C || L.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( L );
		int b = GeometricPanel.getIndex( C );
		return "SPHERICAL_LINE_CIRCLE_INTERSECT(" + a + "," + b + "," + SphericalToolbox.getColor( color ) +")";
	}
}