import java.awt.*;
import Geometry.*;

public class HyperbolicReflection extends HyperbolicPoint{

	HyperbolicPoint A;
	HyperbolicLine L;

	public HyperbolicReflection( HyperbolicPoint A, HyperbolicLine L ){
		this( A, L, Color.black );
	}

	public HyperbolicReflection( HyperbolicPoint A, HyperbolicLine L, Color color ){
		super();
		this.A = A;
		this.L = L;
		this.color = color;
		this.isMovable = false;
	}

	public GeometricPoint getPoint(){
		GeometricPoint X = L.getCenter();
		double r = Math.sqrt( X.x*X.x + X.y*X.y - 1 );
		double d = A.distance( X );
		this.exists = ( L.exists && A.exists );
		return X.add( A.subtract(X).scale(r*r/d/d) );
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == L || A.uses(obj) || L.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int l = GeometricPanel.getIndex( L );
		return "HYPERBOLIC_REFLECTION(" + a + "," + l + "," + GeometricToolbox.getColor( color ) +")";
	}
}