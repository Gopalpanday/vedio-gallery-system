import java.awt.*;
import Geometry.*;

public class HyperbolicLCIntersect extends HyperbolicPoint{

    private HyperbolicLine L;
    private HyperbolicCircle C;
    private int sign;

    public HyperbolicLCIntersect( HyperbolicLine L, HyperbolicCircle C ){
		this( L, C, 1, Color.black );
    }

    public HyperbolicLCIntersect( HyperbolicLine L, HyperbolicCircle C, Color color ){
		this( L, C, 1, color );
    }

    public HyperbolicLCIntersect( HyperbolicLine L, HyperbolicCircle C, int sign ){
		this( L, C, sign, Color.black );
    }

    public HyperbolicLCIntersect( HyperbolicLine L, HyperbolicCircle C, int sign, Color color ){
		super();
		this.L = L;
		this.C = C;
		this.sign = sign;
		this.color = color;
		this.isMovable = false;
    }

    public GeometricPoint getPoint(){
		GeometricPoint X = C.getCenter();
		GeometricPoint Y = L.getCenter();
		double R = C.getRadius();
		double r = Math.sqrt( Y.x*Y.x + Y.y*Y.y - 1 );
		double d = X.distance( Y );
		if ( R+r < d || Math.abs(R-r) > d || d == 0){
			this.exists = false;
			return new GeometricPoint();
		} else {
			this.exists = true;
			double cos = (R*R-r*r+d*d)/(2*R*d);
			GeometricPoint P = X.add( Y.subtract(X).scale(R*cos/d) );
			double z = sign*R*Math.sqrt( 1 - cos*cos );
			return new GeometricPoint( P.x - z*(X.y-Y.y)/d, P.y - z*(Y.x-X.x)/d );
		}
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == L || obj == C || L.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( L );
		int b = GeometricPanel.getIndex( C );
		return "HYPERBOLIC_LINE_CIRCLE_INTERSECT(" + a + "," + b + "," + HyperbolicToolbox.getColor( color ) +")";
	}
}