import java.awt.*;
import Geometry.*;

public class EuclideanCircleIntersect extends EuclideanPoint{

    private EuclideanCircle A;
    private EuclideanCircle B;
    private int sign;

    public EuclideanCircleIntersect( EuclideanCircle A, EuclideanCircle B ){
		this( A, B, 1, Color.black );
    }

    public EuclideanCircleIntersect( EuclideanCircle A, EuclideanCircle B, int sign ){
		this( A, B, sign, Color.black );
    }

    public EuclideanCircleIntersect( EuclideanCircle A, EuclideanCircle B, int sign, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.sign = sign;
		this.color = color;
		this.isMovable = false;
    }

    public GeometricPoint getPoint(){
		EuclideanPoint C = new EuclideanPoint( A.getCenter() );
		EuclideanPoint c = new EuclideanPoint( B.getCenter() );
		double R = A.getRadius();
		double r = B.getRadius();
		double d = C.distance( c );
		if ( R+r < d || Math.abs(R-r) > d || d == 0){
			this.exists = false;
			return new GeometricPoint();
		} else {
			this.exists = true;
			double cos = (R*R-r*r+d*d)/(2*R*d);
			GeometricPoint P = new EuclideanLine( C, c ).getPoint( R*cos/d );
			double z = sign*R*Math.sqrt( 1 - cos*cos );
			return new GeometricPoint( P.x - z*(C.y-c.y)/d, P.y - z*(c.x-C.x)/d );
		}
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || A.uses(obj) || B.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		return "EUCLIDEAN_CIRCLE_INTERSECTION(" + a + "," + b + "," + sign + "," + GeometricToolbox.getColor( color ) +")";
	}
}