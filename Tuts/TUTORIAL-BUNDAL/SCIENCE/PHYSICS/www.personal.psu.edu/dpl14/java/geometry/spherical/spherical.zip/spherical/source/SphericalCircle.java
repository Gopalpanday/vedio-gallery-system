import java.awt.*;
import java.awt.geom.*;
import Geometry.*;

public class SphericalCircle extends SphericalObject{

    SphericalPoint CENTER;      // center of circle
    SphericalPoint X;		// point on circle


    public SphericalCircle(){
		this( new SphericalPoint( 1, 0, 0 ), new SphericalPoint( 0, 1, 0 ), Color.black );
    }

    public SphericalCircle( SphericalPoint center, SphericalPoint x ){
		this( center, x, Color.black );
    }
    
    public SphericalCircle( SphericalPoint center, SphericalPoint x, Color color ){
		super();
		this.CENTER = center;    
		this.X = x; 
		this.color = color;
    }
    
    public GeometricPoint getCenter(){
		return CENTER.getPoint();
    }
    
    public GeometricPoint getPoint( double radians ){
		double r = getRadius();
		GeometricPoint C = getCenter();
		this.exists = ( X.exists && CENTER.exists );
		return new GeometricPoint( C.x + r*Math.cos(radians), C.y - r*Math.sin(radians) );
    }
    
    public double getRadius(){
		return getCenter().distance( X.getPoint() );
    }

    public double distance( GeometricPoint p ){
		//return 5*Math.abs( CENTER.dot(p) - CENTER.dot(X) );
		return Math.abs( CENTER.distance(X) - CENTER.distance(p) );
    }
    
    public void draw( Graphics2D g ){
		int W = SphericalPanel.w;
		int H = SphericalPanel.h;
		double R = Math.min(W/2.0,H/2.0);
		
		// Convert points to screen coordinates
		GeometricPoint C = CENTER.toScreenCoordinates();
		GeometricPoint P = X.toScreenCoordinates();
		this.exists = ( CENTER.exists && X.exists );
		if ( this.exists ){
			double d = C.dot(P);
		
			double theta = Math.asin(Math.abs(C.x)/Math.sqrt(C.x*C.x+C.y*C.y));
			if ( C.x > 0 ){
				if ( C.y > 0 ){
					theta *= -1;
				} else {
					theta += Math.PI;
				}
			} else if ( C.y < 0 ){
				theta = Math.PI - theta;
			}
			if ( d < 0 ) theta += Math.PI;

			double rx = R*Math.sqrt(1-d*d);
			double ry = Math.abs(C.z*rx);

			AffineTransform rot = AffineTransform.getRotateInstance( -theta, W/2+R*C.x*d, H/2-R*C.y*d);
			g.setTransform(rot);
			float linewidth = 2.0f;
			if ( mouseOver || isSelected ){
				linewidth = 3.5f;
			}
	
			double T = C.z*d/Math.sqrt((1-d*d)*(C.x*C.x+C.y*C.y));
			if ( T <= -1.0 ) {
				g.setColor( Color.lightGray );
				g.setStroke( new BasicStroke(linewidth,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,10.0f,dash,0.0f) );
				g.draw( new Arc2D.Double(W/2-rx+R*C.x*d, H/2-ry-R*C.y*d, 2*rx, 2*ry, 0, 360, Arc2D.OPEN ) );
			} else if ( T >= 1.0 ){
				g.setColor( this.color );
				g.setStroke( new BasicStroke( linewidth ) );
				g.draw( new Arc2D.Double(W/2-rx+R*C.x*d, H/2-ry-R*C.y*d, 2*rx, 2*ry, 0, 360, Arc2D.OPEN ) );
			} else {
				T = 180*Math.abs(Math.asin(T))/Math.PI;
				if ( C.z*d > 0 ){
					g.setColor( Color.lightGray );
					g.setStroke( new BasicStroke(linewidth,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,10.0f,dash,0.0f) );
					g.draw( new Arc2D.Double(W/2-rx+R*C.x*d, H/2-ry-R*C.y*d, 2*rx, 2*ry, T, 180-2*T, Arc2D.OPEN ) );

					g.setColor( this.color );
					g.setStroke( new BasicStroke( linewidth ) );    
					g.draw( new Arc2D.Double(W/2-rx+R*C.x*d, H/2-ry-R*C.y*d, 2*rx, 2*ry, 180-T, 180+2*T, Arc2D.OPEN ) );
				} else {
					g.setColor( Color.lightGray );
					g.setStroke( new BasicStroke(linewidth,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,10.0f,dash,0.0f) );
					g.draw( new Arc2D.Double(W/2-rx+R*C.x*d, H/2-ry-R*C.y*d, 2*rx, 2*ry, 180-T, 180+2*T, Arc2D.OPEN ) );

					g.setColor( this.color );
					g.setStroke( new BasicStroke( linewidth ) );    
					g.draw( new Arc2D.Double(W/2-rx+R*C.x*d, H/2-ry-R*C.y*d, 2*rx, 2*ry, T, 180-2*T, Arc2D.OPEN ) );
				}
			}
			g.setTransform( new AffineTransform() );
			g.setStroke( new BasicStroke( 1.0f ) );
		}
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == CENTER || obj == X || CENTER.uses(obj) || X.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( CENTER );
		int b = GeometricPanel.getIndex( X );
		return "SPHERICAL_CIRCLE(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}