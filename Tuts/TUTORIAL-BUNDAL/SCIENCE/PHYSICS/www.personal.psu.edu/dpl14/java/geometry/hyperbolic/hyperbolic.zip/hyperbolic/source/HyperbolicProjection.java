import java.awt.*;
import Geometry.*;

public class HyperbolicProjection extends HyperbolicPoint{

	HyperbolicPoint A;
	HyperbolicLine L;

	public HyperbolicProjection( HyperbolicPoint A, HyperbolicLine L ){
		this( A, L, Color.black );
	}

	public HyperbolicProjection( HyperbolicPoint A, HyperbolicLine L, Color color ){
		super();
		this.A = A;
		this.L = L;
		this.color = color;
		this.isMovable = false;
	}

	public GeometricPoint getPoint(){
		HyperbolicReflection X = new HyperbolicReflection( A, L );
		HyperbolicMidpoint M = new HyperbolicMidpoint( A, X );
		return M.getPoint();
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == L || A.uses(obj) || L.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int l = GeometricPanel.getIndex( L );
		return "HYPERBOLIC_PROJECTION(" + a + "," + l + "," + GeometricToolbox.getColor( color ) +")";
	}
}