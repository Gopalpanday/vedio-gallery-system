import java.awt.*;
import Geometry.*;

public class EuclideanCircumcenter extends EuclideanPoint{

	EuclideanPoint A;
	EuclideanPoint B;
	EuclideanPoint C;

	public EuclideanCircumcenter( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C ){
		this( A, B, C, Color.black );
	}

	public EuclideanCircumcenter( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.C = C;
		this.color = color;
		this.isMovable = false;
	}

	public GeometricPoint getPoint(){
		GeometricPoint X = A.getPoint();
		GeometricPoint Y = B.getPoint();
		GeometricPoint Z = C.getPoint();
		this.exists = ( A.exists && B.exists && C.exists );
		double s = X.subtract(Z).dot( Y.subtract(Z) )/X.subtract(Z).cross( X.subtract(Y) ).z;
		return new GeometricPoint( (X.x + Y.x - (X.y - Y.y)*s)/2.0, (X.y + Y.y + (X.x - Y.x)*s)/2.0 );
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || obj == C || A.uses(obj) || B.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		int c = GeometricPanel.getIndex( C );
		return "EUCLIDEAN_CIRCUMCENTER(" + a + "," + b + "," + c + "," + GeometricToolbox.getColor( color ) +")";
	}
}