import java.awt.*;
import Geometry.*;

public class EuclideanPerpLine extends EuclideanLine{

	EuclideanLine L;

	public EuclideanPerpLine( EuclideanPoint A, EuclideanLine L ){
		this( A, L, Color.black );
	}

	public EuclideanPerpLine( EuclideanPoint A, EuclideanLine L, Color color ){
		super();
		this.A = A;
		this.L = L;
		this.color = color;
	}

	public double distance( GeometricPoint p ){
		GeometricPoint X = A.getPoint();
		GeometricPoint Y = L.getPoint( 1.0 ).subtract( L.getPoint(0.0) );
		EuclideanPoint Z = new EuclideanPoint( X.x + Y.y, X.y - Y.x );
		EuclideanLine l = new EuclideanLine( A, Z );
		return l.distance( p );
	}

	public void draw( Graphics2D g ){
		GeometricPoint X = A.getPoint();
		GeometricPoint Y = L.getPoint( 1.0 ).subtract( L.getPoint(0.0) );
		this.exists = ( A.exists && L.exists );
		if ( this.exists ){
			EuclideanPoint Z = new EuclideanPoint( X.x + Y.y, X.y - Y.x );
			EuclideanLine l = new EuclideanLine( A, Z, color );
			l.mouseOver = this.mouseOver;
			l.isSelected = this.isSelected;
			l.draw( g );
		}
	}

	public GeometricPoint getPoint( double t ){
		GeometricPoint X = A.getPoint();
		GeometricPoint Y = L.getPoint( 1.0 ).subtract( L.getPoint(0.0) );
		EuclideanPoint Z = new EuclideanPoint( X.x + Y.y, X.y - Y.x );
		EuclideanLine l = new EuclideanLine( A, Z );
		return l.getPoint( t );
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == L || A.uses(obj) || L.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int l = GeometricPanel.getIndex( L );
		return "EUCLIDEAN_PERPENDICULAR_LINE(" + a + "," + l + "," + GeometricToolbox.getColor( color ) +")";
	}
}