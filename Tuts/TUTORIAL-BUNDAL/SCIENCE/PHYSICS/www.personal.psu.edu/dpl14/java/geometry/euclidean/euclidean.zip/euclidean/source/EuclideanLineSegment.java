import java.awt.*;
import java.awt.geom.*;
import Geometry.*;

public class EuclideanLineSegment extends EuclideanLine{

	public EuclideanLineSegment( EuclideanPoint A, EuclideanPoint B ){
		this( A, B, Color.black );
	}

	public EuclideanLineSegment( EuclideanPoint A, EuclideanPoint B, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.color = color;
	}

	public double distance( GeometricPoint p ){
		double dot = A.subtract(B).dot(A.subtract(p));
		double distAB = Math.pow( A.distance(B), 2 );
		if ( dot>0 && dot<distAB ){
			return Math.sqrt( Math.pow( A.distance(p), 2 ) - dot*dot/distAB );
		} else {
			return 100000.0;
		}
	}

	public void draw( Graphics2D g ){
		GeometricPoint X = A.getPoint();
		GeometricPoint Y = B.getPoint();
		this.exists = ( A.exists && B.exists );
		if ( this.exists ){
			g.setStroke( new BasicStroke(2.0f) );
			if ( mouseOver || isSelected ){
				g.setStroke( new BasicStroke(3.5f) );
			}
			g.setColor( color );
			g.draw( new Line2D.Double(X.x, X.y, Y.x, Y.y) );
			g.setStroke( new BasicStroke(1.0f) );
		}
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		return "EUCLIDEAN_LINE_SEGMENT(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}