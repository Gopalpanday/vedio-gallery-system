import java.awt.*;
import Geometry.*;

public class HyperbolicCircleIntersect extends HyperbolicPoint{

    private HyperbolicCircle A;
    private HyperbolicCircle B;
    private int sign;

    public HyperbolicCircleIntersect( HyperbolicCircle A, HyperbolicCircle B ){
		this( A, B, 1, Color.black );
    }

    public HyperbolicCircleIntersect( HyperbolicCircle A, HyperbolicCircle B, Color color ){
		this( A, B, 1, color );
    }

    public HyperbolicCircleIntersect( HyperbolicCircle A, HyperbolicCircle B, int sign ){
		this( A, B, sign, Color.black );
    }

    public HyperbolicCircleIntersect( HyperbolicCircle A, HyperbolicCircle B, int sign, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.sign = sign;
		this.color = color;
		this.isMovable = false;
    }


    public GeometricPoint getPoint(){
		GeometricPoint C = A.getCenter();
		GeometricPoint c = B.getCenter();
		double R = A.getRadius();
		double r = B.getRadius();
		double d = C.distance( c );
		if ( R+r < d || Math.abs(R-r) > d || d == 0){
			this.exists = false;
			return new GeometricPoint();
		} else {
			this.exists = true;
			double cos = (R*R-r*r+d*d)/(2*R*d);
			GeometricPoint P = C.add( c.subtract(C).scale(R*cos/d) );
			double z = sign*R*Math.sqrt( 1 - cos*cos );
			return new GeometricPoint( P.x - z*(C.y-c.y)/d, P.y - z*(c.x-C.x)/d );
		}
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || A.uses(obj) || B.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		return "HYPERBOLIC_CIRCLE_INTERSECT(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}