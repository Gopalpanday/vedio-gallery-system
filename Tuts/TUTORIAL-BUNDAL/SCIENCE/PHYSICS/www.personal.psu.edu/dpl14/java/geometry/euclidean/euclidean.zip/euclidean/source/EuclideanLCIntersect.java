import java.awt.*;
import Geometry.*;

public class EuclideanLCIntersect extends EuclideanPoint{

	private EuclideanLine L;
	private EuclideanCircle C;
	private int sign;

	public EuclideanLCIntersect( EuclideanLine L, EuclideanCircle C ){
		this( L, C, 1, Color.black );
	}

	public EuclideanLCIntersect( EuclideanLine L, EuclideanCircle C, int sign ){
		this( L, C, sign, Color.black );
	}

	public EuclideanLCIntersect( EuclideanLine L, EuclideanCircle C, int sign, Color color ){
		super();
		this.L = L;
		this.C = C;
		this.sign = sign;
		this.color = color;
		this.isMovable = false;
	}

	public GeometricPoint getPoint(){
		GeometricPoint A = L.getPoint( 0.0 );
		GeometricPoint B = L.getPoint( 1.0 );
		GeometricPoint X = C.getCenter();
		exists = ( A.exists && B.exists && X.exists );
		double rad = Math.pow( C.getRadius(), 2 );
		double dot = A.subtract( X ).dot( B.subtract(A) );
		double  ab = A.subtract( B ).dot( A.subtract(B) );
		double  ax = A.subtract( X ).dot( A.subtract(X) );
		if ( dot*dot - ab*(ax-rad) < 0 ){
			this.exists = false;
			return new EuclideanPoint();
		} else {
			double t = (-dot + sign*Math.sqrt(dot*dot - ab*(ax-rad)))/ab;
			if ( L instanceof EuclideanLineSegment ){
				if ( t >= 0.0 && t <= 1.0 ){
					this.exists = true;
					return L.getPoint( t );
				} else {
					this.exists = false;
					return new EuclideanPoint();
				}
			} else {
				this.exists = true;
				return L.getPoint( t );
			}
		}
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == L || obj == C || L.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int l = GeometricPanel.getIndex( L );
		int c = GeometricPanel.getIndex( C );
		return "EUCLIDEAN_LINE_CIRCLE_INTERSECTION(" + l + "," + c + "," + sign + "," + GeometricToolbox.getColor( color ) +")";
	}
}