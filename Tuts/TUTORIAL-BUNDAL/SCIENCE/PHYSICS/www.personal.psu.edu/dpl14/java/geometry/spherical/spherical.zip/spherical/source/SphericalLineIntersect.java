import java.awt.*;
import Geometry.*;

public class SphericalLineIntersect extends SphericalPoint{

    private SphericalLine L1;
    private SphericalLine L2;
    private int sign;
    
    public SphericalLineIntersect( SphericalLine L1, SphericalLine L2 ){
		this( L1, L2, 1, Color.black );
    }
    
    public SphericalLineIntersect( SphericalLine L1, SphericalLine L2, Color color ){
		this( L1, L2, 1, color );
    }
    
    public SphericalLineIntersect( SphericalLine L1, SphericalLine L2, int sign ){
		this( L1, L2, sign, Color.black );
    }
    
    public SphericalLineIntersect( SphericalLine L1, SphericalLine L2, int sign, Color color ){
		super();
		this.L1 = L1;
		this.L2 = L2;
		this.sign = sign;
		this.color = color;
		this.isMovable = false;
    }
    
    public GeometricPoint getPoint(){
		GeometricPoint P = L1.A.cross( L1.B ).cross( L2.A.cross(L2.B) );
		this.exists = ( L1.exists && L2.exists );
		return P.scale( sign/P.length() );
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == L1 || obj == L2 || L1.uses(obj) || L2.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( L1 );
		int b = GeometricPanel.getIndex( L2 );
		return "SPHERICAL_LINE_INTERSECT(" + a + "," + b + "," + sign + "," +  GeometricToolbox.getColor( color ) +")";
	}
}