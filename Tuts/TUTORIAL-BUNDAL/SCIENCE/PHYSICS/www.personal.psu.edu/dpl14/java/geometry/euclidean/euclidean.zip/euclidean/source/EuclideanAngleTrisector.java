import java.awt.*;
import Geometry.*;

public class EuclideanAngleTrisector extends EuclideanLine{
    
    public EuclideanAngleTrisector( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C ){
		this( A, B, C, Color.black );
    }

    public EuclideanAngleTrisector( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.C = C;
		this.color = color;
    }


    //compute the angle (in radians) abc
    public double angle(){
		double d1 = A.distance( B );
		double d2 = B.distance( C );
		double dot = A.subtract( B ).dot( C.subtract(B) );
		double cross = A.subtract( B ).cross( C.subtract(B) ).z;
	
		double out = Math.asin( cross/(d1*d2) );

		if ( dot < 0){
			if ( cross < 0 ){
				out = -Math.PI - out;
			} else {
				out = Math.PI - out;
			}
		}
		return -out;
    }

    public GeometricPoint getPoint( double t ){
		double angle = angle()/3.0;
		GeometricPoint P = A.getPoint();
		GeometricPoint Q = B.getPoint();
		this.exists = ( A.exists && B.exists && C.exists );		
		double x = Q.x + (P.x-Q.x)*Math.cos(angle) + (P.y-Q.y)*Math.sin(angle);
		double y = Q.y - (P.x-Q.x)*Math.sin(angle) + (P.y-Q.y)*Math.cos(angle);
		EuclideanLine l = new EuclideanLine( B, new EuclideanPoint( x, y ) );
		return l.getPoint( t );
    }
    
    public double distance( GeometricPoint p ){
		double angle = angle()/3.0;
		GeometricPoint P = A.getPoint();
		GeometricPoint Q = B.getPoint();
		double x = Q.x + (P.x-Q.x)*Math.cos(angle) + (P.y-Q.y)*Math.sin(angle);
		double y = Q.y - (P.x-Q.x)*Math.sin(angle) + (P.y-Q.y)*Math.cos(angle);
		EuclideanLine l = new EuclideanLine( B, new EuclideanPoint( x, y ) );
		return l.distance( p );
    }
    
    public void draw( Graphics2D g ){
		double angle = angle()/3.0;
		GeometricPoint P = A.getPoint();
		GeometricPoint Q = B.getPoint();
		this.exists = ( A.exists && B.exists && C.exists );
		if ( this.exists ){
			double x = Q.x + (P.x-Q.x)*Math.cos(angle) + (P.y-Q.y)*Math.sin(angle);
			double y = Q.y - (P.x-Q.x)*Math.sin(angle) + (P.y-Q.y)*Math.cos(angle);
			EuclideanLine l = new EuclideanLine( B, new EuclideanPoint( x, y ), color );
			l.mouseOver = this.mouseOver;
			l.isSelected = this.isSelected;
			l.draw( g );
		}
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || obj == C || A.uses(obj) || B.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		int c = GeometricPanel.getIndex( C );
		return "EUCLIDEAN_ANGLE_TRISECTOR(" + a + "," + b + "," + c + "," + GeometricToolbox.getColor( color ) +")";
	}
}