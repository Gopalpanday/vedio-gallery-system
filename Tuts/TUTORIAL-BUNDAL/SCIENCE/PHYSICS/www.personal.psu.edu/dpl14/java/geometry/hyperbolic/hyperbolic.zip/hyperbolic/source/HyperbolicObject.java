import java.awt.*;
import Geometry.*;

public abstract class HyperbolicObject extends GeometricObject{
        
    public HyperbolicObject(){
		this.threshold = 0.05;
    }
}