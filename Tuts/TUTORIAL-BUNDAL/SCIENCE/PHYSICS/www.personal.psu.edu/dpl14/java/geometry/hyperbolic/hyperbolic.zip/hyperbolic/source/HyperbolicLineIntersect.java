import java.awt.*;
import Geometry.*;

public class HyperbolicLineIntersect extends HyperbolicPoint{

    private HyperbolicLine L1;
    private HyperbolicLine L2;
    
    public HyperbolicLineIntersect( HyperbolicLine L1, HyperbolicLine L2 ){
		this( L1, L2, Color.black );
    }

    public HyperbolicLineIntersect( HyperbolicLine L1, HyperbolicLine L2, Color color ){
		super();
		this.L1 = L1;
		this.L2 = L2;
		this.color = color;
		this.isMovable = false;
    }
    

    public GeometricPoint getPoint(){
		GeometricPoint C = L1.getCenter();
		GeometricPoint c = L2.getCenter();
		double R = Math.sqrt( C.x*C.x + C.y*C.y - 1 );
		double r = Math.sqrt( c.x*c.x + c.y*c.y - 1 );
		double d = C.distance( c );
		if ( R+r < d || Math.abs(R-r) > d || d == 0){
			this.exists = false;
			return new GeometricPoint();
		} else {
			this.exists = true;
			double cos = (R*R-r*r+d*d)/(2*R*d);
			GeometricPoint P = C.add( c.subtract(C).scale(R*cos/d) );
			int sign = 1;
			double z = R*Math.sqrt( 1 - cos*cos );
			GeometricPoint out = new GeometricPoint( P.x - z*(C.y-c.y)/d, P.y - z*(c.x-C.x)/d );
			if ( out.length() > 1 ){
				out = new GeometricPoint( P.x + z*(C.y-c.y)/d, P.y + z*(c.x-C.x)/d );
			}
			if ( out.length() > 1 ){
				return null;
			}
			return out;
		}
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == L1 || obj == L2 || L1.uses(obj) || L2.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( L1 );
		int b = GeometricPanel.getIndex( L2 );
		return "HYPERBOLIC_LINE_INTERSECT(" + a + "," + b + "," +  GeometricToolbox.getColor( color ) +")";
	}
}