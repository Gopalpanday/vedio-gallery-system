import java.awt.*;
import java.awt.geom.*;
import Geometry.*;

public class SphericalLineSegment extends SphericalLine{
    
    public SphericalLineSegment( SphericalPoint A, SphericalPoint B ){
		this( A, B, Color.black );
    }
    
    public SphericalLineSegment( SphericalPoint A, SphericalPoint B, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.color = color;
    }

    /*
    public double distance( GeometricPoint p ){
		//return 50*Math.abs(Math.acos(A.dot(p))+Math.acos(B.dot(p))-Math.acos(A.dot(B)));
    }*/
    
    public void draw( Graphics2D g ){
		int W = SphericalPanel.w;
		int H = SphericalPanel.h;
	
		GeometricPoint X = A.toScreenCoordinates();
		GeometricPoint Y = B.toScreenCoordinates();
		GeometricPoint P = X.cross( Y );
		P = P.scale( 1/P.length() );
	
		double R = Math.min(W/2.0,H/2.0);
		double r = Math.abs( P.z );
	
	
		// 0 < theta < 2pi
		double theta = Math.asin(2*P.x*P.y/(r*r-1))/2.0;
		if ( P.x*P.x > P.y*P.y ){
			if ( P.x*P.y<0 ){
				theta = Math.PI/2 - theta;
			} else {
				theta = -Math.PI/2 - theta;
			}
		}
		if ( P.y*P.z > 0 ) theta += Math.PI;

		AffineTransform rot = AffineTransform.getRotateInstance( -theta, W/2, H/2);
		g.setTransform(rot);
		float linewidth = 2.0f;
		if ( mouseOver || isSelected ){
			linewidth = 3.5f;
		}
	
		// -pi < angleA, angleB < pi
		double angleA = Math.acos( X.x*Math.cos(theta) + X.y*Math.sin(theta) );
		if ( X.y*Math.cos(theta) - X.x*Math.sin(theta) < 0 ){
	    	angleA *= -1.0;
		}
		double angleB = Math.acos( Y.x*Math.cos(theta) + Y.y*Math.sin(theta) );
		if ( Y.y*Math.cos(theta) - Y.x*Math.sin(theta) < 0 ){
	    	angleB *= -1.0;
		}
	
		double angle = Math.abs(angleA-angleB);
		double start = Math.min(angleA,angleB);
		if ( Math.PI < angle ){
			angle = 2*Math.PI - angle;
			start = Math.max(angleA,angleB);
		}
	
		start *= 180/Math.PI;
		angle *= 180/Math.PI;
		if ( start < 0 && start + angle < 0){
			g.setColor( Color.lightGray );
			g.setStroke( new BasicStroke(linewidth,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,10.0f,dash,0.0f) );
			g.draw( new Arc2D.Double(W/2-R, H/2-R*r, 2*R, 2*R*r, start, angle, Arc2D.OPEN ) );
		} else if ( start < 0 && start + angle < 180 ){
			g.setColor( Color.lightGray );
			g.setStroke( new BasicStroke(linewidth,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,10.0f,dash,0.0f) );
			g.draw( new Arc2D.Double(W/2-R, H/2-R*r, 2*R, 2*R*r, start, -start, Arc2D.OPEN ) );

			g.setColor( color );
			g.setStroke( new BasicStroke( linewidth ) );
			g.draw( new Arc2D.Double(W/2-R, H/2-R*r, 2*R, 2*R*r, 0, angle+start, Arc2D.OPEN ) );
		} else if ( start > 0 && start + angle < 180 ){
			g.setColor( color );
			g.setStroke( new BasicStroke( linewidth ) );
			g.draw( new Arc2D.Double(W/2-R, H/2-R*r, 2*R, 2*R*r, start, angle, Arc2D.OPEN ) );
		} else {
			g.setColor( Color.lightGray );
			g.setStroke( new BasicStroke(linewidth,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,10.0f,dash,0.0f) );
			g.draw( new Arc2D.Double(W/2-R, H/2-R*r, 2*R, 2*R*r, 180, angle+start-180, Arc2D.OPEN ) );

			g.setColor( color );
			g.setStroke( new BasicStroke( linewidth ) );
			g.draw( new Arc2D.Double(W/2-R, H/2-R*r, 2*R, 2*R*r, start, 180-start, Arc2D.OPEN ) );
		}
	
		g.setTransform( new AffineTransform() );
		g.setStroke( new BasicStroke( 1.0f ) );
    }

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		return "SPHERICAL_LINE_SEGMENT(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}