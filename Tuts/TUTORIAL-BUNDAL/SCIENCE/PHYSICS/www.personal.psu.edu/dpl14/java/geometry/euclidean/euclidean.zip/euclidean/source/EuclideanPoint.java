import java.awt.*;
import java.awt.geom.*;
import Geometry.*;


class LinkedPoints{
	EuclideanPoint point;
	LinkedPoints next;
	
	LinkedPoints(){
		point = null;
		next = null;
	}
}

public class EuclideanPoint extends GeometricPoint{
	
	LinkedPoints firstPoint = new LinkedPoints();  // list of points on circles of fixed radii with this as CENTER

	public EuclideanPoint(){
		this( 0, 0, Color.black );
	}

	public EuclideanPoint( double x, double y ){
		this( x, y, Color.black );
	}

	public EuclideanPoint( double x, double y, Color color ){
		super();
		this.x = x;
		this.y = y;
		this.z = 0.0;
		this.color = color;
		this.isMovable = true;
		this.exists = true;
		this.threshold = 5;
	}

	public EuclideanPoint( Point p ){
		this( p.x, p.y, Color.black );
	}

	public EuclideanPoint( Point p, Color color ){
		this( p.x, p.y, color );
	}

	public EuclideanPoint( GeometricPoint p ){
		this( p.x, p.y, Color.black );
	}

	public EuclideanPoint( GeometricPoint p, Color color ){
		this( p.x, p.y, color );
	}

/*
	public double distance( GeometricPoint p ){
		GeometricPoint P0 = this.getPoint();
		GeometricPoint P1 = p.getPoint();
		return Math.sqrt( (P0.x-P1.x)*(P0.x-P1.x) + (P0.y-P1.y)*(P0.y-P1.y) );
	}
*/
	public void draw( Graphics2D g ){
		GeometricPoint P = this.getPoint();
		if ( this.exists ){
			g.setColor( color );
			if ( isMarker ){
				GeneralPath path = new GeneralPath();
				path.moveTo( (float)P.x, (float)(P.y+radius) );
				path.lineTo( (float)(P.x + radius*Math.sqrt(3)/2.0), (float)(P.y - radius/2.0) );
				path.lineTo( (float)(P.x - radius*Math.sqrt(3)/2.0), (float)(P.y - radius/2.0) );
				path.closePath();
				g.fill( path );
				if ( mouseOver || isSelected )
					path = new GeneralPath();
					path.moveTo( (float)P.x, (float)(P.y+radius+2.0) );
					path.lineTo( (float)(P.x + (radius+2)*Math.sqrt(3)/2.0), (float)(P.y - (radius+2)/2.0) );
					path.lineTo( (float)(P.x - (radius+2)*Math.sqrt(3)/2.0), (float)(P.y - (radius+2)/2.0) );
					path.closePath();
					g.draw( path );
			} else {
				if ( mouseOver || isSelected ){
					if ( isMovable ){
						g.draw( new Arc2D.Double(P.x-radius-2, P.y-radius-2, 2*radius+4, 2*radius+4, 0, 360, Arc2D.OPEN) );
					} else {
						g.setStroke( new BasicStroke(5.0f) );
						g.draw( new Line2D.Double(P.x-radius-1, P.y-radius-1, P.x+radius+1, P.y+radius+1) );
						g.draw( new Line2D.Double(P.x-radius-1, P.y+radius+1, P.x+radius+1, P.y-radius-1) );
						g.setStroke( new BasicStroke(3.0f) );
						g.setColor( Color.white );
						g.draw( new Line2D.Double(P.x-radius-1, P.y-radius-1, P.x+radius+1, P.y+radius+1) );
						g.draw( new Line2D.Double(P.x-radius-1, P.y+radius+1, P.x+radius+1, P.y-radius-1) );
						g.setColor( color );
					}
				}
				if ( isMovable ){
					g.setStroke( new BasicStroke(1.0f) );
					g.fill( new Arc2D.Double(P.x-radius, P.y-radius, 2*radius, 2*radius,0,360, Arc2D.OPEN) );
				} else {
					g.setStroke( new BasicStroke(2.0f) );
					g.draw( new Line2D.Double(P.x-radius, P.y-radius, P.x+radius, P.y+radius) );
					g.draw( new Line2D.Double(P.x-radius, P.y+radius, P.x+radius, P.y-radius) );
					g.setStroke( new BasicStroke(1.0f) );
				}
			}
		}
	}
	
	public boolean uses( GeometricObject obj ){
		return false;
	}

	public void addPoint( EuclideanPoint point ){
		if ( firstPoint.point == null ){
			firstPoint.point = point;
			firstPoint.next = new LinkedPoints();
		} else {
			LinkedPoints tmp = firstPoint.next;
			firstPoint.next = new LinkedPoints();
			firstPoint.next.point = point;
			firstPoint.next.next = tmp;
		}
	}

	// should determine whether or not this exists.
	public GeometricPoint getPoint(){
		return new EuclideanPoint( this );
	}

	public void setPoint( double x, double y ){
		double dx = x-this.x;
		double dy = y-this.y;
		
		this.x = x;
		this.y = y;
		
		updateLinkedPoints( dx, dy );
	}

	public void setPoint( Point p ){
		double dx = p.x-x;
		double dy = p.y-y;
		
		x = p.x;
		y = p.y;
		
		updateLinkedPoints( dx, dy );
	}

	public void translate( double dx, double dy ){
		this.x += dx;
		this.y += dy;
		updateLinkedPoints( dx, dy );
	}
	
	public void updateLinkedPoints( double dx, double dy ){
		LinkedPoints tmp = firstPoint;
		while ( tmp.point != null ){
			tmp.point.translate( dx, dy );
			tmp = tmp.next;
		} 
	}

	public String toString(){
		return "EUCLIDEAN_POINT(" + (int)this.x + "," + (int)this.y + "," + GeometricToolbox.getColor( color ) + ")";
	}
}