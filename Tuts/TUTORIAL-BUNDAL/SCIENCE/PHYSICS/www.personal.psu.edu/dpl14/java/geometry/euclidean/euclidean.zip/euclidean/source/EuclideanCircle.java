import java.awt.*;
import java.awt.geom.*;
import Geometry.*;

public class EuclideanCircle extends EuclideanObject{

	EuclideanPoint CENTER;  // center of circle
	EuclideanPoint X;		// point on circle

	public EuclideanCircle(){
		this( new EuclideanPoint( 0, 0 ), new EuclideanPoint( 1, 0 ), Color.black );
	}

	public EuclideanCircle( EuclideanPoint center, EuclideanPoint x ){
		this( center, x, Color.black );
	}

	public EuclideanCircle( EuclideanPoint center, EuclideanPoint x, Color color ){
		super();
		this.CENTER = center;
		this.X = x; 
		this.color = color;
	}

	public GeometricPoint getCenter(){
		GeometricPoint P = CENTER.getPoint();
		GeometricPoint Q = X.getPoint();
		this.exists = ( CENTER.exists && X.exists );
		return CENTER.getPoint();
	}

	public GeometricPoint getPoint( double radians ){
		double r = getRadius();
		GeometricPoint C = getCenter();
		return new GeometricPoint( C.x + r*Math.cos(radians), C.y - r*Math.sin(radians) );
	}

	public double getRadius(){
		return CENTER.distance( X );
	}

	public double distance( GeometricPoint p ){
		return Math.abs( this.getRadius() - this.getCenter().distance(p) );
	}

	public void draw( Graphics2D g ){
		GeometricPoint c = this.getCenter();
		if ( this.exists ){
			double r = this.getRadius();
			g.setStroke( new BasicStroke(2.0f) );
			if ( mouseOver || isSelected ){
				g.setStroke( new BasicStroke(3.5f) );
			}
			g.setColor( color );
			g.draw( new Ellipse2D.Double( c.x-r, c.y-r, 2*r, 2*r) );
			g.setStroke( new BasicStroke(1.0f) );
		}
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == CENTER || obj == X || CENTER.uses(obj) || X.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int c = GeometricPanel.getIndex( CENTER );
		int x = GeometricPanel.getIndex( X );
		return "EUCLIDEAN_CIRCLE(" + c + "," + x + "," + GeometricToolbox.getColor( color ) +")";
	}
}