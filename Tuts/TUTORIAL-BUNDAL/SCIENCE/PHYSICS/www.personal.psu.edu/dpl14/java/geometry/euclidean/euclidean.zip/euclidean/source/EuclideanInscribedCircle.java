import java.awt.*;
import Geometry.*;

public class EuclideanInscribedCircle extends EuclideanCircle{

	private EuclideanPoint A;
	private EuclideanPoint B;
	private EuclideanPoint C;

	public EuclideanInscribedCircle( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C ){
		this( A, B, C, Color.black );
	}

	public EuclideanInscribedCircle( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.C = C;
		this.color = color;
	}

	public GeometricPoint getCenter(){
		GeometricPoint P = new EuclideanIncenter( A, B, C ).getPoint();
		this.exists = ( A.exists && B.exists && C.exists );
		return P;
	}

	public double getRadius(){
		double perimeter = A.distance(B) + B.distance(C) + C.distance(A);
		double area = Math.abs( B.subtract(A).cross(C.subtract(A)).z );
		return area/perimeter;
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || obj == C || A.uses(obj) || B.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		int c = GeometricPanel.getIndex( C );
		return "EUCLIDEAN_INSCRIBED_CIRCLE(" + a + "," + b + "," + c + "," + GeometricToolbox.getColor( color ) +")";
	}
}