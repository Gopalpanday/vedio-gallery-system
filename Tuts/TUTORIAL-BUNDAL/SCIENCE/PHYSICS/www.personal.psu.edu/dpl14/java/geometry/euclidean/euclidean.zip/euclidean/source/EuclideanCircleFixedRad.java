import java.awt.*;
import java.awt.geom.*;
import Geometry.*;

public class EuclideanCircleFixedRad extends EuclideanCircle{

	double radius;

	public EuclideanCircleFixedRad(){
		this( new EuclideanPoint( 0, 0 ), new EuclideanPoint(10,0), Color.black );
	}

	public EuclideanCircleFixedRad( EuclideanPoint center, double radius ){
		this( center, radius, Color.black );
	}

	public EuclideanCircleFixedRad( EuclideanPoint center, double radius, Color color ){
		super();
		this.CENTER = center;
		this.X = new EuclideanPoint( CENTER.add( new EuclideanPoint(radius,0) ) );
		this.X.isMovable = true;
		this.CENTER.addPoint( X );
		this.color = color;
	}
	
	public EuclideanCircleFixedRad( EuclideanPoint center, EuclideanPoint X ){
		this( center, X, Color.black );
	}

	public EuclideanCircleFixedRad( EuclideanPoint center, EuclideanPoint X, Color color ){
		this.CENTER = center;
		this.X = X;
		this.CENTER.addPoint( X );
		this.color = color;
	}

	public GeometricPoint getCenter(){
		GeometricPoint P = CENTER.getPoint();
		GeometricPoint Q = X.getPoint();
		this.exists = ( CENTER.exists && X.exists );
		return CENTER.getPoint();
	}

	public GeometricPoint getPoint( double radians ){
		GeometricPoint C = getCenter();
		double r = getRadius();
		return new GeometricPoint( C.x + r*Math.cos(radians), C.y - r*Math.sin(radians) );
	}

	public String toString(){
		int c = GeometricPanel.getIndex( CENTER );
		int r = (int) getRadius();
		return "EUCLIDEAN_CIRCLE_FIXED_RADIUS(" + c + "," + r + "," + GeometricToolbox.getColor( color ) +")";
	}
}
