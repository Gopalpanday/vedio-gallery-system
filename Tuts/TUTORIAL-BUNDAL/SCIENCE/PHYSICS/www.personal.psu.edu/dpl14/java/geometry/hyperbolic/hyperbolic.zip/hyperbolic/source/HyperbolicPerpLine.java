import java.awt.*;
import Geometry.*;

public class HyperbolicPerpLine extends HyperbolicLine{

	HyperbolicLine L;

	public HyperbolicPerpLine( HyperbolicPoint A, HyperbolicLine L ){
		this( A, L, Color.black );
	}

	public HyperbolicPerpLine( HyperbolicPoint A, HyperbolicLine L, Color color ){
		super();
		this.A = A;
		this.L = L;
		this.color = color;
	}

	public double distance( GeometricPoint p ){
		HyperbolicPoint C = new HyperbolicProjection( A, L );
		HyperbolicLine l = new HyperbolicLine( A, C, this.color );
		return l.distance( p );
	}

	public void draw( Graphics2D g ){
		this.exists = ( A.exists && L.exists );
		if ( this.exists ){
			HyperbolicPoint C = new HyperbolicProjection( A, L );
			HyperbolicLine l = new HyperbolicLine( A, C, this.color );
			l.mouseOver = this.mouseOver;
			l.isSelected = this.isSelected;
			l.draw( g );
		}
	}

	public GeometricPoint getPoint( double t ){
		HyperbolicPoint C = new HyperbolicProjection( A, L );
		HyperbolicLine l = new HyperbolicLine( A, C, this.color );
		return l.getPoint( t );
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == L || A.uses(obj) || L.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int l = GeometricPanel.getIndex( L );
		return "HYPERBOLIC_PERPENDICULAR_LINE(" + a + "," + l + "," + GeometricToolbox.getColor( color ) +")";
	}
}