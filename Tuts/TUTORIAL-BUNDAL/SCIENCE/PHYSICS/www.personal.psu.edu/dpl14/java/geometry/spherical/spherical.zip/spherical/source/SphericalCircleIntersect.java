import java.awt.*;
import Geometry.*;

public class SphericalCircleIntersect extends SphericalPoint{

    private SphericalCircle A;
    private SphericalCircle B;
    private int sign;

    public SphericalCircleIntersect( SphericalCircle A, SphericalCircle B ){
		this( A, B, 1, Color.black );
    }

    public SphericalCircleIntersect( SphericalCircle A, SphericalCircle B, Color color ){
		this( A, B, 1, color );
    }

    public SphericalCircleIntersect( SphericalCircle A, SphericalCircle B, int sign ){
		this( A, B, sign, Color.black );
    }

    public SphericalCircleIntersect( SphericalCircle A, SphericalCircle B, int sign, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.sign = sign;
		this.color = color;
		this.isMovable = false;
    }

    public GeometricPoint getPoint(){
		GeometricPoint AC = A.getCenter();
		GeometricPoint BC = B.getCenter();
	
		GeometricPoint cross = AC.cross( BC );
		double dotA = AC.dot( A.X.getPoint() );
		double dotB = BC.dot( B.X.getPoint() );
	
		if ( cross.z != 0 ){
			double a = cross.dot( cross );
			double b = 2*( dotB*AC.cross(cross).z - dotA*BC.cross(cross).z );
			double c = dotB*dotB*(AC.x*AC.x + AC.y*AC.y) + dotA*dotA*(BC.x*BC.x+BC.y*BC.y) - 2*dotA*dotB*(AC.x*BC.x+AC.y*BC.y) - cross.z*cross.z;
	    
			double z = ( -b + sign*Math.sqrt(b*b-4*a*c) )/(2*a);
			double x = ( BC.y*dotA - AC.y*dotB + cross.x*z )/cross.z;
			double y = ( AC.x*dotB - BC.x*dotA + cross.y*z )/cross.z;

			this.exists = true;
			return new GeometricPoint( x, y, z );
		} else {
			this.exists = false;
			return new GeometricPoint( );
		}
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || A.uses(obj) || B.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		return "SPHERICAL_CIRCLE_INTERSECT(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}