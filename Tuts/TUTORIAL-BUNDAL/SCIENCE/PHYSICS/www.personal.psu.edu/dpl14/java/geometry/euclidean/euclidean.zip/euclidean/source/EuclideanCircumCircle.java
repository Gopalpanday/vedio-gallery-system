import java.awt.*;
import Geometry.*;

public class EuclideanCircumCircle extends EuclideanCircle{

	EuclideanPoint A;
	EuclideanPoint B;
	EuclideanPoint C;

	public EuclideanCircumCircle( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C ){
		this( A, B, C, Color.black );
	}

	public EuclideanCircumCircle( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C, Color color ){
		super();
		this.A = A;
		this.B = B; 
		this.C = C;
		this.color = color;	   
	}

	public GeometricPoint getCenter(){
		GeometricPoint P = new EuclideanCircumcenter( A, B, C ).getPoint();
		this.exists = P.exists;
		return P;
	}

	public double getRadius(){
		return getCenter().distance(A);
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || obj == C || A.uses(obj) || B.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		int c = GeometricPanel.getIndex( C );
		return "EUCLIDEAN_CIRCUMSCRIBED_CIRCLE(" + a + "," + b + "," + c + "," + GeometricToolbox.getColor( color ) +")";
	}
}