import java.awt.*;
import Geometry.*;

public class HyperbolicInversion extends HyperbolicPoint{

	HyperbolicPoint A;
	HyperbolicCircle C;

	public HyperbolicInversion( HyperbolicPoint A, HyperbolicCircle C ){
		this( A, C, Color.black );
	}

	public HyperbolicInversion( HyperbolicPoint A, HyperbolicCircle C, Color color ){
		super();
		this.A = A;
		this.C = C;
		this.color = color;
		this.isMovable = false;
	}

	public GeometricPoint getPoint(){
		GeometricPoint X = C.getCenter();
		double r = C.getRadius();
		double d = A.distance( X );
		this.exists = ( C.exists && A.exists );
		return X.add( A.subtract(X).scale(r*r/d/d) );
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == C || A.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int c = GeometricPanel.getIndex( C );
		return "HYPERBOLIC_INVERSION(" + a + "," + c + "," + GeometricToolbox.getColor( color ) +")";
	}
}