import java.awt.*;
import Geometry.*;

public class EuclideanOrthocenter extends EuclideanPoint{

	private EuclideanPoint A;
	private EuclideanPoint B;
	private EuclideanPoint C;

	public EuclideanOrthocenter( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C ){
		this( A, B, C, Color.black );
	}

	public EuclideanOrthocenter( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.C = C;
		this.color = color;
		this.isMovable = false;
	}

	private double area(){
		GeometricPoint X = A.getPoint();
		GeometricPoint Y = B.getPoint();
		GeometricPoint Z = C.getPoint();
		return Math.abs( (Y.x-X.x)*(Z.y-X.y) - (Y.y-X.y)*(Z.x-X.x) )/2.0;
	}

	public GeometricPoint getPoint(){
		double d1 = A.subtract(B).dot( A.subtract(B) );
		double d2 = B.subtract(C).dot( B.subtract(C) );
		double d3 = C.subtract(A).dot( C.subtract(A) );
		double a = area();
		double d = (d1+d2-d3)*d3/(8.0*a*a);
		double e = (d2+d3-d1)/(2.0*d3); 
		this.exists = ( A.exists && B.exists && C.exists );
		return B.add( C.subtract(B).add(A.subtract(C).scale(e)).scale(d) );
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || obj == C || A.uses(obj) || B.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		int c = GeometricPanel.getIndex( C );
		return "EUCLIDEAN_ORTHOCENTER(" + a + "," + b + "," + c + "," + GeometricToolbox.getColor( color ) +")";
	}
}