import java.awt.*;
import Geometry.*;

public class EuclideanEulerLine extends EuclideanLine{

    public EuclideanEulerLine( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C ){
		this( A, B, C, Color.black );
    }

    public EuclideanEulerLine( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.C = C;
		this.color = color;
    }

    public double distance( GeometricPoint p ){
		EuclideanPoint X = new EuclideanOrthocenter( A, B, C );
		EuclideanPoint Y = new EuclideanCircumcenter( A, B, C );
		EuclideanLine L = new EuclideanLine( X, Y );
		return L.distance( p );
    }
    
    public void draw( Graphics2D g ){
		EuclideanPoint X = new EuclideanOrthocenter( A, B, C );
		EuclideanPoint Y = new EuclideanCircumcenter( A, B, C );
		EuclideanLine L = new EuclideanLine( X, Y, color );
		this.exists = ( A.exists && B.exists && C.exists );
		if ( this.exists ) L.draw( g );
    }

    public GeometricPoint getPoint( double t ){
		EuclideanPoint X = new EuclideanOrthocenter( A, B, C );
		EuclideanPoint Y = new EuclideanCircumcenter( A, B, C );
		EuclideanLine L = new EuclideanLine( X, Y );
		this.exists = ( A.exists && B.exists && C.exists );
		return L.getPoint( t );
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || obj == C || A.uses(obj) || B.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		int c = GeometricPanel.getIndex( C );
		return "EUCLIDEAN_EULER_LINE(" + a + "," + b + "," + c + "," + GeometricToolbox.getColor( color ) +")";
	}
}