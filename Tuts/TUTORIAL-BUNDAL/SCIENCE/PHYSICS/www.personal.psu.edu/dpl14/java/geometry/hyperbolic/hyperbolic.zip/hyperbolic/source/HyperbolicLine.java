import java.awt.*;
import java.awt.geom.*;
import Geometry.*;

public class HyperbolicLine extends HyperbolicObject{
    
    HyperbolicPoint A;
    HyperbolicPoint B;
	
	double a;			// x-coordinate of center of circle through A and B
	double b;			// y-coordinate of center of circle through A and B
	double r;			// radius of circle
	double R;			// radius of disk
    
    public HyperbolicLine(){
		this( new HyperbolicPoint(), new HyperbolicPoint(), Color.black );
    }

    public HyperbolicLine( HyperbolicPoint A, HyperbolicPoint B ){
		this( A, B, Color.black );
    }

    public HyperbolicLine( HyperbolicPoint A, HyperbolicPoint B, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.color = color;
    }

	// under construction
    public GeometricPoint getPoint( double t ){
		return A.getPoint();
    }
    
    public HyperbolicPoint getCenter(){
		GeometricPoint X = A.getPoint( );
		GeometricPoint Y = B.getPoint( );
		double det = X.x*Y.y - X.y*Y.x;
		double a = (Y.y*(1 + X.x*X.x + X.y*X.y) - X.y*(1 + Y.x*Y.x + Y.y*Y.y))/(2*det);
		double b = (X.x*(1 + Y.x*Y.x + Y.y*Y.y) - Y.x*(1 + X.x*X.x + X.y*X.y))/(2*det);
		return new HyperbolicPoint( a, b );
    }

    public double distance( GeometricPoint p ){
		HyperbolicPoint c = getCenter();
		double r = Math.sqrt( c.x*c.x + c.y*c.y - 1 );
		return Math.abs( Math.sqrt((p.x-c.x)*(p.x-c.x)+(p.y-c.y)*(p.y-c.y))-r );
    }

    public void draw( Graphics2D g ){
		GeometricPoint X = A.getPoint( );
		GeometricPoint Y = B.getPoint( );
		int W = HyperbolicPanel.w;
		int H = HyperbolicPanel.h;
	
		if ( this.exists ){
			
			g.setStroke( new BasicStroke(2.0f) );
			if ( mouseOver || isSelected ){
				g.setStroke( new BasicStroke(3.5f) );
			}
			g.setColor( color );

			double det = X.x*Y.y - X.y*Y.x;
			R = Math.min( W/2.0, H/2.0 );
			if ( det == 0 ){
				double theta = Math.acos(X.x/X.length());
				if ( X.length() == 0 ){
					theta = Math.acos(Y.x/Y.length());
					if ( Y.y < 0 ){
						theta *= -1;
					}
				} else {
					if ( X.y < 0 ){
						theta *= -1;
					}
				}
				g.draw( new Line2D.Double( W/2.0+R*Math.cos(theta), H/2.0-R*Math.sin(theta), W/2.0-R*Math.cos(theta), H/2.0+R*Math.sin(theta) ) );
				//g.draw( new Line2D.Double( W/2.0+X.x*R, H/2.0-X.y*R, W/2.0+Y.x*R, H/2.0-Y.y*R ) );
			} else {
				a = (Y.y*(1 + X.x*X.x + X.y*X.y) - X.y*(1 + Y.x*Y.x + Y.y*Y.y))/(2*det); 
				b = (X.x*(1 + Y.x*Y.x + Y.y*Y.y) - Y.x*(1 + X.x*X.x + X.y*X.y))/(2*det);
				r = Math.sqrt( a*a + b*b - 1 );
				double theta = 180*Math.asin(1/Math.sqrt(a*a+b*b))/Math.PI;
				double start = 180*Math.acos(-a/Math.sqrt(a*a+b*b))/Math.PI - theta;
				if ( b > 0 ){
					start = -180*Math.acos(-a/Math.sqrt(a*a+b*b))/Math.PI - theta;
				}
				g.draw( new Arc2D.Double( W/2.0+(a-r)*R, H/2.0-(b+r)*R, 2*r*R, 2*r*R, start, 2*theta, Arc2D.OPEN) );
			}
		}
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || A.uses(obj) || B.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		return "HYPERBOLIC_LINE(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}