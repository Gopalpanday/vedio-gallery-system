import java.awt.*;
import Geometry.*;

public class EuclideanProjection extends EuclideanPoint{

	EuclideanPoint A;
	EuclideanLine L;

	public EuclideanProjection( EuclideanPoint A, EuclideanLine L ){
		this( A, L, Color.black );
	}

	public EuclideanProjection( EuclideanPoint A, EuclideanLine L, Color color ){
		super();
		this.A = A;
		this.L = L;
		this.color = color;
		this.isMovable = false;
	}

	public GeometricPoint getPoint(){
		EuclideanPoint X = new EuclideanPoint( L.getPoint( 0.0 ) );
		EuclideanPoint Y = new EuclideanPoint( L.getPoint( 1.0 ) );
		double d = Math.pow( X.distance( Y ), 2 );
		double dot = A.subtract(X).dot( Y.subtract(X) );
		this.exists = ( L.exists && A.exists );
		return X.add( Y.subtract(X).scale(dot/d) );
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == L || A.uses(obj) || L.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int l = GeometricPanel.getIndex( L );
		return "EUCLIDEAN_PROJECTION(" + a + "," + l + "," + GeometricToolbox.getColor( color ) +")";
	}
}