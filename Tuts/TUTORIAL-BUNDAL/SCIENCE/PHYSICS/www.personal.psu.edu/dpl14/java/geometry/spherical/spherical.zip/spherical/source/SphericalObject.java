import java.awt.*;
import Geometry.*;

public abstract class SphericalObject extends GeometricObject{

    public SphericalObject(){
		this.threshold = 0.01;
    }
}