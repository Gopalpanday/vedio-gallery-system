import java.awt.*;
import java.awt.geom.*;
import Geometry.*;

public class HyperbolicPoint extends GeometricPoint{

    public HyperbolicPoint(){
		this( 0, 0, Color.black );
    }
            
    public HyperbolicPoint( double x, double y ){
		this( x, y, Color.black );
    }
    
    public HyperbolicPoint( double x, double y, Color color ){
		this.x = x;
		this.y = y;
		this.z = 0.0;
		this.color = color;
		this.isMovable = true;
		this.threshold = 0.05;
    }
    
    public HyperbolicPoint( Point p ){
		this( p.x, p.y, Color.black );
    }

    public HyperbolicPoint( HyperbolicPoint p ){
		this( p.x, p.y, p.color );
    }
	
	public HyperbolicPoint( GeometricPoint p ){
		this( p.x, p.y, p.color );
	}

    public HyperbolicPoint( Point p, Color color ){
		this( p.x, p.y, color );
    }

    // this gives the regular Euclidean distance between points in the unit disk
    public double distance( GeometricPoint p ){
		GeometricPoint X = this.getPoint();
		GeometricPoint Y = p.getPoint();
		return Math.sqrt( (X.x-Y.x)*(X.x-Y.x) + (X.y-Y.y)*(X.y-Y.y) );
    }
	
    // this gives the Hyperbolic distance between (0,0) and this
	public double hyperbolicLength(){
		double y = this.length(); // i.e. the Euclidean length of this
		return Math.log((1+y)/(1-y))/2;
	}

    // this gives the Hyperbolic distance between points in the unit disk
	public double hyperbolicDistance( HyperbolicPoint P ){
		GeometricPoint X = this.getPoint();
		GeometricPoint Y = P.getPoint();
		double a = Y.x - X.x;
		double b = Y.y - X.y;
		double c = 1 - X.x*Y.x - X.y*Y.y;
		double d = X.y*Y.x - X.x*Y.y;
		double y = Math.sqrt((a*a+b*b)/(c*c+d*d)); // |(Y - X)/(1-conjugate(X)Y)| where X and Y are thought of as complex numbers
		return Math.log((1+y)/(1-y))/2;
	}
	
	
	public HyperbolicPoint conjugate(){
		GeometricPoint X = this.getPoint();
		return new HyperbolicPoint( X.x, -X.y );
	}
	

	public HyperbolicPoint multiply( HyperbolicPoint P ){
		GeometricPoint X = this.getPoint();
		GeometricPoint Y = P.getPoint();
		return new HyperbolicPoint( X.x*Y.x - X.y*Y.y, X.x*Y.y + X.y*Y.x  );
	}
	
	public HyperbolicPoint divide( HyperbolicPoint P ){
		double d = P.dot(P);
		HyperbolicPoint m = this.multiply(P.conjugate());
		return new HyperbolicPoint( m.x/d, m.y/d);
	}
/*
	// returns (Athis+B)/(B*this+A*) where * denotes complex conjugation
	public HyperbolicPoint mobius( GeometricPoint A, GeometricPoint B ){
		GeometricPoint X = A.getPoint();
		GeometricPoint Y = B.getPoint();
		
	}
*/
    public void draw( Graphics2D g ){
		int W = HyperbolicPanel.w;
		int H = HyperbolicPanel.h;
		double R = Math.min( W/2.0, H/2.0 );
		GeometricPoint P = this.getPoint();
		if ( this.exists ){
			g.setColor( color );
			if ( mouseOver || isSelected ){
				if ( isMovable ){
					g.setStroke( new BasicStroke(1.0f) );
					g.draw( new Arc2D.Double(W/2.0+R*P.x-radius-2, H/2.0-R*P.y-radius-2, 2*radius+4, 2*radius+4, 0, 360, Arc2D.OPEN) );
				} else {
					g.setStroke( new BasicStroke(5.0f) );
					g.draw( new Line2D.Double(W/2.0+R*P.x-radius-1, H/2.0-R*P.y-radius-1, W/2.0+R*P.x+radius+1, H/2.0-R*P.y+radius+1) );
					g.draw( new Line2D.Double(W/2.0+R*P.x-radius-1, H/2.0-R*P.y+radius+1, W/2.0+R*P.x+radius+1, H/2.0-R*P.y-radius-1) );
					g.setStroke( new BasicStroke(3.0f) );
					g.setColor( Color.white );
					g.draw( new Line2D.Double(W/2.0+R*P.x-radius-1, H/2.0-R*P.y-radius-1, W/2.0+R*P.x+radius+1, H/2.0-R*P.y+radius+1) );
					g.draw( new Line2D.Double(W/2.0+R*P.x-radius-1, H/2.0-R*P.y+radius+1, W/2.0+R*P.x+radius+1, H/2.0-R*P.y-radius-1) );
					g.setColor( color );
				}
			}
			if ( isMovable ){
				g.setStroke( new BasicStroke(1.0f) );
				g.fill( new Arc2D.Double(W/2.0+R*P.x-radius, H/2.0-R*P.y-radius, 2*radius, 2*radius, 0, 360, Arc2D.OPEN) );
			} else {
				g.setStroke( new BasicStroke(2.0f) );
				g.draw( new Line2D.Double(W/2.0+R*P.x-radius, H/2.0-R*P.y-radius, W/2+R*P.x+radius, H/2-R*P.y+radius) );
				g.draw( new Line2D.Double(W/2.0+R*P.x+radius, H/2.0-R*P.y-radius, W/2+R*P.x-radius, H/2-R*P.y+radius) );
				g.setStroke( new BasicStroke(1.0f) );
			}
		}
    }

    public GeometricPoint getPoint(){
		return new HyperbolicPoint( this );
    }

	public String toString(){
		GeometricPoint P = this.getPoint();
		return "HYPERBOLIC_POINT(" + P.x + "," + P.y + "," + GeometricToolbox.getColor( color ) + ")";
	}
}