import java.awt.*;
import Geometry.*;

public class EuclideanPerpPoint extends EuclideanPoint{

	EuclideanPoint A;
	EuclideanPoint B;

	int sign;   // 1 means that point B is rotated 90 degrees in a counter-clockwise direction around A
				// -1 means that point B is rotated 90 degrees in a clockwise direction around A

	public EuclideanPerpPoint(){
		this( new EuclideanPoint(), new EuclideanPoint(), 1, Color.black );
	}

	public EuclideanPerpPoint( EuclideanPoint A, EuclideanPoint B, int sign ){
		this( A, B, sign, Color.black );
	}

	public EuclideanPerpPoint( EuclideanPoint A, EuclideanPoint B, int sign, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.sign = sign;
		this.color = color;
	}

	public GeometricPoint getPoint(){
		GeometricPoint P = A.getPoint();
		GeometricPoint Q = B.getPoint();
		this.exists = ( A.exists && B.exists );
		return new GeometricPoint( P.x - sign*(P.y-Q.y), P.y - sign*(Q.x-P.x) );
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || A.uses(obj) || B.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		return "EUCLIDEAN_PERPENDICULAR_POINT(" + a + "," + b + "," + sign + "," + GeometricToolbox.getColor( color ) +")";
	}
}