import java.awt.*;
import java.awt.geom.*;
import Geometry.*;

public class HyperbolicLineSegment extends HyperbolicLine{
    
    public HyperbolicLineSegment( HyperbolicPoint A, HyperbolicPoint B ){
		this( A, B, Color.black );
    }

    public HyperbolicLineSegment( HyperbolicPoint A, HyperbolicPoint B, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.color = color;
	}
	
	// computes angle (in radians) from p to q
	public double getAngle( GeometricPoint p, GeometricPoint q ){
		double out = 0.0;
		double dot = p.x*q.x + p.y*q.y;
		double cross = p.x*q.y - p.y*q.x;

		if ( dot < 0){
			if ( cross < 0 ){
				out = -Math.PI - Math.asin( cross/(p.length()*q.length()) );
			} else {
				out = Math.PI - Math.asin( cross/(p.length()*q.length()) );
			}
		} else {
			out = Math.asin( cross/(p.length()*q.length()) );
		}
		return out;
	}

    
    public void draw( Graphics2D g ){
		GeometricPoint X = A.getPoint( );
		GeometricPoint Y = B.getPoint( );
		int W = HyperbolicPanel.w;
		int H = HyperbolicPanel.h;
	
		if ( this.exists ){
			
			g.setStroke( new BasicStroke(2.0f) );
			if ( mouseOver || isSelected ){
				g.setStroke( new BasicStroke(3.5f) );
			}
			g.setColor( color );

			double det = X.x*Y.y - X.y*Y.x;
			R = Math.min( W/2.0, H/2.0 );
			if ( det == 0 ){
				g.draw( new Line2D.Double( W/2.0+X.x*R, H/2.0-X.y*R, W/2.0+Y.x*R, H/2.0-Y.y*R ) );
			} else {
				a = (Y.y*(1 + X.x*X.x + X.y*X.y) - X.y*(1 + Y.x*Y.x + Y.y*Y.y))/(2*det); 
				b = (X.x*(1 + Y.x*Y.x + Y.y*Y.y) - Y.x*(1 + X.x*X.x + X.y*X.y))/(2*det);
				r = Math.sqrt( a*a + b*b - 1 );
				GeometricPoint v = new GeometricPoint( -a, -b );
				double alpha = getAngle( v, A.add(v) );		// angle from (-a,-b) to A-(a,b)
				double beta = getAngle( v, B.add(v) );		// angle from (-a,-b) and B-(a,b)
				double theta = 180*(Math.abs(alpha)+Math.abs(beta))/Math.PI;
				if ( alpha*beta>0 ){
					theta = 180*Math.abs(alpha-beta)/Math.PI;
				}
				double start = 180*Math.acos(-a/Math.sqrt(a*a+b*b))/Math.PI + 180*Math.min(alpha,beta)/Math.PI;
				if ( b > 0 ){
					start = -180*Math.acos(-a/Math.sqrt(a*a+b*b))/Math.PI + 180*Math.min(alpha,beta)/Math.PI;
				}
				g.draw( new Arc2D.Double( W/2.0+(a-r)*R, H/2.0-(b+r)*R, 2*r*R, 2*r*R, start, theta, Arc2D.OPEN) );
			}
		}
    }

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		return "HYPERBOLIC_LINE_SEGMENT(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}