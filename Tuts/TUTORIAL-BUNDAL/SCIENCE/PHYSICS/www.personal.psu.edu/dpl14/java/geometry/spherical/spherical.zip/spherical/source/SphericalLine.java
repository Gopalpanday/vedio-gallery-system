import java.awt.*;
import java.awt.geom.*;
import Geometry.*;

public class SphericalLine extends SphericalObject{
    
    SphericalPoint A;
    SphericalPoint B;

    public SphericalLine(){
		this( new SphericalPoint(), new SphericalPoint(), Color.black );
    }

    public SphericalLine( SphericalPoint A, SphericalPoint B ){
		this( A, B, Color.black );
    }

    public SphericalLine( SphericalPoint A, SphericalPoint B, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.color = color;
    }

	// under construction
    public GeometricPoint getPoint( double t ){
		double d = A.distance(B);
		GeometricPoint C = A.cross(B);
		GeometricPoint P = A.getPoint();
		P.rotate( t*d, C );
		this.exists = ( A.exists && B.exists );
		return P;
    }

    public double distance( GeometricPoint p ){
		SphericalPoint C = new SphericalPoint( A.cross( B ) );
		return Math.abs( Math.PI/2 - C.distance(p) ); 
    }


    public void draw( Graphics2D g ){
		int W = SphericalPanel.w;
		int H = SphericalPanel.h;

		GeometricPoint X = A.toScreenCoordinates();
		GeometricPoint Y = B.toScreenCoordinates();
		GeometricPoint P = X.cross( Y );
		P = P.scale( 1/P.length() );
	
		double R = Math.min(W/2.0,H/2.0);
		double r = Math.abs( P.z );
	
		// 0 < theta < 2pi
		double theta = Math.asin(2*P.x*P.y/(r*r-1))/2.0;
		if ( P.x*P.x > P.y*P.y ){
			if ( P.x*P.y<0 ){
				theta = Math.PI/2 - theta;
			} else {
				theta = -Math.PI/2 - theta;
			}
		}
		// draw the correct half of the ellipse in color
		if ( P.y*P.z > 0 ) theta += Math.PI;

		AffineTransform rot = AffineTransform.getRotateInstance( -theta, W/2, H/2);
		g.setTransform(rot);

		float linewidth = 2.0f;
		if ( mouseOver || isSelected ){
			linewidth = 3.5f;
		}
		g.setColor( Color.lightGray );
		g.setStroke( new BasicStroke(linewidth,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND,10.0f,dash,0.0f) );
		g.draw( new Arc2D.Double(W/2-R, H/2-R*r, 2*R, 2*R*r, 180, 180, Arc2D.OPEN ) );

		g.setColor( this.color );
		g.setStroke( new BasicStroke(linewidth,BasicStroke.CAP_BUTT,BasicStroke.JOIN_ROUND) );
		g.draw( new Arc2D.Double(W/2-R, H/2-R*r, 2*R, 2*R*r, 0, 180, Arc2D.OPEN ) );
	
		g.setTransform( new AffineTransform() );
		g.setStroke( new BasicStroke( 1.0f ) );
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || A.uses(obj) || B.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		return "SPHERICAL_LINE(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}