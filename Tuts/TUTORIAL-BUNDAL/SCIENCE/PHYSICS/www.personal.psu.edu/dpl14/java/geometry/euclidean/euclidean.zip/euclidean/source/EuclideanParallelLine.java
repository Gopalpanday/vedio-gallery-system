import java.awt.*;
import Geometry.*;

public class EuclideanParallelLine extends EuclideanLine{

	private EuclideanLine L;

	public EuclideanParallelLine( EuclideanPoint A, EuclideanLine L ){
		this( A, L, Color.black );
	}

	public EuclideanParallelLine( EuclideanPoint A, EuclideanLine L, Color color ){
		super();
		this.A = A;
		this.L = L;
		this.color = color;
	}

	public double distance( GeometricPoint p ){
		EuclideanPoint X = new EuclideanPoint(L.getPoint(1.0).add( A.subtract(L.getPoint(0.0)) ));
		EuclideanLine l = new EuclideanLine( A, X );
		return l.distance( p );
	}

	public void draw( Graphics2D g ){
		EuclideanPoint X = new EuclideanPoint(L.getPoint(1.0).add( A.subtract(L.getPoint(0.0)) ));
		this.exists = ( A.exists && L.exists );
		if ( this.exists ){
			EuclideanLine l = new EuclideanLine( A, X, color );
			l.mouseOver = this.mouseOver;
			l.isSelected = this.isSelected;
			l.draw( g );
		}
	}

	public GeometricPoint getPoint( double t ){
		return L.getPoint( t ).add( A.subtract(L.getPoint(0.0)) );
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == L || A.uses(obj) || L.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int l = GeometricPanel.getIndex( L );
		return "EUCLIDEAN_PARALLEL_LINE(" + a + "," + l + "," + GeometricToolbox.getColor( color ) +")";
	}
}