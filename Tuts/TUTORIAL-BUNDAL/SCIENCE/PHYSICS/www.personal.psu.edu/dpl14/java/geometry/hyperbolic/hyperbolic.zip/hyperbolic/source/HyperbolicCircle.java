import java.awt.*;
import java.awt.geom.*;
import Geometry.*;

public class HyperbolicCircle extends HyperbolicObject{

    HyperbolicPoint CENTER;      // center of circle
    HyperbolicPoint X;		// point on circle


    public HyperbolicCircle(){
		this( new HyperbolicPoint( 0, 0 ), new HyperbolicPoint( 0, 0.5), Color.black );
    }

    public HyperbolicCircle( HyperbolicPoint center, HyperbolicPoint x ){
		this( center, x, Color.black );
    }
    
    public HyperbolicCircle( HyperbolicPoint center, HyperbolicPoint x, Color color ){
		super();
		this.CENTER = center;    
		this.X = x; 
		this.color = color;
    }
    
	// returns the Euclidean center
    public GeometricPoint getCenter(){
		double d = CENTER.hyperbolicLength();
		double r = CENTER.hyperbolicDistance( X );
		double c = (Math.exp(4*d)-1)/((Math.exp(2*(d+r))+1)*(Math.exp(2*(d-r))+1));
		GeometricPoint M = CENTER.getPoint();
		this.exists = ( CENTER.exists && X.exists );
		return M.scale(c/M.length());
    }
    
    public GeometricPoint getPoint( double radians ){
		double r = getRadius();
		GeometricPoint C = getCenter();
		this.exists = ( X.exists && CENTER.exists );
		return new GeometricPoint( C.x + r*Math.cos(radians), C.y - r*Math.sin(radians) );
    }
    
	// returns the Euclidean radius
    public double getRadius(){
		//double d = CENTER.hyperbolicLength();
		//double r = CENTER.hyperbolicDistance( X );
		//return (Math.exp(2*(d+r))-Math.exp(2*(d-r)))/((Math.exp(2*(d+r))+1)*(Math.exp(2*(d-r))+1));
		return this.getCenter().distance(X);
    }

    public double distance( GeometricPoint p ){
		return Math.abs( this.getCenter().distance(X) - this.getCenter().distance(p) );
    }
    
    public void draw( Graphics2D g ){
		int W = HyperbolicPanel.w;
		int H = HyperbolicPanel.h;
		double R = Math.min(W/2.0,H/2.0);
		
		GeometricPoint c = this.getCenter();
		if ( this.exists ){
			double r = this.getRadius();
			g.setStroke( new BasicStroke(2.0f) );
			if ( mouseOver || isSelected ){
				g.setStroke( new BasicStroke(3.5f) );
			}
			g.setColor( color );
			g.draw( new Ellipse2D.Double( W/2.0 + R*(c.x-r), H/2.0 - R*(c.y+r), 2*r*R, 2*r*R) );
			//g.setStroke( new BasicStroke(1.0f) );
		}
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == CENTER || obj == X || CENTER.uses(obj) || X.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( CENTER );
		int b = GeometricPanel.getIndex( X );
		return "HYPERBOLIC_CIRCLE(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}