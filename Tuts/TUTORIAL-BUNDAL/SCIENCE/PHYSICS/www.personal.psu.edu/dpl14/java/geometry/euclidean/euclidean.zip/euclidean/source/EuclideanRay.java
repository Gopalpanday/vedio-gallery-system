import java.awt.*;
import java.awt.geom.*;
import Geometry.*;

public class EuclideanRay extends EuclideanLine{

	public EuclideanRay(){
		this( new EuclideanPoint(), new EuclideanPoint(), Color.black );
	}

	public EuclideanRay( EuclideanPoint A, EuclideanPoint B ){
		this( A, B, Color.black );
	}

	public EuclideanRay( EuclideanPoint A, EuclideanPoint B, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.color = color;
	}

	public GeometricPoint getPoint( double t ){
		GeometricPoint P = A.add( B.subtract(A).scale(t) );
		this.exists = ( A.exists && B.exists );
		return P;
	}

	public double distance( GeometricPoint p ){
		double dot = Math.pow( A.subtract(B).dot(A.subtract(p)), 2 );
		double distAB = Math.pow( A.distance(B), 2 );
		double distAP = Math.pow( A.distance(p), 2 );
		return Math.sqrt( distAP - dot/distAB );
	}

	public void draw( Graphics2D g ){
		GeometricPoint X = getPoint( 0.0 );
		GeometricPoint Y = getPoint( 100.0 );

		if ( this.exists ){
			g.setStroke( new BasicStroke(2.0f) );
			if ( mouseOver || isSelected ){
				g.setStroke( new BasicStroke(3.5f) );
			}
			g.setColor( color );
			g.draw( new Line2D.Double(X.x, X.y, Y.x, Y.y) );
			g.setStroke( new BasicStroke(1.0f) );
		}
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		return "EUCLIDEAN_RAY(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}