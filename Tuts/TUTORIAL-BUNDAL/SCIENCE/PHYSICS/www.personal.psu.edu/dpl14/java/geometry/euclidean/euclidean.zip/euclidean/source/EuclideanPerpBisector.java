import java.awt.*;
import Geometry.*;

public class EuclideanPerpBisector extends EuclideanLine{

	EuclideanLineSegment L;

	public EuclideanPerpBisector( EuclideanLineSegment L ){
		this( L, Color.black );
	}

	public EuclideanPerpBisector( EuclideanLineSegment L, Color color ){
		super();
		this.L = L;
		this.color = color;
	}

	public double distance( GeometricPoint p ){
		GeometricPoint X = L.getPoint( 0.0 );
		GeometricPoint Y = L.getPoint( 1.0 );
		A = new EuclideanPoint( (X.x+Y.x)/2.0-Y.y+X.y, (X.y+Y.y)/2.0+Y.x-X.x );
		B = new EuclideanPoint( (X.x+Y.x)/2.0+Y.y-X.y, (X.y+Y.y)/2.0-Y.x+X.x );
		EuclideanLine l = new EuclideanLine( A, B );
		return l.distance( p );
	}

	public void draw( Graphics2D g ){
		//EuclideanPoint X = L.getPoint( 0.0 );
		//EuclideanPoint Y = L.getPoint( 1.0 );
		GeometricPoint X = L.A.getPoint();
		GeometricPoint Y = L.B.getPoint();
		this.exists = ( L.A.exists && L.B.exists );
		if ( this.exists ){
			A = new EuclideanPoint( (X.x+Y.x)/2.0-Y.y+X.y, (X.y+Y.y)/2.0+Y.x-X.x );
			B = new EuclideanPoint( (X.x+Y.x)/2.0+Y.y-X.y, (X.y+Y.y)/2.0-Y.x+X.x );
			EuclideanLine l = new EuclideanLine( A, B, color );
			l.mouseOver = this.mouseOver;
			l.isSelected = this.isSelected;
			l.draw( g );
		}
	}

	public GeometricPoint getPoint( double t ){
		GeometricPoint X = L.getPoint( 0.0 );
		GeometricPoint Y = L.getPoint( 1.0 );
		A = new EuclideanPoint( (X.x+Y.x)/2.0-Y.y+X.y, (X.y+Y.y)/2.0+Y.x-X.x );
		B = new EuclideanPoint( (X.x+Y.x)/2.0+Y.y-X.y, (X.y+Y.y)/2.0-Y.x+X.x );
		return B.add( A.subtract(B).scale(1-t) );
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == L || L.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int l = GeometricPanel.getIndex( L );
		return "EUCLIDEAN_PERPENDICULAR_BISECTOR(" + l + "," + GeometricToolbox.getColor( color ) +")";
	}
}