import java.awt.*;
import Geometry.*;

public class SphericalPerpLine extends SphericalLine{

	SphericalLine L;

	public SphericalPerpLine( SphericalPoint A, SphericalLine L ){
		this( A, L, Color.black );
	}

	public SphericalPerpLine( SphericalPoint A, SphericalLine L, Color color ){
		super();
		this.A = A;
		this.L = L;
		this.color = color;
	}

	public double distance( GeometricPoint p ){
		SphericalPoint X = new SphericalPoint( L.A.getPoint() );
		SphericalPoint Y = new SphericalPoint( L.B.getPoint() );
		SphericalPoint C = new SphericalPoint( X.cross(Y) );
		SphericalLine l = new SphericalLine( A, C );
		return l.distance( p );
	}

	public void draw( Graphics2D g ){
		SphericalPoint X = new SphericalPoint( L.A.getPoint() );
		SphericalPoint Y = new SphericalPoint( L.B.getPoint() );
		this.exists = ( A.exists && L.exists );
		if ( this.exists ){
			SphericalPoint C = new SphericalPoint( X.cross(Y) );
			SphericalLine l = new SphericalLine( A, C, this.color );
			l.mouseOver = this.mouseOver;
			l.isSelected = this.isSelected;
			l.draw( g );
		}
	}

	public GeometricPoint getPoint( double t ){
		SphericalPoint X = new SphericalPoint( L.A.getPoint() );
		SphericalPoint Y = new SphericalPoint( L.B.getPoint() );
		SphericalPoint C = new SphericalPoint( X.cross(Y) );
		SphericalLine l = new SphericalLine( A, C );
		return l.getPoint( t );
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == L || A.uses(obj) || L.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int l = GeometricPanel.getIndex( L );
		return "SPHERICAL_PERPENDICULAR_LINE(" + a + "," + l + "," + GeometricToolbox.getColor( color ) +")";
	}
}