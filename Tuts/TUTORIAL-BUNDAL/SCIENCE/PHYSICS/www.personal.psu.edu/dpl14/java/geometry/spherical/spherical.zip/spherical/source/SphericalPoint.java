import java.awt.*;
import java.awt.geom.*;
import Geometry.*;

public class SphericalPoint extends GeometricPoint{
   
    public SphericalPoint(){
		this( 0.0, 0.0, 1.0, Color.black );
    }
            
    public SphericalPoint( double x, double y ){
		this( x, y, Math.sqrt(1-x*x-y*y), Color.black );
    }
    
    public SphericalPoint( double x, double y, Color color ){
		this( x, y, Math.sqrt(1-x*x-y*y), color );
    }
    
    public SphericalPoint( double x, double y, double z ){
		this( x, y, z, Color.black );
    }
    
    public SphericalPoint( double x, double y, double z, Color color ){
		double d = Math.sqrt( x*x + y*y + z*z );
		this.x = x/d;
		this.y = y/d;
		this.z = z/d;
		this.color = color;
		this.isMovable = true;
		this.threshold = 0.05;
    }

    public SphericalPoint( SphericalPoint p ){
		this( p.x, p.y, p.z );
    }
	
    public SphericalPoint( GeometricPoint p ){
		this( p.x, p.y, p.z );
    }

    public double distance( GeometricPoint p ){
		GeometricPoint P0 = this.getPoint();
		GeometricPoint P1 = p.getPoint();
		return Math.acos( P0.dot(P1) );
    }    
    
    public GeometricPoint toScreenCoordinates(){
		GeometricPoint XAXIS = SphericalPanel.XAXIS;
		GeometricPoint YAXIS = SphericalPanel.YAXIS;
		GeometricPoint ZAXIS = SphericalPanel.ZAXIS;
		GeometricPoint P = this.getPoint();
		return XAXIS.scale(P.x).add(YAXIS.scale(P.y)).add(ZAXIS.scale(P.z));
    }

    public void draw( Graphics2D g ){
		int W = SphericalPanel.w;
		int H = SphericalPanel.h;
		double R = Math.min(W/2.0,H/2.0);
		
		// Convert this point to screen coordinates
		GeometricPoint C = this.toScreenCoordinates();
		if ( this.exists ){
	
			// add perspective
			//double d = 10;
			//X.x *= d/(d-X.z)*(1-d/5000);
			//X.y *= d/(d-X.z)*(1-d/5000);
			//X.z *= d/(d-X.z);
/*
			int r = (int)(1.5*(X.z*X.z+X.z+1))+1;
			if ( X.z < 0 ) g.setColor( Color.lightGray );
			g.fillOval( W/2 + (int)(R*X.x)-r, H/2 - (int)(R*X.y)-r, 2*r, 2*r );
			if ( mouseOver || isSelected )
				g.drawOval( W/2 + (int)(R*X.x)-r-2, H/2 - (int)(R*X.y)-r-2, 2*r+4, 2*r+4 );
*/	
			double theta = Math.asin(Math.abs(C.x)/Math.sqrt(C.x*C.x+C.y*C.y));
			if ( C.x > 0 ){
				if ( C.y > 0 ){
					theta *= -1;
				} else {
					theta += Math.PI;
				}
			} else if ( C.y < 0 ){
				theta = Math.PI - theta;
			}

			double rx = (int)(1.5*(C.z*C.z+C.z+1))+1;
			rx = 4.0;
			double ry = Math.abs(C.z*rx);
	
			AffineTransform rot = AffineTransform.getRotateInstance( -theta, W/2+R*C.x, H/2-R*C.y);
			g.setTransform(rot);
			g.setColor( this.color );
			if ( C.z < 0 ) g.setColor( Color.lightGray );
			if ( isMovable ){
				g.fill( new Arc2D.Double(W/2-rx+R*C.x, H/2-ry-R*C.y, 2*rx, 2*ry, 0, 360, Arc2D.OPEN ) );
				if ( mouseOver || isSelected )
					g.draw( new Arc2D.Double(W/2-rx+R*C.x-2, H/2-ry-R*C.y-2, 2*rx+4, 2*ry+4, 0, 360, Arc2D.OPEN ) );
			} else {
				if ( mouseOver || isSelected ){
					g.setStroke( new BasicStroke( 5.0f ) );
					g.draw( new Line2D.Double(W/2-rx+R*C.x, H/2-ry-R*C.y, W/2+rx+R*C.x, H/2+ry-R*C.y ) );
					g.draw( new Line2D.Double(W/2-rx+R*C.x, H/2+ry-R*C.y, W/2+rx+R*C.x, H/2-ry-R*C.y ) );
					g.setColor( Color.white );
					g.setStroke( new BasicStroke( 3.0f ) );
					g.draw( new Line2D.Double(W/2-rx+R*C.x, H/2-ry-R*C.y, W/2+rx+R*C.x, H/2+ry-R*C.y ) );
					g.draw( new Line2D.Double(W/2-rx+R*C.x, H/2+ry-R*C.y, W/2+rx+R*C.x, H/2-ry-R*C.y ) );
				}
				g.setStroke( new BasicStroke( 2.0f ) );
				g.draw( new Line2D.Double(W/2-rx+R*C.x, H/2-ry-R*C.y, W/2+rx+R*C.x, H/2+ry-R*C.y ) );
				g.draw( new Line2D.Double(W/2-rx+R*C.x, H/2+ry-R*C.y, W/2+rx+R*C.x, H/2-ry-R*C.y ) );
			}
			g.setTransform( new AffineTransform() );
		}
    }

    public GeometricPoint getPoint(){
		return new SphericalPoint( this );
    }
    

	public String toString(){
		GeometricPoint P = this.getPoint();
		return "SPHERICAL_POINT(" + P.x + "," + P.y + "," + P.z + "," + GeometricToolbox.getColor( color ) + ")";
	}

/*
	// rotate this point an angle of theta radians about myVector v
	public void rotate( double theta, myVector v ){
		myVector q = new myVector( v );
		myVector t = new myVector( this );
		q.scale( t.dot(q)/q.dot(q) );
			
		x -= q.dx; y -= q.dy; z -= q.dz;
		
		myVector perp = v.cross( t );
		perp.scale( Math.sin(theta)/v.length() );
		this.scale( Math.cos(theta) );
		
		x += perp.dx + q.dx; y += perp.dy + q.dy; z += perp.dz + q.dz;
	}
*/
}