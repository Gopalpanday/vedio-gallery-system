import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import Geometry.*;

public class EuclideanToolbox extends GeometricToolbox{
	
	
	public void init(){
		frame = new JFrame();
			frame.setVisible(false);
			frame.setSize(600, 600);
			frame.setLocation(0,0);
			frame.setTitle( "" );

		contentpane = frame.getContentPane();

		if ( getParameter("mode").equals("LOCKED") ){
			LOCKED = true;
			type = EuclideanObject.POINT;
			contentpane = this.getContentPane();
		}

		setup();
		
		contentpane.add( "Center", panel = new EuclideanPanel( this ) );

		int i=1;
		while ( getParameter("object_"+i) != null ){
			first = panel.firstObject;  // so that getObject knows where to start looking
			panel.addObject( parseObject(getParameter("object_"+i)) );
			i++;
		}
		
		frame.addWindowListener( this );
		panel.requestFocus();
	}
	
	

	public GeometricObject parseObject( String s ){
		int openparan = s.indexOf("(");
		String object = s.substring(0,openparan).trim();
		StringTokenizer st = new StringTokenizer( s.substring(openparan+1,s.length()-1), "," );
		EuclideanPoint X;
		EuclideanPoint Y;
		EuclideanPoint Z;
		EuclideanLine L;
		EuclideanLine M;
		EuclideanLineSegment LS;
		EuclideanCircle C;
		EuclideanCircle D;
		int I;
		double a;

		if ( object.equals("ANGLE_BISECTOR") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Z = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanAngleBisector( X, Y, Z, getColor(st.nextToken()) );
		} else if ( object.equals("ANGLE_TRISECTOR") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Z = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanAngleTrisector( X, Y, Z, getColor(st.nextToken()) );
		} else if ( object.equals("CENTROID") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Z = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanCentroid( X, Y, Z, getColor(st.nextToken()) );
		} else if ( object.equals("CIRCLE") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanCircle( X, Y, getColor(st.nextToken()) );
		} else if ( object.equals("CIRCLE_FIXED_RADIUS") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			I = Integer.parseInt( st.nextToken() );
			return new EuclideanCircleFixedRad( X, I, getColor(st.nextToken()) );
		} else if ( object.equals("CIRCLE_INTERSECTION") ){
			C = (EuclideanCircle)getObject( Integer.parseInt( st.nextToken() ) );
			D = (EuclideanCircle)getObject( Integer.parseInt( st.nextToken() ) );
			I = Integer.parseInt(st.nextToken());
			return new EuclideanCircleIntersect( C, D, I, getColor(st.nextToken()) );
		} else if ( object.equals("CIRCUMCENTER") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Z = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanCircumcenter( X, Y, Z, getColor(st.nextToken()) );
		} else if ( object.equals("CIRCUMSCRIBED_CIRCLE") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Z = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanCircumCircle( X, Y, Z, getColor(st.nextToken()) );	
		} else if ( object.equals("EQUILATERAL_TRIANGLE") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			//return new EuclideanEquilateralTriangle( X, Y, getColor(st.nextToken()) );
			return null;
		} else if ( object.equals("EULER_LINE") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Z = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanEulerLine( X, Y, Z, getColor(st.nextToken()) );
		} else if ( object.equals("INCENTER") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Z = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanIncenter( X, Y, Z, getColor(st.nextToken()) );
		} else if ( object.equals("INSCRIBED_CIRCLE") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Z = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanInscribedCircle( X, Y, Z, getColor(st.nextToken()) );
		} else if ( object.equals("INVERSION") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			C = (EuclideanCircle)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanInversion( X, C, getColor(st.nextToken()) );
		} else if ( object.equals("LINE") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanLine( X, Y, getColor(st.nextToken()) );
		} else if ( object.equals("LINE_INTERSECTION") ){
			L = (EuclideanLine)getObject( Integer.parseInt( st.nextToken() ) );
			M = (EuclideanLine)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanLineIntersect( L, M, getColor(st.nextToken()) );
		} else if ( object.equals("LINE_CIRCLE_INTERSECTION") ){
			L = (EuclideanLine)getObject( Integer.parseInt( st.nextToken() ) );
			C = (EuclideanCircle)getObject( Integer.parseInt( st.nextToken() ) );
			I = Integer.parseInt(st.nextToken());
			return new EuclideanLCIntersect( L, C, I, getColor(st.nextToken()) );
		} else if ( object.equals("LINE_SEGMENT") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanLineSegment( X, Y, getColor(st.nextToken()) );
		} else if ( object.equals("MIDPOINT") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanMidpoint( X, Y, getColor(st.nextToken()) );
		} else if ( object.equals("ORTHOCENTER") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Z = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanOrthocenter( X, Y, Z, getColor(st.nextToken()) );
		} else if ( object.equals("PARALLEL_LINE") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			L = (EuclideanLine)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanParallelLine( X, L, getColor(st.nextToken()) );
		} else if ( object.equals("PERPENDICULAR_BISECTOR") ){
			LS = (EuclideanLineSegment)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanPerpBisector( LS, getColor(st.nextToken()) );
		} else if ( object.equals("PERPENDICULAR_LINE") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			L = (EuclideanLine)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanPerpLine( X, L, getColor(st.nextToken()) );
		} else if ( object.equals("POINT") ){
			double x = Double.parseDouble( st.nextToken() );
			double y = Double.parseDouble( st.nextToken() );
			return new EuclideanPoint( x, y, getColor(st.nextToken()) );
		} else if ( object.equals("POINT_ON_CIRCLE") ){
			C = (EuclideanCircle)getObject( Integer.parseInt( st.nextToken() ) );
			I = Integer.parseInt( st.nextToken() );
			return new EuclideanPointOnCircle( C, I, getColor(st.nextToken()) );
		} else if ( object.equals("POINT_ON_LINE") ){
			L = (EuclideanLine)getObject( Integer.parseInt( st.nextToken() ) );
			a = Double.parseDouble( st.nextToken() );
			return new EuclideanPointOnLine( L, a, getColor(st.nextToken()) );
		} else if ( object.equals("PROJECTION") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			L = (EuclideanLine)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanProjection( X, L, getColor(st.nextToken()) );
		} else if ( object.equals("RAY") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanRay( X, Y, getColor(st.nextToken()) );
		} else if ( object.equals("REFLECTION") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			L = (EuclideanLine)getObject( Integer.parseInt( st.nextToken() ) );
			return new EuclideanReflection( X, L, getColor(st.nextToken()) );
		} else if ( object.equals("SQUARE") ){
			X = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			Y = (EuclideanPoint)getObject( Integer.parseInt( st.nextToken() ) );
			//return new EuclideanSquare( X, Y, getColor(st.nextToken()) );
			return null;
		} else {
			return null;
		}
	}
}

