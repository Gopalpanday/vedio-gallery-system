import java.awt.*;
import Geometry.*;

public class EuclideanCentroid extends EuclideanPoint{

    EuclideanPoint A;
    EuclideanPoint B;
    EuclideanPoint C;

    public EuclideanCentroid( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C ){
		this( A, B, C, Color.black );
    }
    
    public EuclideanCentroid( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.C = C;
		this.color = color;
		this.isMovable = false;
    }
    
    public GeometricPoint getPoint(){
		GeometricPoint AP = A.getPoint();
		GeometricPoint BP = B.getPoint();
		GeometricPoint CP = C.getPoint();
		this.exists = ( A.exists && B.exists && C.exists );
		return new GeometricPoint( (AP.x + BP.x + CP.x)/3.0, (AP.y + BP.y + CP.y)/3.0);
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || obj == C || A.uses(obj) || B.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		int c = GeometricPanel.getIndex( C );
		return "EUCLIDEAN_CENTROID(" + a + "," + b + "," + c + "," + GeometricToolbox.getColor( color ) +")";
	}
}