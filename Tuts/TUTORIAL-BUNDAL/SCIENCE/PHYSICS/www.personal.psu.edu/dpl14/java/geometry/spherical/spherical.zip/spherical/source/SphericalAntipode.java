import java.awt.*;
import Geometry.*;

public class SphericalAntipode extends SphericalPoint{

    SphericalPoint A;
   
    public SphericalAntipode( SphericalPoint A ){
		this( A, Color.black );
    }
    
    public SphericalAntipode( SphericalPoint A, Color color ){
		super();
		this.A = A;
		this.color = color;
		this.isMovable = false;
    }
    
    public GeometricPoint getPoint(){
		this.exists = A.exists;
		return A.scale(-1);
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == A || A.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = SphericalPanel.getIndex( A );
		return "ANTIPODE(" + a + "," + GeometricToolbox.getColor( color ) +")";
	}
}