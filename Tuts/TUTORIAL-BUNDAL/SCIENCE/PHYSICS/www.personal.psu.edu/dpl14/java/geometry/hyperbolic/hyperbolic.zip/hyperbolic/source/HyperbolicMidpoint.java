import java.awt.*;
import Geometry.*;

public class HyperbolicMidpoint extends HyperbolicPoint{

    private HyperbolicPoint A;
    private HyperbolicPoint B;

    public HyperbolicMidpoint( HyperbolicPoint A, HyperbolicPoint B ){
		this( A, B, Color.black );
    }

    public HyperbolicMidpoint( HyperbolicPoint A, HyperbolicPoint B, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.color = color;
		this.isMovable = false;
    }

    public GeometricPoint getPoint(){
		// find Mobius transformation M to send A to (0,0)
		// use this transformation on B resulting in MB
		HyperbolicPoint numer = new HyperbolicPoint( B.subtract(A) );
		HyperbolicPoint denom = A.conjugate().multiply(B);
			denom.x = 1 - denom.x;
			denom.y = -denom.y;
		HyperbolicPoint MB = numer.divide(denom);
		// find midpoint MM of (0,0) and MB
		double y = MB.length();
		//double d = Math.log((1+y)/(1-y))/2;
		//double z = (Math.exp(d) - 1)/(Math.exp(d) + 1)/y;
		double z = (1-Math.sqrt(1-y*y))/(y*y);
		HyperbolicPoint MM = new HyperbolicPoint( MB.x*z, MB.y*z );
		// use inverse transformation to produce M, the midpoint of A and B
		numer = new HyperbolicPoint( MM.add(A) );
		denom = A.conjugate().multiply(MM);
			denom.x = 1 + denom.x;
		return numer.divide(denom);
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || A.uses(obj) || B.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		return "HYPERBOLIC_MIDPOINT(" + a + "," + b + "," + GeometricToolbox.getColor( color ) +")";
	}
}