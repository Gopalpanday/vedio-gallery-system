import java.awt.*;
import Geometry.*;

public class EuclideanAngleBisector extends EuclideanLine{

    public EuclideanAngleBisector( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C ){
		this( A, B, C, Color.black );
    }

    public EuclideanAngleBisector( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.C = C;
		this.color = color;
    }

    public GeometricPoint getPoint( double t ){
		EuclideanPoint P = (EuclideanPoint)( B.add(C.subtract(B).scale(A.distance(B)/B.distance(C))) );
		EuclideanPoint M = new EuclideanMidpoint( A, P );
		this.exists = ( A.exists && B.exists && C.exists );
		return B.add( M.subtract(B).scale(t) );
    }
    
    public double distance( GeometricPoint p ){
		EuclideanPoint P = (EuclideanPoint)( B.add(C.subtract(B).scale(A.distance(B)/B.distance(C))) );
		EuclideanPoint M = new EuclideanMidpoint( A, P );
		EuclideanLine l = new EuclideanLine( B, M );
		return l.distance( p );
    }
    
    public void draw( Graphics2D g ){
		EuclideanPoint P = (EuclideanPoint)( B.add(C.subtract(B).scale(A.distance(B)/B.distance(C))) );
		EuclideanPoint M = new EuclideanMidpoint( A, P );
		this.exists = ( A.exists && B.exists && C.exists );
		if ( this.exists ){
			EuclideanLine l = new EuclideanLine( B, M, color );
			l.mouseOver = this.mouseOver;
			l.isSelected = this.isSelected;
			l.draw( g );
		}
    }

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || obj == C || A.uses(obj) || B.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		int c = GeometricPanel.getIndex( C );
		return "EUCLIDEAN_ANGLE_BISECTOR(" + a + "," + b + "," + c + "," + GeometricToolbox.getColor( color ) +")";
	}
}