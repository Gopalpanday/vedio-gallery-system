import java.awt.*;
import Geometry.*;

public class EuclideanIncenter extends EuclideanPoint{

	private EuclideanPoint A;
	private EuclideanPoint B;
	private EuclideanPoint C;

	public EuclideanIncenter( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C ){
		this( A, B, C, Color.black );
	}

	public EuclideanIncenter( EuclideanPoint A, EuclideanPoint B, EuclideanPoint C, Color color ){
		super();
		this.A = A;
		this.B = B;
		this.C = C;
		this.color = color;
		this.isMovable = false;
	}

	public GeometricPoint getPoint(){
		double perimeter = A.distance( B ) + B.distance( C ) + C.distance( A );
		this.exists = ( A.exists && B.exists && C.exists ); // note that A.getPoint() is called in line above
		double t = A.distance(C)/perimeter;
		return A.add( B.subtract(A).add(C.subtract(A).scale(A.distance(B)/A.distance(C))).scale(t) );
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == A || obj == B || obj == C || A.uses(obj) || B.uses(obj) || C.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int a = GeometricPanel.getIndex( A );
		int b = GeometricPanel.getIndex( B );
		int c = GeometricPanel.getIndex( C );
		return "EUCLIDEAN_INCENTER(" + a + "," + b + "," + c + "," + GeometricToolbox.getColor( color ) +")";
	}
}