import java.awt.*;
import Geometry.*;

public class EuclideanPointOnLine extends EuclideanPoint{

	EuclideanLine L;

	public EuclideanPointOnLine( EuclideanLine L, EuclideanPoint A ){
		this( L, A, Color.black );
	}

	public EuclideanPointOnLine( EuclideanLine L, EuclideanPoint A, Color color ){
		super();
		this.L = L;
		setPoint( A );
		this.color = color;
		this.isMovable = true;
	}

	public EuclideanPointOnLine( EuclideanLine L, double x ){
		this( L, x, Color.black );
	}

	public EuclideanPointOnLine( EuclideanLine L, double x, Color color ){
		this.L = L;
		this.x = x;
		this.color = color;
		this.isMovable = true;
	}

	public void setPoint( EuclideanPoint A ){
		GeometricPoint P = new EuclideanProjection( new EuclideanPoint(A.getPoint()), L ).getPoint();
		GeometricPoint X = L.getPoint( 0.0 );
		GeometricPoint Y = L.getPoint( 1.0 );
		double oldx = this.x;
		if ( X.x != Y.x ){
			this.x = (P.x-X.x)/(Y.x-X.x);
		} else {
			this.x = (P.y-X.y)/(Y.y-X.y);
		}
		
		GeometricPoint d = L.getPoint( x ).subtract( L.getPoint(oldx) );
		LinkedPoints tmp = firstPoint;
		while ( tmp.point != null ){
			tmp.point.translate( d.x, d.y );
			tmp = tmp.next;
		}
	}

	public GeometricPoint getPoint(){
		GeometricPoint P = L.getPoint( x );
		this.exists = L.exists;
		return P;
	}

	public boolean uses( GeometricObject obj ){
		if ( obj == L || L.uses(obj) ) return true;
		return false;
	}

	public String toString(){
		int l = GeometricPanel.getIndex( L );
		return "EUCLIDEAN_POINT_ON_LINE(" + l + "," + x + "," + GeometricToolbox.getColor( color ) +")";
	}
}