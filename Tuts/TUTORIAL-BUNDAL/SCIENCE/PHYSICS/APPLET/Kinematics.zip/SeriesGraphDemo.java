// Class   : SeriesGraphDemo
// Author  : Russ Ethington
// Version : 1/28/96 for Java 1.0
// Notice  : Copyright (C) 1995, 1996 Russ Ethington

import java.io.*;   
import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;

public class SeriesGraphDemo extends Applet
{
   private SeriesGraph seriesGraph;
   private Panel       buttonPanel;
   private Vector      theNames;
   private Vector      theDates;
   private Vector      theValues;

   public static void main(String args[]) 
   {
      Frame frame = new Frame("SeriesGraphDemo");
      SeriesGraphDemo seriesGraphDemo = new SeriesGraphDemo();
      seriesGraphDemo.init();
      seriesGraphDemo.start();

      frame.add("Center", seriesGraphDemo);
      frame.resize(300, 200);
      frame.show();
   }

   public void init() 
   {
      debugLog("SeriesGraphDemo:init");

      setLayout(new BorderLayout());
      
      seriesGraph = new SeriesGraph();
      theNames = new Vector();
      theDates = new Vector();
      theValues = new Vector();
      
      buttonPanel = new Panel();
      buttonPanel.setLayout(new GridLayout(1, 3));
      buttonPanel.add(new Button("Humidity"));
      buttonPanel.add(new Button("Temperature"));
      buttonPanel.add(new Button("Pressure"));

      add("Center", seriesGraph);
      add("South", buttonPanel);

      setData(20, 100);
      seriesGraph.setTitle("Daily Relative Humidity");
      seriesGraph.updateView(theNames, theDates, theValues);
   }

   public void setData(int low, int high)
   {
      debugLog("SeriesGraphDemo:setData");

      int totalSets =   2;
      int totalValues = 28;

      theNames.removeAllElements();
      theDates.removeAllElements();
      theValues.removeAllElements();

      for (int i = 0; i < totalSets; i++)
      {
         theNames.addElement("Data Set " + Integer.toString(i));

         Vector newDates = new Vector();
         Vector newValues = new Vector();

         theDates.addElement(newDates);
         theValues.addElement(newValues);

         for (int j = 0; j < totalValues; j++)
         {
            String fakeDate = Integer.toString(i + 1) + "/" + Integer.toString(j) + "/95";           
            newDates.addElement(new String(fakeDate));
            double value = Math.random() * (high - low) + low;
            String fakeData = String.valueOf(value);            
            newValues.addElement(new String(fakeData));
         }
      }
   }

   public boolean action(Event event, Object object) 
   {
      debugLog("SeriesGraphDemo:action");
      
      if (event.target instanceof Button) 
      {
         if (((String) object).equals("Humidity"))
         {
            setData(20, 100);
            seriesGraph.setTitle("Daily Relative Humidity");
         }
         else
         if (((String) object).equals("Temperature"))
         {
            setData(0,  30);
            seriesGraph.setTitle("Daily Temperature (C)");
         }
         else
         if (((String) object).equals("Pressure"))
         {
            setData(800, 1500);
            seriesGraph.setTitle("Daily Barometric Pressure (mb)");
         }
         seriesGraph.updateView(theNames, theDates, theValues);
         seriesGraph.repaint();
         return true;
      }
      return false;
   }

   public void start()
   {
      debugLog("SeriesGraphDemo:start");
   }

   public void stop()
   {
      debugLog("SeriesGraphDemo:stop");
   }

   public void debugLog(String message)
   {
//    System.out.println(message);
   }
}
