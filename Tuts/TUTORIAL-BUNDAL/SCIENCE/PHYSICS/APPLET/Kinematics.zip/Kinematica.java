/* Kinematica.java  v0.9  (18 Aug 1996)
    Rob Salgado - salgado@physics.syr.edu
*/

import java.applet.*;
import java.awt.*;
import java.lang.Math;
import java.lang.String;
import java.util.*;

class Coordinate { int x, y;}
class GraphParameters { double x0, v0, a0; double MouseX, MouseY;}

//----------------------------------------------------------------
class simulationCanvas extends Canvas
{
    //-----------------------------DATA MEMBERS
    // only for quadratic functions
    private double x0=0.0, v0=0.0, a0=0.0;

    // for graph
    private double xmin, xmax, ymin, ymax;
    public Color fgcolor=Color.white,bgcolor=Color.black,axcolor=Color.gray,gridcolor=Color.cyan,
            ptcolor=Color.blue,tempcolor;
    private static Dimension minSize;
    private static int GraphHeight=200, GraphWidth=200;
    private static int START_X, START_Y, MIDDLE_X,MIDDLE_Y,UNIT;
    static double Scale=20.0;
    static FontMetrics fm;
    String xLabel, yLabel;
    //for double-buffering
    private Image Im2;
    private Graphics g2;
    //for mouse
    static int MouseUp = 1, MouseIn =0;
    public int MouseY;
    public static int MouseX;
    private double GraphX, GraphY;
    //
    Container parent;

    public simulationCanvas(Container theParent)
    {   parent=theParent;
          minSize = new Dimension(GraphHeight,GraphWidth);
          resize(minSize);
           bgcolor=Color.white;
           fgcolor=Color.green;
           axcolor=Color.black;

    }

    public void update(Graphics g)
    {
        paint(g);
    }
    public void paint(Graphics g)
    {
            if (g2==null) graphSetup();
            else if ((this.size().width!=GraphWidth) ||
                     (this.size().height!=GraphHeight)) graphSetup();
            gDraw();

            g.drawImage(Im2,0,0,this);
            //resize(new Dimension(GraphHeight, GraphWidth));
    }


    public void graphSetup()
    {
            SetGraphSize(parent.size().height/3-10,parent.size().width/3-10);
            Im2=createImage(GraphHeight, GraphWidth);
            g2=Im2.getGraphics();
            fm=g2.getFontMetrics(this.getFont());
    }

    public double gx(int mx)        {   return  (double)(mx-MIDDLE_X)/(double)UNIT; }
    public double gy(int my)        {   return -(double)(my-MIDDLE_Y)/(double)UNIT; }
    public int mx(double gx)        {   return  (int)(gx * (double)UNIT) + MIDDLE_X;}
    public int my(double gy)        {   return -(int)(gy * (double)UNIT) + MIDDLE_Y;}
    public double tenths(double val){   return Math.rint(val*10.0)/10.0;}

    private void gMiddle()
    {
        MIDDLE_X = (int)(GraphWidth / 2);
        MIDDLE_Y = (int)(GraphHeight / 2);
        UNIT = (int)(GraphWidth / Scale);
        START_X =  MIDDLE_X- (MIDDLE_X / UNIT) * UNIT;
        START_Y =  MIDDLE_Y- (MIDDLE_Y / UNIT) * UNIT;
    }


    private void gDraw ()
    {
        double x,y;
        int Y, OLD_Y;

        //---
        x=gx(0);
        y = 0;Y=my(y);
        for (int i = -1; i <= GraphWidth; i++)
        {
            x=gx(i);
            OLD_Y =  Y; y  = x0+v0*x+ a0*x*x/2.0 ; Y=my(y);
            g2.setColor (fgcolor);
            g2.drawLine (i - 1, OLD_Y, i, Y);
        }
    }

    void SetGraphSize (int newHeight, int newWidth)
    {
        GraphHeight=newHeight;
        GraphWidth=newWidth;
    }

}

    // A graph widget
class graphCanvas extends Canvas
{
    //-----------------------------DATA MEMBERS
    // only for quadratic functions
    private int whichFunction;
    private double x0=0.0, v0=0.0, a0=0.0;

    // for graph
    private double xmin, xmax, ymin, ymax;
    public Color fgcolor=Color.white,bgcolor=Color.black,axcolor=Color.gray,gridcolor=Color.cyan,
            ptcolor=Color.blue,tempcolor;
    private static Dimension minSize;
    private static int GraphHeight=200, GraphWidth=200;
    private static int START_X, START_Y, MIDDLE_X,MIDDLE_Y,UNIT;
    static double Scale=20.0;
    static Coordinate dragFrom = new Coordinate();
    static Coordinate dragTo = new Coordinate();
    static Coordinate Origin = new Coordinate();
    static FontMetrics fm;
    String xLabel, yLabel;
    //options
    boolean drawXAxis=true, drayYAxis=true, drawGrid=true;
    boolean drawPoint=true, drawSlope=true, drawArea=true;
    //for double-buffering
    private Image Im2;
    private Graphics g2;
    //for mouse
    static int MouseUp = 1, MouseIn =0;
    public int MouseY;
    public static int MouseX;
    private double GraphX, GraphY;
    //
    Container parent;

    //-----------------------------METHODS
    //constructor method
    public graphCanvas(Container theParent)
    {   parent=theParent;
          minSize = new Dimension(GraphHeight,GraphWidth);
          resize(minSize);
           bgcolor=Color.white;
           fgcolor=Color.green;
           axcolor=Color.black;
           Origin.x = 0;
           Origin.y = 0;
           //graphSetup();

    }

    //for identifying functions
    public void graphFunction(double newx0, double newv0, double newa0) {
        whichFunction=1;
        x0=newx0;v0=newv0;a0=newa0;
        repaint();
        }
    public void graphFunction(double newv0, double newa0) {
        whichFunction=2;
        v0=newv0;a0=newa0;
        repaint();
        }
    public void graphFunction(double newa0) {
        whichFunction=3;
        a0=newa0;
        repaint();
        }
    //for graphing functions
    private double function(double t)
    {
       double ans;
       switch (whichFunction)
       {
         case 1: ans=(x0+v0*t+a0*t*t/2.0);break;
         case 2: ans=(v0+a0*t);break;
         case 3: ans=(a0);break;
         default: ans=0.0;break;
       }
       return(ans);
    }
    //for evaluating a function (or its derivatives) at a point
    private double function(int wF, double t)
    {
       double ans;
       switch (wF)
       {
         case 1: ans=(x0+v0*t+a0*t*t/2.0);break;
         case 2: ans=(v0+a0*t);break;
         case 3: ans=(a0);break;
         default: ans=0.0;break;
       }
       return(ans);
    }

    void SetGraphSize (int newHeight, int newWidth)
    {
        GraphHeight=newHeight;
        GraphWidth=newWidth;
    }
    public Dimension preferredSize()
    {
        return minimumSize();
    }
    public synchronized Dimension minimumSize()
    {
        return minSize;
    }

    // Canvas mouse routines
    public boolean mouseDown (Event evt, int x, int y)
    {
        MouseIn=whichFunction;
        dragFrom.x = x;
        dragFrom.y = y;
        MouseUp = 0;
        return false;
    }
    public boolean mouseDrag (Event evt, int x, int y)
    {
        MouseIn=whichFunction;
        dragTo.x = x;
        dragTo.y = y;
        parent.repaint ();
        return false;
    }
    public boolean mouseUp (Event evt, int x, int y)
    {
        Origin.x += dragTo.x - dragFrom.x;
        Origin.y += dragTo.y - dragFrom.y;
        dragFrom.x = dragTo.x;
        dragFrom.y = dragTo.y;
        MouseUp = 1;
        repaint ();
        return false;
    }
    public boolean mouseMove(Event evt, int x, int y)
    {
        MouseIn=whichFunction;
        MouseX=x;MouseY=y;
        parent.repaint();
        return false;
    }

    public boolean mouseEnter(Event evt, int x, int y)
    {
        MouseIn=whichFunction;
        return true;
    }

    public boolean mouseExit(Event evt, int x, int y)
    {
        MouseIn=0;
        repaint();
        return true;
    }

    public void update(Graphics g)
    {
        paint(g);
    }
    public void paint(Graphics g)
    {
            if (g2==null) graphSetup();
            else if ((this.size().width!=GraphWidth) ||
                     (this.size().height!=GraphHeight)) graphSetup();
            gDrawCoordSystem();
            gDraw();
            gOptions();

            g.drawImage(Im2,0,0,this);
            //resize(new Dimension(GraphHeight, GraphWidth));
    }


    public void graphSetup()
    {
            SetGraphSize(parent.size().height/3-10,parent.size().width/3-10);
            Im2=createImage(GraphHeight, GraphWidth);
            g2=Im2.getGraphics();
            fm=g2.getFontMetrics(this.getFont());
    }

    private void gMiddle()
    {
        MIDDLE_X = (int)(GraphWidth / 2) + Origin.x + dragTo.x - dragFrom.x;
        MIDDLE_Y = (int)(GraphHeight / 2) + Origin.y + dragTo.y - dragFrom.y;
        UNIT = (int)(GraphWidth / Scale);
        START_X = MIDDLE_X - (MIDDLE_X / UNIT) * UNIT;
        START_Y = MIDDLE_Y - (MIDDLE_Y / UNIT) * UNIT;
    }
    private void gDrawCoordSystem ()
    {
        gMiddle();
        // First clear the hidden Image
        g2.setColor (bgcolor);g2.fillRect(0,0, GraphWidth, GraphHeight);

        g2.setColor (gridcolor);
/*        // Draw  grid
        for (int delta = START_X; delta <= GraphWidth; delta += UNIT)
            g2.drawLine (delta, 0, delta, GraphHeight);
        for (int delta = START_Y; delta <= GraphHeight; delta += UNIT)
            g2.drawLine (0, delta, GraphWidth, delta);
*/        // Draw x and y-axis
        g2.setColor (axcolor);
        g2.drawLine (0, MIDDLE_Y, GraphWidth-1, MIDDLE_Y);      // x-axis
        g2.drawLine (MIDDLE_X, 0, MIDDLE_X, GraphHeight-1);     // y-axis
        // Draw  tickmarks
        for (int delta = START_X; delta <= GraphWidth; delta += UNIT)
            g2.drawLine (delta, MIDDLE_Y + 2, delta, MIDDLE_Y - 2);
        for (int delta = START_Y; delta <= GraphHeight; delta += UNIT)
            g2.drawLine (MIDDLE_X - 2, delta, MIDDLE_X + 2, delta);
        // Draw axis-labels
        for (int delta = MIDDLE_X+5*UNIT; delta <= GraphWidth; delta += 5*UNIT)
        {
            xLabel=""+gx(delta);
            g2.drawString(xLabel,
                        delta-fm.stringWidth(xLabel)/2,MIDDLE_Y+fm.getAscent());
        }
        for (int delta = MIDDLE_Y-5*UNIT; delta >= -GraphHeight; delta -= 5*UNIT)
        {
            yLabel=""+gy(delta);
            g2.drawString(yLabel,
                        MIDDLE_X - fm.stringWidth(yLabel), delta+fm.getAscent()/2);
        }

    }
    private void gDraw ()
    {
        gMiddle();

        double x,y;
        int Y, OLD_Y;
        //---
        x=gx(0);
        y = 0;Y=my(y);
        for (int i = -1; i <= GraphWidth; i++)
        {
            x=gx(i);
            OLD_Y =  Y; y  =  function(x); Y=my(y);
            g2.setColor (fgcolor);
            g2.drawLine (i - 1, OLD_Y, i, Y);
        }
    }
    private void gOptions()
    {
        GraphX=tenths(gx(MouseX));
        if (MouseIn!=0)
        {
            switch(whichFunction-MouseIn)
            {
                case -1: gShowSlope(GraphX);gShowPoint(GraphX);gLabelPoint(GraphX);break;
                case 0: gShowRise(GraphX);gShowPoint(GraphX);gLabelPoint(GraphX);break;
                case 1: gShowAreaUnder(GraphX);gShowPoint(GraphX);gLabelPoint(GraphX);break;
                default: break;
            }
        }

    }

    public double gx(int mx)        {   return  (double)(mx-MIDDLE_X)/(double)UNIT; }
    public double gy(int my)        {   return -(double)(my-MIDDLE_Y)/(double)UNIT; }
    public int mx(double gx)        {   return  (int)(gx * (double)UNIT) + MIDDLE_X;}
    public int my(double gy)        {   return -(int)(gy * (double)UNIT) + MIDDLE_Y;}
    public double tenths(double val){   return Math.rint(val*10.0)/10.0;}

    public boolean isNearGraph(int testX, int testY)
    {
        boolean answer=false;
        int Y;
        GraphY=tenths(gy(MouseY));
        if (MouseIn==whichFunction) {
                Y=mx(function(GraphX));
                answer = (Math.abs(Y-testY) <= 10) ? true: false;
        }
        return answer;
    }
    public void gShowPoint(double newX)
    {
        double y;
        int Y;
        GraphY=tenths(gy(MouseY));
        y=function(newX);Y=my(y);
        g2.fillRect(MouseX-2,Y-2,4,4);
    }
    public void gLabelPoint(double newX)
    {
        double y;
        int Y;
        GraphY=tenths(gy(MouseY));
        y=function(newX);Y=my(y);
        xLabel=""+newX;
        g2.setColor(Color.black);
        g2.drawString(xLabel,
                        mx(newX)-fm.stringWidth(xLabel)/2,MIDDLE_Y+fm.getAscent());
        yLabel=""+y;
        g2.drawString(yLabel,
                        MIDDLE_X - fm.stringWidth(yLabel), Y+fm.getAscent()/2);
    }
    public void gShowRise(double newX)
    {
        int Y;
        double z;
        if (MouseX>=MIDDLE_X)
        {
            GraphY=tenths(gy(MouseY));
            Y=my(function(newX));
            switch (MouseIn)
            {
                case 1: z=x0;break;
                case 2: z=v0;break;
                case 3: z=a0;break;
                default: z=0;break;
            }
            g2.drawLine(MouseX,Y,MouseX,my(z) );
            //g2.drawString(""+newX+","+function(newX),10,10);
        }
    }
    public void gShowSlope(double newX)
    {
        int Y;
        double DY;
        GraphY=tenths(gy(MouseY));
        Y=my(function(newX));
        g2.setColor(Color.blue);
        DY=function(whichFunction+1,newX);
        g2.drawLine(MouseX-(int)(3*UNIT),Y+(int)(DY*3*UNIT),
                    MouseX+(int)(3*UNIT),Y-(int)(DY*3*UNIT));
        g2.setColor(Color.black);
        g2.drawString("Slope "+DY,10,10);
    }
    public void gShowAreaUnder(double newX)
    {
        double x,y,z, area;
        int Y, OLD_Y;
        GraphY=tenths(gy(MouseY));

        x=gx(0);
        y = 0; Y=my(y);
        for (int i = MIDDLE_X; i <= MouseX ; i++)
            {
                if (((i-MIDDLE_X)%UNIT) !=0)
                {
                    x=gx(i);
                    OLD_Y =  Y; y = function(x); Y = my(y);

                    if (Y<=MIDDLE_Y){   g2.setColor(Color.blue);   }
                    else            {   g2.setColor(Color.red);     }
                    g2.drawLine (i, MIDDLE_Y, i, Y);
                }
            }

        switch(MouseIn)
            {
                case 1: z=x0;area=(v0+newX*a0/2)*newX;break;
                case 2: z=v0;area=(a0*newX);break;
                case 3: z=a0;area=0;break;
                default: z=0;area=0;break;
            }
         g2.setColor(Color.black);
         if (MouseX>=MIDDLE_X) g2.drawString("Area "+area,10,GraphHeight-10);
    }


}



//----------------------------------------------------------------
public class Kinematica extends Applet
{
    Coordinate dragFrom = new Coordinate();
    Coordinate dragTo = new Coordinate();
    Coordinate Origin = new Coordinate();
    Coordinate Mouse = new Coordinate();

    int MouseUp=1;

    Label x_label_x0 = new Label("x0=");
    TextField x_blank_x0 = new TextField ("",2);
    Label x_label_v0 = new Label("v0=");
    TextField x_blank_v0 = new TextField ("",2);
    Label x_label_a0 = new Label("a0=");
    TextField x_blank_a0 = new TextField ("",2);

    Label v_label_v0 = new Label("v0=");
    TextField v_blank_v0 = new TextField ("",2);
    Label v_label_a0 = new Label("a0=");
    TextField v_blank_a0 = new TextField ("",2);

    Label a_label_a0 = new Label("a0=");
    TextField a_blank_a0 = new TextField ("",2);

    graphCanvas xcanvas = new graphCanvas(this);
    graphCanvas vcanvas = new graphCanvas(this);
    graphCanvas acanvas = new graphCanvas(this);

    Panel xpanel = new Panel();
    Panel vpanel = new Panel();
    Panel apanel = new Panel();

    GridBagLayout myGBLayout = new GridBagLayout();
    GridBagConstraints myGBC = new GridBagConstraints();

    double x0=0.0, v0=0.0, a0=0.0;

    public void init ()
    {
        setLayout(myGBLayout);
        setBackground (Color.gray); //applet colors
        setForeground (Color.red);  //
    }
    public void start ()
    {
        x_blank_x0.setBackground(Color.lightGray);
        x_blank_v0.setBackground(Color.cyan);
        x_blank_a0.setBackground(Color.green);
        v_blank_v0.setBackground(Color.cyan);
        v_blank_a0.setBackground(Color.green);
        a_blank_a0.setBackground(Color.green);

        xcanvas.bgcolor=Color.white; xcanvas.fgcolor=Color.red;
        xcanvas.axcolor=Color.gray;
        xpanel.setBackground(Color.white);
        xpanel.add (x_label_x0);xpanel.add (x_blank_x0);
        xpanel.add (x_label_v0);xpanel.add (x_blank_v0);
        xpanel.add (x_label_a0);xpanel.add (x_blank_a0);

        vcanvas.bgcolor=Color.green; vcanvas.fgcolor=Color.red;
        vcanvas.axcolor=Color.gray;
        vpanel.setBackground(Color.green);
        vpanel.add (v_label_v0);vpanel.add (v_blank_v0);
        vpanel.add (v_label_a0);vpanel.add (v_blank_a0);

        acanvas.bgcolor=Color.yellow; acanvas.fgcolor=Color.red;
        acanvas.axcolor=Color.gray;
        apanel.setBackground(Color.yellow);
        apanel.add (a_label_a0);apanel.add (a_blank_a0);

        myGBC.weighty=1.0;
        myGBC.gridwidth=1;
        myGBLayout.setConstraints(xcanvas, myGBC);add (xcanvas);
        myGBC.gridwidth=GridBagConstraints.REMAINDER;
        myGBLayout.setConstraints(xpanel, myGBC);add (xpanel);

        myGBC.gridwidth=1;
        myGBLayout.setConstraints(vcanvas, myGBC);add (vcanvas);
        myGBC.gridwidth=GridBagConstraints.REMAINDER;
        myGBLayout.setConstraints(vpanel, myGBC);add (vpanel);

        myGBC.gridwidth=1;
        myGBLayout.setConstraints(acanvas, myGBC);add (acanvas);
        myGBC.gridwidth=GridBagConstraints.REMAINDER;
        myGBLayout.setConstraints(apanel, myGBC);add (apanel);
    }

    /////////////////////////////////////////////////////////
    // Event handling
    /////////////////////////////////////////////////////////
    public boolean action (Event evt, Object arg)
    {
        if (evt.id == Event.WINDOW_EXPOSE)
        {
            repaint ();
        }
        return false;
    }
    public void update(Graphics g)
    {
        paint(g);
    }


    public void paint(Graphics g)
    {
        xcanvas.graphFunction(x0,v0,a0);
        vcanvas.graphFunction(v0,a0);
        acanvas.graphFunction(a0);
        //screenupdate();
    }
    public void screenupdate()
    {
        xcanvas.repaint();
        vcanvas.repaint();
        acanvas.repaint();
        validate();
    }

    public boolean keyUp (Event evt, int Key)
    {
        if (Key == 10)          // Return key
        {
            if ((x_blank_x0==evt.target) ||
                (x_blank_v0==evt.target) ||
                (x_blank_a0==evt.target)   )
            {
                x0=Double.valueOf(x_blank_x0.getText()).doubleValue();
                v0=Double.valueOf(x_blank_v0.getText()).doubleValue();
                a0=Double.valueOf(x_blank_a0.getText()).doubleValue();
                v_blank_v0.setText(""+v0);
                v_blank_a0.setText(""+a0);
                a_blank_a0.setText(""+a0);
            }
            else if ((v_blank_v0==evt.target) ||
                     (v_blank_a0==evt.target)   )
            {
                v0=Double.valueOf(v_blank_v0.getText()).doubleValue();
                a0=Double.valueOf(v_blank_a0.getText()).doubleValue();
                x_blank_v0.setText(""+v0);
                x_blank_a0.setText(""+a0);
                a_blank_a0.setText(""+a0);
            }
            else if (a_blank_a0==evt.target)
            {
                a0=Double.valueOf(a_blank_a0.getText()).doubleValue();
                x_blank_a0.setText(""+a0);
                v_blank_a0.setText(""+a0);
            }
            repaint();
        }
        return false;
    }

}

