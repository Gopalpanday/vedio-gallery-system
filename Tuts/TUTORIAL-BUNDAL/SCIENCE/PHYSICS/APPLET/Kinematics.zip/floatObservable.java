public class floatObservable extends Observable
{
  float value;

  public floatObservable() {value=0.0;}
  public floatObservable(float newValue) {value=newValue;}
  public synchronized void setValue(float newValue)
  {
    if (newValue!=value) {
      value=newValue;
      setChanged();
      notifyObservers();
    }
  }
  public synchronized float getValue()
  {
    return value;
  }
}  
