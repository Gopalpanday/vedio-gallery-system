import java.applet.*;
import java.awt.*;
import java.lang.Math;
import java.util.*;


class Coordinate {int x, y;}


/*class _Graph {}
class xGraph extends _Graph {}
class vGraph extends _Graph {}
class aGraph extends _Graph {}
// _Graph xgraph, vgraph, agraph;

*/


class _Graph extends Panel{
	Graphics g;
	Image Im;
	static int Scale=20;
	static int GraphHeight, GraphWidth;
	Coordinate dragFrom = new Coordinate();
	Coordinate dragTo = new Coordinate();
	Coordinate Origin = new Coordinate();

	public void init()
	{
	setLayout(new BorderLayout());
	setBackground(Color.gray);
	setForeground(Color.red);
	Origin.x=Origin.y=0;
	createHiddenIm();
	}

	public void createHiddenIm()
	{
		Im = createImage (GraphWidth, GraphHeight);
		g = Im.getGraphics ();
	}
}




public class Kinematica extends Applet
{
	// Constant for the size of the window

	TextField blank_x0 = new TextField ("",3);
	TextField blank_v0 = new TextField ("",3);
	TextField blank_a0 = new TextField ("",3);

   	double x0=0.0, v0=0.0, a0=0.0;

	Label ScaleField = new Label("20", Label.CENTER);


	boolean debug = true;


	Coordinate dragFrom = new Coordinate();
	Coordinate dragTo = new Coordinate();
	Coordinate Origin = new Coordinate();

	Graphics xg, vg, ag;
	Image xIm, vIm, aIm;

	int GraphHeight, GraphWidth;

	int Scale = 20;
	int MouseUp = 1;


	public void init ()
	{
		setLayout(new BorderLayout());
		setBackground (Color.black);
		setForeground (Color.red);
		Origin.x = 0;
		Origin.y = 0;
		createHiddenIm();
	}

	void GetGraphSize ()
	{
	    GraphHeight=size().height/4;
	    GraphWidth=size().width/4;
	}


	void createHiddenIm ()
	{
		GetGraphSize();

	    xIm = createImage (GraphWidth, GraphHeight);
		xg = xIm.getGraphics ();

	    vIm = createImage (GraphWidth, GraphHeight);
		vg = vIm.getGraphics ();

	    aIm = createImage (GraphWidth, GraphHeight);
		ag = aIm.getGraphics ();
    }


	public void start ()
	{
	  Panel graphPanel = new Panel();
	  Panel algebraPanel = new Panel();
	  Panel simulationPanel = new Panel();


		Panel p = new Panel ();

		Panel innerP = new Panel();
		innerP.add (new Button ("-"));
		innerP.add (ScaleField);
		innerP.add (new Button ("+"));

		blank_x0.setForeground(Color.blue);
		blank_x0.setBackground(Color.green);
		blank_x0.setFont(new Font("Courier",1,14));

        p.add (new Label ("x0="));
        p.add (blank_x0);
        p.add (new Label ("v0="));
        p.add (blank_v0);
        p.add (new Label ("a0="));
        p.add (blank_a0);

		//p.add (new Button ("Show graph"));
        p.add ("East",innerP);

		add ("North", p);

	}


	/////////////////////////////////////////////////////////
	// Event handling
	/////////////////////////////////////////////////////////
	public boolean action (Event evt, Object arg)
	{
		if ("Show graph".equals (arg))
		{
		    x0=Double.valueOf(blank_x0.getText()).doubleValue();
		    v0=Double.valueOf(blank_v0.getText()).doubleValue();
		    a0=Double.valueOf(blank_a0.getText()).doubleValue();
					repaint ();
		}
		if ("-".equals (arg) && Scale < 100)
		{
			Scale += 1;
			ScaleField.setText (String.valueOf (Scale));
			repaint();
		}
		if ("+".equals (arg) && Scale > 3)
		{
			Scale -= 1;
			ScaleField.setText (String.valueOf (Scale));
			repaint();
		}
		if ("*".equals (arg) && Scale > 3)
		{
            showStatus("Scale="+String.valueOf (Scale) );
			repaint();
		}

		if (evt.id == Event.WINDOW_EXPOSE)
		{
			createHiddenIm ();
			repaint ();
		}
		return false;
	}

	// This enables the user to see the graph by pressing enter only
	public boolean keyUp (Event evt, int Key)
	{
		if (Key == 10)			// Return key
		{
		    x0=Double.valueOf(blank_x0.getText()).doubleValue();
		    v0=Double.valueOf(blank_v0.getText()).doubleValue();
		    a0=Double.valueOf(blank_a0.getText()).doubleValue();

			repaint ();
		}
		return false;
	}

	// This enables the user to drag the coordinate system with the mouse
	public boolean mouseDown (Event evt, int x, int y)
	{
	        dragFrom.x = x;
		dragFrom.y = y;
		MouseUp = 0;
		return false;
	}
	public boolean mouseDrag (Event evt, int x, int y)
	{
		dragTo.x = x;
		dragTo.y = y;
		repaint ();
		return false;
	}
	public boolean mouseUp (Event evt, int x, int y)
	{
		Origin.x += dragTo.x - dragFrom.x;
		Origin.y += dragTo.y - dragFrom.y;
		dragFrom.x = dragTo.x;
		dragFrom.y = dragTo.y;
		MouseUp = 1;
		repaint ();
		return false;
	}


	/////////////////////////////////////////////////////////
	// Painting and Stuff
	/////////////////////////////////////////////////////////
        public void update (Graphics g)
        {
                paint (g);
        }

	public void paint (Graphics g)
	{
	    GetGraphSize();

		DrawCoordSystem (xg, Color.white);
		DrawCoordSystem (vg, Color.green);
		DrawCoordSystem (ag, Color.yellow);

		Draw ();

		g.drawImage (xIm, 10, GraphHeight-10, this);
		g.drawImage (vIm, 10, 2*GraphHeight-5, this);
		g.drawImage (aIm, 10, 3*GraphHeight, this);

	}



	////////////////////////////////////////////////////////////////////
	// This function draws the initial coordinating system to the screen.
	////////////////////////////////////////////////////////////////////
	private void DrawCoordSystem (Graphics hg, Color background_color)
	{
		int MIDDLE_X = (int)(GraphWidth / 2) + Origin.x + dragTo.x - dragFrom.x;
		int MIDDLE_Y = (int)(GraphHeight / 2) + Origin.y + dragTo.y - dragFrom.y;

		int UNIT = (int)(GraphWidth / Scale);
		int delta, startX, startY;

		// First clear the hidden Image
		hg.setColor (background_color);
		hg.fillRect (0, 0, GraphWidth, GraphHeight);
		hg.setColor (Color.black);

		// Draw x and y-axis
		hg.drawLine (0, MIDDLE_Y, GraphWidth-1, MIDDLE_Y);		// x-axis
		hg.drawLine (MIDDLE_X, 0, MIDDLE_X, GraphHeight-1);		// y-axis

		// Draw the measurement
		startX = MIDDLE_X - (MIDDLE_X / UNIT) * UNIT;
		for (delta = startX; delta <= GraphWidth; delta += UNIT)
			hg.drawLine (delta, MIDDLE_Y + 2, delta, MIDDLE_Y - 2);
		startY = MIDDLE_Y - (MIDDLE_Y / UNIT) * UNIT;
		for (delta = startY; delta <= GraphHeight; delta += UNIT)
		{
			hg.drawLine (MIDDLE_X - 2, delta, MIDDLE_X + 2, delta);
		}
	}



	////////////////////////////////////////////////////////////////////
	// Draws the function specified in E ('Expression' object)
	////////////////////////////////////////////////////////////////////

    private double f(double t) {
        return (a0*t*t/2.0+v0*t+x0);
    }


    private double df(double t) {
        return (a0*t+v0);
    }

    private double ddf(double t) {
        return (a0);
    }

	private void Draw ()
	{
		int MIDDLE_X = (int)(GraphWidth / 2) + Origin.x + dragTo.x - dragFrom.x;
		int MIDDLE_Y = (int)(GraphHeight/ 2) + Origin.y + dragTo.y - dragFrom.y;
		int UNIT = (int)(GraphWidth / Scale);
		double y, x, dy, ddy;
		int Y, OLD_Y, dY, dOLD_Y, ddY, ddOLD_Y;
		int i, Error, oldError;

		//---
		Error = 0;
		x = (double)(-MIDDLE_X) / (double)UNIT;
		y = 0;
		dy= 0;
		ddy=0;

		try
		{
			y  =  f(0.0);
			dy = df(0.0);
			ddy=ddf(0.0);
		}
		catch (Exception e)
		{
			Error = 1;
			dbi ("Error  at " + String.valueOf (Scale) + " :: " + e.getMessage());
		}
		//---

		  Y = -(int)(  y * (double)UNIT) + MIDDLE_Y;
		 dY = -(int)( dy * (double)UNIT) + MIDDLE_Y;
		ddY = -(int)(ddy * (double)UNIT) + MIDDLE_Y;

		for (i = -1; i <= GraphWidth; i++)
		{
			oldError = Error;

		    //---
		    Error = 0;
			x = (double)(i - MIDDLE_X) / (double)UNIT;
			try
			{
				y  =  f(x);
				dy = df(x);
				ddy=ddf(x);
			}
			catch (ArithmeticException e)
			{
				if (Error == 0)
				{
					dbi ("Error got from evaluating the expression at the value of " + String.valueOf (x) + " is : " + e.getMessage());
					Error = 1;
				}
			}
            //---

			if (Error == 0)
			{
				  OLD_Y =  Y;
				 dOLD_Y = dY;
                ddOLD_Y =ddY;
				  Y = -(int)(  y * (double)UNIT) + MIDDLE_Y;
				 dY = -(int)( dy * (double)UNIT) + MIDDLE_Y;
				ddY = -(int)(ddy * (double)UNIT) + MIDDLE_Y;
				if (oldError == 0)
				{

					xg.setColor (Color.black);
					xg.drawLine (i - 1, OLD_Y, i, Y);
					vg.setColor(Color.red);
					vg.drawLine (i - 1, dOLD_Y, i, dY);
					ag.setColor(Color.blue);
					ag.drawLine (i - 1, ddOLD_Y, i, ddY);
				}
			}
		}


	}

	void dbi (String msg)
	{
		if (debug)
			System.out.println (msg);
	}
}

