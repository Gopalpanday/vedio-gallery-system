// Class   : SineLine
// Author  : Russ Ethington
// Version : 1/27/96 for Java 1.0
// Notice  : Copyright (C) 1995, 1996 Russ Ethington

import java.awt.*;
import java.lang.*;
import java.util.*;
import java.applet.*;

public class SineLine extends Applet implements Runnable
{
   private int points[];
   private int shift = 0;
   private int sleepTime;
   private Thread life = null;
   private Image image;
   private Graphics osG;
   private int lineType = 0;
   private int theSpeed;
   private int direction;
   private Color background;
   private int mouseClick = 0;
   private boolean paused = false;

   public static final int Raised = 0;
   public static final int Lowered = 1;

   public static final int Left = -1;
   public static final int Right = 1;

   final int Priority = Thread.MIN_PRIORITY;

   public void init() 
   { 
      points = new int[size().width];

      // Randomize this line equation each time.

      double factor = Math.PI / size().width;

      int ampl1 = randomInteger(1, 3);
      int ampl2 = randomInteger(1, 3);
      int ampl3 = 0; //randomInteger(1, 1);

      double rate1 = randomInteger(10, 30);
      double rate2 = randomInteger(30, 50);
      double rate3 = randomInteger(50, 70);

      int heightFactor = (ampl1 + ampl2 + ampl3 + 1) * 2;

      for (double i = 0; i < size().width; i++)
      {
         double x = (ampl1 * (Math.sin(rate1 * i * factor) + 1) +
                     ampl2 * (Math.sin(rate2 * i * factor) + 1) +
                     ampl3 * (Math.sin(rate3 * i * factor) + 1)) * 
                     size().height / heightFactor;

         points[(int)i] = (int) x;
      }

      image = createImage(size().width, size().height);
      osG = image.getGraphics();

      String theScrollSpeed = getParameter("Speed");
      if (theScrollSpeed == null) theScrollSpeed = "5";

      theSpeed = Integer.parseInt(theScrollSpeed);
      if (theSpeed < 1) theSpeed = 1;
      if (theSpeed > 10) theSpeed = 10;

      setInterval(theSpeed);

      String theDirection = getParameter("Direction");
      if (theDirection == null) theDirection = "Left";

      if (theDirection.equalsIgnoreCase("Left"))
         direction = Left;
      else
         direction = Right;

      String theBackground = getParameter("Background");
      if (theBackground == null)
         background = Color.lightGray;
      else
      {
         try
            background = new Color(Integer.parseInt(theBackground, 16));
         catch (NumberFormatException e)
            background = Color.lightGray;
      }
      setBackground(background);

      String theTypeName = getParameter("Type");
      if (theTypeName == null) theTypeName = "Default";

      if (theTypeName.equalsIgnoreCase("Lowered"))
         prepareEtchedLine(Lowered);
      else
      if (theTypeName.equalsIgnoreCase("Raised"))
         prepareEtchedLine(Raised);      
      else 
      if (theTypeName.equalsIgnoreCase("Default"))
         prepareDefaultLine();
   }

   public void setInterval(int speed)
   {
      sleepTime = 100 - 10 * speed;
   }

   int randomInteger(int low, int high)
   {
      return (int) (low + Math.random() * (high - low));
   }

   public void start()
   {
      if (life == null)
      {
         life = new Thread(this);
         life.setPriority(Priority);
         life.start();
      }
   }

   public void run()
   {
      long total = 0;
      long sum = 0;

      while (life != null)
      {
         long then = System.currentTimeMillis();         
         if (!paused) repaint();
         long now = System.currentTimeMillis();

         if (now - then < sleepTime)
         {
            try
               life.sleep(now - then);
            catch (InterruptedException e)
               ;
         }
      }
   }
   
   public void stop()
   {
      if (life != null  && life.isAlive()) 
         life.stop();
      life = null;
   }

   public void update(Graphics g) 
   {       
      g.drawImage(image, shift, 0, this);
      g.drawImage(image, shift - bounds().width, 0, this);

      if (paused) return;
      
      if (direction == Left)
      {
         if ((shift=shift-2) <= 0) shift = points.length;
      }
      else
      {
         if ((shift=shift+2) >= points.length) shift = 0;
      }
   }

   public void prepareEtchedLine(int way)
   {
      osG.setColor(background);
      osG.fillRect(0, 0, size().width, size().height);

      int offset = 0;

      if (way == Lowered)
         osG.setColor(Color.darkGray);
      else
         osG.setColor(Color.white);

      for (int i = 0; i < points.length - 1; i++)
         osG.drawLine((i + offset) % points.length, 
                      points[i], 
                      (i + offset) % points.length + 1, 
                      points[i + 1]);
      offset = 1;

      if (way == Lowered)
         osG.setColor(Color.white);
      else
         osG.setColor(Color.darkGray);

      for (int i = 0; i < points.length - 1; i++)
         osG.drawLine((i + offset) % points.length, 
                      points[i] + offset, 
                      (i + offset) % points.length + 1, 
                      points[i + 1] + offset);
   }
   
   public void prepareDefaultLine()
   {
      osG.setColor(background);
      osG.fillRect(0, 0, size().width, size().height);

      int offset = 0;

      osG.setColor(Color.blue);
      for (int i = 0; i < points.length - 1; i++)
         osG.drawLine((i + offset) % points.length, 
                      points[i], 
                      (i + offset) % points.length + 1, 
                      points[i + 1]);
      offset += 5;

      osG.setColor(Color.white);
      for (int i = 0; i < points.length - 1; i++)
         osG.drawLine((i + offset) % points.length, 
                      points[i], 
                      (i + offset) % points.length + 1, 
                      points[i + 1]);
      offset += 5;

      osG.setColor(Color.red);
      for (int i = 0; i < points.length - 1; i++)
         osG.drawLine((i + offset) % points.length, 
                      points[i], 
                      (i + offset) % points.length + 1, 
                      points[i + 1]);
   }

   public boolean mouseDown(Event e, int x, int y)
   {
      switch (mouseClick % 4)
      {
         case 0:
            paused = true;
         break;

         case 1:
            direction = -direction;
            paused = false;
         break;

         case 2:
            init();
            paused = true;
         break;

         case 3:
            paused = false;
         break;
      }
      mouseClick++;

      return true;
   }
}
