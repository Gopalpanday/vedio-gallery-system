public class VariableInput extends TextField implements Observer
{
  private floatObservable floatValue;

  public VariableInput(floatObservable theFloat)
  {
    super(""+theFloat.getValue(),3);
    floatValue=theFloat;
    floatValue.addObserver(this); // Express interest in value
  }

  public boolean action(Event evt, Object whatAction)
  {
    Float floatStr;
    try{
      floatStr = new Float(getText());
      floatValue.setValue(floatStr.getValue());
    } catch (Exception oops) {}
    return true;
  }

  public void update(Observable obs, Object arg)
  {
    setText(""+floatValue.getValue());
  }
}
